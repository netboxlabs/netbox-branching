-- NetBox branching fixture
-- Source NetBox version: 4.4.10
-- Original schema name: branch_x2alz17k
-- The placeholder __BRANCH_SCHEMA__ must be substituted with the
-- target schema name before executing this SQL.

--
-- PostgreSQL database dump
--


-- Dumped from database version 17.9 (Homebrew)
-- Dumped by pg_dump version 17.9 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: __BRANCH_SCHEMA__; Type: SCHEMA; Schema: -; Owner: -
--



SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: circuits_circuit; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_circuit (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.circuits_circuit_id_seq'::regclass) NOT NULL,
    cid character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    install_date date,
    commit_rate integer,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    provider_id bigint NOT NULL,
    tenant_id bigint,
    termination_a_id bigint,
    termination_z_id bigint,
    type_id bigint NOT NULL,
    termination_date date,
    provider_account_id bigint,
    _abs_distance numeric(13,4),
    distance numeric(8,2),
    distance_unit character varying(50)
);


--
-- Name: circuits_circuitgroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_circuitgroup (
    id bigint DEFAULT nextval('public.circuits_circuitgroup_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    tenant_id bigint
);


--
-- Name: circuits_circuitgroupassignment; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_circuitgroupassignment (
    id bigint DEFAULT nextval('public.circuits_circuitgroupassignment_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    priority character varying(50),
    member_id bigint NOT NULL,
    group_id bigint NOT NULL,
    member_type_id integer NOT NULL
);


--
-- Name: circuits_circuittermination; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_circuittermination (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.circuits_circuittermination_id_seq'::regclass) NOT NULL,
    mark_connected boolean NOT NULL,
    term_side character varying(1) NOT NULL,
    port_speed integer,
    upstream_speed integer,
    xconnect_id character varying(50) NOT NULL,
    pp_info character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    cable_id bigint,
    circuit_id bigint NOT NULL,
    _provider_network_id bigint,
    custom_field_data jsonb NOT NULL,
    cable_end character varying(1),
    termination_id bigint,
    termination_type_id integer,
    _location_id bigint,
    _region_id bigint,
    _site_id bigint,
    _site_group_id bigint
);


--
-- Name: circuits_circuittype; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_circuittype (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.circuits_circuittype_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    color character varying(6) NOT NULL
);


--
-- Name: circuits_provider; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_provider (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.circuits_provider_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    comments text NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: circuits_provider_asns; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_provider_asns (
    id bigint DEFAULT nextval('public.circuits_provider_asns_id_seq'::regclass) NOT NULL,
    provider_id bigint NOT NULL,
    asn_id bigint NOT NULL
);


--
-- Name: circuits_provideraccount; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_provideraccount (
    id bigint DEFAULT nextval('public.circuits_provideraccount_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    account character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    provider_id bigint NOT NULL
);


--
-- Name: circuits_providernetwork; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_providernetwork (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.circuits_providernetwork_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    provider_id bigint NOT NULL,
    service_id character varying(100) NOT NULL
);


--
-- Name: circuits_virtualcircuit; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_virtualcircuit (
    id bigint DEFAULT nextval('public.circuits_virtualcircuit_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    cid character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    provider_account_id bigint,
    provider_network_id bigint NOT NULL,
    type_id bigint NOT NULL,
    tenant_id bigint
);


--
-- Name: circuits_virtualcircuittermination; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_virtualcircuittermination (
    id bigint DEFAULT nextval('public.circuits_virtualcircuittermination_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    role character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    interface_id bigint NOT NULL,
    virtual_circuit_id bigint NOT NULL
);


--
-- Name: circuits_virtualcircuittype; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.circuits_virtualcircuittype (
    id bigint DEFAULT nextval('public.circuits_virtualcircuittype_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    color character varying(6) NOT NULL
);


--
-- Name: core_objectchange; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.core_objectchange (
    id bigint DEFAULT nextval('public.core_objectchange_id_seq'::regclass) NOT NULL,
    "time" timestamp with time zone NOT NULL,
    user_name character varying(150) NOT NULL,
    request_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    changed_object_id bigint NOT NULL,
    related_object_id bigint,
    object_repr character varying(200) NOT NULL,
    prechange_data jsonb,
    postchange_data jsonb,
    changed_object_type_id integer NOT NULL,
    related_object_type_id integer,
    user_id bigint,
    message character varying(200) NOT NULL
);


--
-- Name: dcim_cable; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_cable (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_cable_id_seq'::regclass) NOT NULL,
    type character varying(50),
    status character varying(50) NOT NULL,
    label character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    length numeric(8,2),
    length_unit character varying(50),
    _abs_length numeric(10,4),
    tenant_id bigint,
    comments text NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: dcim_cablepath; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_cablepath (
    id bigint DEFAULT nextval('public.dcim_cablepath_id_seq'::regclass) NOT NULL,
    _nodes character varying(40)[] NOT NULL,
    is_active boolean NOT NULL,
    is_split boolean NOT NULL,
    path jsonb NOT NULL,
    is_complete boolean NOT NULL
);


--
-- Name: dcim_cabletermination; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_cabletermination (
    id bigint DEFAULT nextval('public.dcim_cabletermination_id_seq'::regclass) NOT NULL,
    cable_end character varying(1) NOT NULL,
    termination_id bigint NOT NULL,
    cable_id bigint NOT NULL,
    termination_type_id integer NOT NULL,
    _device_id bigint,
    _rack_id bigint,
    _location_id bigint,
    _site_id bigint,
    created timestamp with time zone,
    last_updated timestamp with time zone
);


--
-- Name: dcim_consoleport; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_consoleport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_consoleport_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50),
    speed integer,
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_consoleporttemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_consoleporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.dcim_consoleporttemplate_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    device_type_id bigint,
    module_type_id bigint
);


--
-- Name: dcim_consoleserverport; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_consoleserverport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_consoleserverport_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50),
    speed integer,
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_consoleserverporttemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_consoleserverporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.dcim_consoleserverporttemplate_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    device_type_id bigint,
    module_type_id bigint
);


--
-- Name: dcim_device; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_device (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_device_id_seq'::regclass) NOT NULL,
    local_context_data jsonb,
    name character varying(64) COLLATE public.natural_sort,
    serial character varying(50) NOT NULL,
    asset_tag character varying(50),
    "position" numeric(4,1),
    face character varying(50),
    status character varying(50) NOT NULL,
    vc_position integer,
    vc_priority smallint,
    comments text NOT NULL,
    cluster_id bigint,
    role_id bigint NOT NULL,
    device_type_id bigint NOT NULL,
    location_id bigint,
    platform_id bigint,
    primary_ip4_id bigint,
    primary_ip6_id bigint,
    rack_id bigint,
    site_id bigint NOT NULL,
    tenant_id bigint,
    virtual_chassis_id bigint,
    airflow character varying(50),
    description character varying(200) NOT NULL,
    config_template_id bigint,
    latitude numeric(8,6),
    longitude numeric(9,6),
    oob_ip_id bigint,
    console_port_count bigint NOT NULL,
    console_server_port_count bigint NOT NULL,
    power_port_count bigint NOT NULL,
    power_outlet_count bigint NOT NULL,
    interface_count bigint NOT NULL,
    front_port_count bigint NOT NULL,
    rear_port_count bigint NOT NULL,
    device_bay_count bigint NOT NULL,
    module_bay_count bigint NOT NULL,
    inventory_item_count bigint NOT NULL
);


--
-- Name: dcim_devicebay; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_devicebay (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_devicebay_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    device_id bigint NOT NULL,
    installed_device_id bigint,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_devicebaytemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_devicebaytemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.dcim_devicebaytemplate_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    device_type_id bigint NOT NULL
);


--
-- Name: dcim_devicerole; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_devicerole (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_devicerole_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    vm_role boolean NOT NULL,
    description character varying(200) NOT NULL,
    config_template_id bigint,
    level integer NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    parent_id bigint,
    comments text NOT NULL
);


--
-- Name: dcim_devicetype; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_devicetype (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_devicetype_id_seq'::regclass) NOT NULL,
    model character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    part_number character varying(50) NOT NULL,
    u_height numeric(4,1) NOT NULL,
    is_full_depth boolean NOT NULL,
    subdevice_role character varying(50),
    front_image character varying(100) NOT NULL,
    rear_image character varying(100) NOT NULL,
    comments text NOT NULL,
    manufacturer_id bigint NOT NULL,
    airflow character varying(50),
    weight numeric(8,2),
    weight_unit character varying(50),
    _abs_weight bigint,
    description character varying(200) NOT NULL,
    default_platform_id bigint,
    console_port_template_count bigint NOT NULL,
    console_server_port_template_count bigint NOT NULL,
    power_port_template_count bigint NOT NULL,
    power_outlet_template_count bigint NOT NULL,
    interface_template_count bigint NOT NULL,
    front_port_template_count bigint NOT NULL,
    rear_port_template_count bigint NOT NULL,
    device_bay_template_count bigint NOT NULL,
    module_bay_template_count bigint NOT NULL,
    inventory_item_template_count bigint NOT NULL,
    exclude_from_utilization boolean NOT NULL
);


--
-- Name: dcim_frontport; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_frontport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_frontport_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50) NOT NULL,
    rear_port_position smallint NOT NULL,
    cable_id bigint,
    device_id bigint NOT NULL,
    rear_port_id bigint NOT NULL,
    color character varying(6) NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_frontporttemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_frontporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.dcim_frontporttemplate_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50) NOT NULL,
    rear_port_position smallint NOT NULL,
    device_type_id bigint,
    rear_port_id bigint NOT NULL,
    color character varying(6) NOT NULL,
    module_type_id bigint
);


--
-- Name: dcim_interface; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_interface (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_interface_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    enabled boolean NOT NULL,
    mtu integer,
    mode character varying(50),
    _name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    mgmt_only boolean NOT NULL,
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    lag_id bigint,
    parent_id bigint,
    untagged_vlan_id bigint,
    wwn macaddr8,
    bridge_id bigint,
    rf_role character varying(30),
    rf_channel character varying(50),
    rf_channel_frequency numeric(7,2),
    rf_channel_width numeric(7,3),
    tx_power smallint,
    wireless_link_id bigint,
    module_id bigint,
    vrf_id bigint,
    duplex character varying(50),
    speed integer,
    poe_mode character varying(50),
    poe_type character varying(50),
    cable_end character varying(1),
    vlan_translation_policy_id bigint,
    qinq_svlan_id bigint,
    primary_mac_address_id bigint,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_interface_tagged_vlans; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_interface_tagged_vlans (
    id bigint DEFAULT nextval('public.dcim_interface_tagged_vlans_id_seq'::regclass) NOT NULL,
    interface_id bigint NOT NULL,
    vlan_id bigint NOT NULL
);


--
-- Name: dcim_interface_vdcs; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_interface_vdcs (
    id bigint DEFAULT nextval('public.dcim_interface_vdcs_id_seq'::regclass) NOT NULL,
    interface_id bigint NOT NULL,
    virtualdevicecontext_id bigint NOT NULL
);


--
-- Name: dcim_interface_wireless_lans; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_interface_wireless_lans (
    id bigint DEFAULT nextval('public.dcim_interface_wireless_lans_id_seq'::regclass) NOT NULL,
    interface_id bigint NOT NULL,
    wirelesslan_id bigint NOT NULL
);


--
-- Name: dcim_interfacetemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_interfacetemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.dcim_interfacetemplate_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    _name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    mgmt_only boolean NOT NULL,
    device_type_id bigint,
    module_type_id bigint,
    poe_mode character varying(50),
    poe_type character varying(50),
    enabled boolean NOT NULL,
    bridge_id bigint,
    rf_role character varying(30)
);


--
-- Name: dcim_inventoryitem; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_inventoryitem (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_inventoryitem_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    part_id character varying(50) NOT NULL,
    serial character varying(50) NOT NULL,
    asset_tag character varying(50),
    discovered boolean NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    device_id bigint NOT NULL,
    manufacturer_id bigint,
    parent_id bigint,
    role_id bigint,
    component_id bigint,
    component_type_id integer,
    status character varying(50) NOT NULL,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_inventoryitemrole; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_inventoryitemrole (
    id bigint DEFAULT nextval('public.dcim_inventoryitemrole_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: dcim_inventoryitemtemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_inventoryitemtemplate (
    id bigint DEFAULT nextval('public.dcim_inventoryitemtemplate_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    component_id bigint,
    part_id character varying(50) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    component_type_id integer,
    device_type_id bigint NOT NULL,
    manufacturer_id bigint,
    parent_id bigint,
    role_id bigint
);


--
-- Name: dcim_location; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_location (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_location_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id bigint,
    site_id bigint NOT NULL,
    tenant_id bigint,
    status character varying(50) NOT NULL,
    facility character varying(50) NOT NULL,
    comments text NOT NULL
);


--
-- Name: dcim_macaddress; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_macaddress (
    id bigint DEFAULT nextval('public.dcim_macaddress_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    mac_address macaddr NOT NULL,
    assigned_object_id bigint,
    assigned_object_type_id integer
);


--
-- Name: dcim_manufacturer; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_manufacturer (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_manufacturer_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: dcim_module; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_module (
    id bigint DEFAULT nextval('public.dcim_module_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    local_context_data jsonb,
    serial character varying(50) NOT NULL,
    asset_tag character varying(50),
    comments text NOT NULL,
    device_id bigint NOT NULL,
    module_bay_id bigint NOT NULL,
    module_type_id bigint NOT NULL,
    description character varying(200) NOT NULL,
    status character varying(50) NOT NULL
);


--
-- Name: dcim_modulebay; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_modulebay (
    id bigint DEFAULT nextval('public.dcim_modulebay_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    "position" character varying(30) NOT NULL,
    description character varying(200) NOT NULL,
    device_id bigint NOT NULL,
    level integer NOT NULL,
    lft integer NOT NULL,
    module_id bigint,
    parent_id bigint,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_modulebaytemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_modulebaytemplate (
    id bigint DEFAULT nextval('public.dcim_modulebaytemplate_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    "position" character varying(30) NOT NULL,
    description character varying(200) NOT NULL,
    device_type_id bigint,
    module_type_id bigint
);


--
-- Name: dcim_moduletype; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_moduletype (
    id bigint DEFAULT nextval('public.dcim_moduletype_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    model character varying(100) NOT NULL,
    part_number character varying(50) NOT NULL,
    comments text NOT NULL,
    manufacturer_id bigint NOT NULL,
    weight numeric(8,2),
    weight_unit character varying(50),
    _abs_weight bigint,
    description character varying(200) NOT NULL,
    airflow character varying(50),
    attribute_data jsonb,
    profile_id bigint
);


--
-- Name: dcim_moduletypeprofile; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_moduletypeprofile (
    id bigint DEFAULT nextval('public.dcim_moduletypeprofile_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    schema jsonb
);


--
-- Name: dcim_platform; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_platform (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_platform_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    manufacturer_id bigint,
    config_template_id bigint,
    parent_id bigint,
    level integer NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    comments text NOT NULL
);


--
-- Name: dcim_powerfeed; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_powerfeed (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_powerfeed_id_seq'::regclass) NOT NULL,
    mark_connected boolean NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    type character varying(50) NOT NULL,
    supply character varying(50) NOT NULL,
    phase character varying(50) NOT NULL,
    voltage smallint NOT NULL,
    amperage smallint NOT NULL,
    max_utilization smallint NOT NULL,
    available_power integer NOT NULL,
    comments text NOT NULL,
    _path_id bigint,
    cable_id bigint,
    power_panel_id bigint NOT NULL,
    rack_id bigint,
    cable_end character varying(1),
    description character varying(200) NOT NULL,
    tenant_id bigint
);


--
-- Name: dcim_poweroutlet; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_poweroutlet (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_poweroutlet_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50),
    feed_leg character varying(50),
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    power_port_id bigint,
    module_id bigint,
    cable_end character varying(1),
    color character varying(6) NOT NULL,
    status character varying(50) NOT NULL,
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_poweroutlettemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_poweroutlettemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.dcim_poweroutlettemplate_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    feed_leg character varying(50),
    device_type_id bigint,
    power_port_id bigint,
    module_type_id bigint
);


--
-- Name: dcim_powerpanel; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_powerpanel (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_powerpanel_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    location_id bigint,
    site_id bigint NOT NULL,
    comments text NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: dcim_powerport; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_powerport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_powerport_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50),
    maximum_draw integer,
    allocated_draw integer,
    _path_id bigint,
    cable_id bigint,
    device_id bigint NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_powerporttemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_powerporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.dcim_powerporttemplate_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50),
    maximum_draw integer,
    allocated_draw integer,
    device_type_id bigint,
    module_type_id bigint
);


--
-- Name: dcim_rack; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_rack (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_rack_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    facility_id character varying(50),
    status character varying(50) NOT NULL,
    serial character varying(50) NOT NULL,
    asset_tag character varying(50),
    form_factor character varying(50),
    width smallint NOT NULL,
    u_height smallint NOT NULL,
    desc_units boolean NOT NULL,
    outer_width smallint,
    outer_depth smallint,
    outer_unit character varying(50),
    comments text NOT NULL,
    location_id bigint,
    role_id bigint,
    site_id bigint NOT NULL,
    tenant_id bigint,
    weight numeric(8,2),
    max_weight integer,
    weight_unit character varying(50),
    _abs_weight bigint,
    _abs_max_weight bigint,
    mounting_depth smallint,
    description character varying(200) NOT NULL,
    starting_unit smallint NOT NULL,
    rack_type_id bigint,
    airflow character varying(50),
    outer_height smallint
);


--
-- Name: dcim_rackreservation; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_rackreservation (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_rackreservation_id_seq'::regclass) NOT NULL,
    units smallint[] NOT NULL,
    description character varying(200) NOT NULL,
    rack_id bigint NOT NULL,
    tenant_id bigint,
    user_id bigint NOT NULL,
    comments text NOT NULL,
    status character varying(50) NOT NULL
);


--
-- Name: dcim_rackrole; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_rackrole (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_rackrole_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    color character varying(6) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: dcim_racktype; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_racktype (
    id bigint DEFAULT nextval('public.dcim_racktype_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    weight numeric(8,2),
    weight_unit character varying(50),
    _abs_weight bigint,
    manufacturer_id bigint NOT NULL,
    model character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    form_factor character varying(50) NOT NULL,
    width smallint NOT NULL,
    u_height smallint NOT NULL,
    starting_unit smallint NOT NULL,
    desc_units boolean NOT NULL,
    outer_width smallint,
    outer_depth smallint,
    outer_unit character varying(50),
    max_weight integer,
    _abs_max_weight bigint,
    mounting_depth smallint,
    outer_height smallint
);


--
-- Name: dcim_rearport; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_rearport (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_rearport_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    mark_connected boolean NOT NULL,
    type character varying(50) NOT NULL,
    positions smallint NOT NULL,
    cable_id bigint,
    device_id bigint NOT NULL,
    color character varying(6) NOT NULL,
    module_id bigint,
    cable_end character varying(1),
    _location_id bigint,
    _rack_id bigint,
    _site_id bigint
);


--
-- Name: dcim_rearporttemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_rearporttemplate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.dcim_rearporttemplate_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    label character varying(64) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(50) NOT NULL,
    positions smallint NOT NULL,
    device_type_id bigint,
    color character varying(6) NOT NULL,
    module_type_id bigint
);


--
-- Name: dcim_region; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_region (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_region_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id bigint,
    comments text NOT NULL
);


--
-- Name: dcim_site; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_site (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_site_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    facility character varying(50) NOT NULL,
    time_zone character varying(63),
    description character varying(200) NOT NULL,
    physical_address character varying(200) NOT NULL,
    shipping_address character varying(200) NOT NULL,
    latitude numeric(8,6),
    longitude numeric(9,6),
    comments text NOT NULL,
    group_id bigint,
    region_id bigint,
    tenant_id bigint
);


--
-- Name: dcim_site_asns; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_site_asns (
    id bigint DEFAULT nextval('public.dcim_site_asns_id_seq'::regclass) NOT NULL,
    site_id bigint NOT NULL,
    asn_id bigint NOT NULL
);


--
-- Name: dcim_sitegroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_sitegroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_sitegroup_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id bigint,
    comments text NOT NULL
);


--
-- Name: dcim_virtualchassis; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_virtualchassis (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.dcim_virtualchassis_id_seq'::regclass) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    domain character varying(30) NOT NULL,
    master_id bigint,
    comments text NOT NULL,
    description character varying(200) NOT NULL,
    member_count bigint NOT NULL
);


--
-- Name: dcim_virtualdevicecontext; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.dcim_virtualdevicecontext (
    id bigint DEFAULT nextval('public.dcim_virtualdevicecontext_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    identifier smallint,
    comments text NOT NULL,
    device_id bigint,
    primary_ip4_id bigint,
    primary_ip6_id bigint,
    tenant_id bigint
);


--
-- Name: django_migrations; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE __BRANCH_SCHEMA__.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __BRANCH_SCHEMA__.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: extras_cachedvalue; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_cachedvalue (
    id uuid NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    object_id bigint NOT NULL,
    field character varying(200) NOT NULL,
    type character varying(30) NOT NULL,
    value text NOT NULL,
    weight smallint NOT NULL,
    object_type_id integer NOT NULL
);


--
-- Name: extras_configcontext; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.extras_configcontext_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    weight smallint NOT NULL,
    description character varying(200) NOT NULL,
    is_active boolean NOT NULL,
    data jsonb NOT NULL,
    data_file_id bigint,
    data_path character varying(1000) NOT NULL,
    data_source_id bigint,
    auto_sync_enabled boolean NOT NULL,
    data_synced timestamp with time zone,
    profile_id bigint
);


--
-- Name: extras_configcontext_cluster_groups; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_cluster_groups (
    id bigint DEFAULT nextval('public.extras_configcontext_cluster_groups_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    clustergroup_id bigint NOT NULL
);


--
-- Name: extras_configcontext_cluster_types; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_cluster_types (
    id bigint DEFAULT nextval('public.extras_configcontext_cluster_types_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    clustertype_id bigint NOT NULL
);


--
-- Name: extras_configcontext_clusters; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_clusters (
    id bigint DEFAULT nextval('public.extras_configcontext_clusters_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    cluster_id bigint NOT NULL
);


--
-- Name: extras_configcontext_device_types; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_device_types (
    id bigint DEFAULT nextval('public.extras_configcontext_device_types_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    devicetype_id bigint NOT NULL
);


--
-- Name: extras_configcontext_locations; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_locations (
    id bigint DEFAULT nextval('public.extras_configcontext_locations_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    location_id bigint NOT NULL
);


--
-- Name: extras_configcontext_platforms; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_platforms (
    id bigint DEFAULT nextval('public.extras_configcontext_platforms_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    platform_id bigint NOT NULL
);


--
-- Name: extras_configcontext_regions; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_regions (
    id bigint DEFAULT nextval('public.extras_configcontext_regions_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    region_id bigint NOT NULL
);


--
-- Name: extras_configcontext_roles; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_roles (
    id bigint DEFAULT nextval('public.extras_configcontext_roles_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    devicerole_id bigint NOT NULL
);


--
-- Name: extras_configcontext_site_groups; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_site_groups (
    id bigint DEFAULT nextval('public.extras_configcontext_site_groups_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    sitegroup_id bigint NOT NULL
);


--
-- Name: extras_configcontext_sites; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_sites (
    id bigint DEFAULT nextval('public.extras_configcontext_sites_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    site_id bigint NOT NULL
);


--
-- Name: extras_configcontext_tags; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_tags (
    id bigint DEFAULT nextval('public.extras_configcontext_tags_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: extras_configcontext_tenant_groups; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_tenant_groups (
    id bigint DEFAULT nextval('public.extras_configcontext_tenant_groups_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    tenantgroup_id bigint NOT NULL
);


--
-- Name: extras_configcontext_tenants; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontext_tenants (
    id bigint DEFAULT nextval('public.extras_configcontext_tenants_id_seq'::regclass) NOT NULL,
    configcontext_id bigint NOT NULL,
    tenant_id bigint NOT NULL
);


--
-- Name: extras_configcontextprofile; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configcontextprofile (
    id bigint DEFAULT nextval('public.extras_configcontextprofile_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    data_path character varying(1000) NOT NULL,
    auto_sync_enabled boolean NOT NULL,
    data_synced timestamp with time zone,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    schema jsonb,
    data_file_id bigint,
    data_source_id bigint
);


--
-- Name: extras_configtemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_configtemplate (
    id bigint DEFAULT nextval('public.extras_configtemplate_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    data_path character varying(1000) NOT NULL,
    data_synced timestamp with time zone,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    template_code text NOT NULL,
    environment_params jsonb,
    data_file_id bigint,
    data_source_id bigint,
    auto_sync_enabled boolean NOT NULL,
    as_attachment boolean NOT NULL,
    file_extension character varying(15) NOT NULL,
    file_name character varying(200) NOT NULL,
    mime_type character varying(50) NOT NULL
);


--
-- Name: extras_imageattachment; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_imageattachment (
    id bigint DEFAULT nextval('public.extras_imageattachment_id_seq'::regclass) NOT NULL,
    object_id bigint NOT NULL,
    image character varying(100) NOT NULL,
    image_height smallint NOT NULL,
    image_width smallint NOT NULL,
    name character varying(50) NOT NULL,
    created timestamp with time zone,
    object_type_id integer NOT NULL,
    last_updated timestamp with time zone,
    description character varying(200) NOT NULL
);


--
-- Name: extras_journalentry; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_journalentry (
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.extras_journalentry_id_seq'::regclass) NOT NULL,
    assigned_object_id bigint NOT NULL,
    created timestamp with time zone,
    kind character varying(30) NOT NULL,
    comments text NOT NULL,
    assigned_object_type_id integer NOT NULL,
    created_by_id bigint,
    custom_field_data jsonb NOT NULL
);


--
-- Name: extras_tableconfig; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_tableconfig (
    id bigint DEFAULT nextval('public.extras_tableconfig_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    "table" character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    weight smallint NOT NULL,
    enabled boolean NOT NULL,
    shared boolean NOT NULL,
    columns character varying(100)[] NOT NULL,
    ordering character varying(100)[],
    object_type_id integer NOT NULL,
    user_id bigint
);


--
-- Name: extras_tag; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_tag (
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.extras_tag_id_seq'::regclass) NOT NULL,
    color character varying(6) NOT NULL,
    description character varying(200) NOT NULL,
    weight smallint NOT NULL
);


--
-- Name: extras_tag_object_types; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_tag_object_types (
    id bigint DEFAULT nextval('public.extras_tag_object_types_id_seq'::regclass) NOT NULL,
    tag_id bigint NOT NULL,
    contenttype_id integer NOT NULL
);


--
-- Name: extras_taggeditem; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.extras_taggeditem (
    object_id integer NOT NULL,
    id bigint DEFAULT nextval('public.extras_taggeditem_id_seq'::regclass) NOT NULL,
    content_type_id integer NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: ipam_aggregate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_aggregate (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_aggregate_id_seq'::regclass) NOT NULL,
    prefix cidr NOT NULL,
    date_added date,
    description character varying(200) NOT NULL,
    rir_id bigint NOT NULL,
    tenant_id bigint,
    comments text NOT NULL
);


--
-- Name: ipam_asn; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_asn (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_asn_id_seq'::regclass) NOT NULL,
    asn bigint NOT NULL,
    description character varying(200) NOT NULL,
    rir_id bigint NOT NULL,
    tenant_id bigint,
    comments text NOT NULL
);


--
-- Name: ipam_asnrange; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_asnrange (
    id bigint DEFAULT nextval('public.ipam_asnrange_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    start bigint NOT NULL,
    "end" bigint NOT NULL,
    rir_id bigint NOT NULL,
    tenant_id bigint
);


--
-- Name: ipam_fhrpgroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_fhrpgroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_fhrpgroup_id_seq'::regclass) NOT NULL,
    group_id smallint NOT NULL,
    protocol character varying(50) NOT NULL,
    auth_type character varying(50),
    auth_key character varying(255) NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(100) NOT NULL,
    comments text NOT NULL
);


--
-- Name: ipam_fhrpgroupassignment; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_fhrpgroupassignment (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    id bigint DEFAULT nextval('public.ipam_fhrpgroupassignment_id_seq'::regclass) NOT NULL,
    interface_id bigint NOT NULL,
    priority smallint NOT NULL,
    group_id bigint NOT NULL,
    interface_type_id integer NOT NULL
);


--
-- Name: ipam_ipaddress; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_ipaddress (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_ipaddress_id_seq'::regclass) NOT NULL,
    address inet NOT NULL,
    status character varying(50) NOT NULL,
    role character varying(50),
    assigned_object_id bigint,
    dns_name character varying(255) NOT NULL,
    description character varying(200) NOT NULL,
    assigned_object_type_id integer,
    nat_inside_id bigint,
    tenant_id bigint,
    vrf_id bigint,
    comments text NOT NULL
);


--
-- Name: ipam_iprange; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_iprange (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_iprange_id_seq'::regclass) NOT NULL,
    start_address inet NOT NULL,
    end_address inet NOT NULL,
    size integer NOT NULL,
    status character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    role_id bigint,
    tenant_id bigint,
    vrf_id bigint,
    comments text NOT NULL,
    mark_utilized boolean NOT NULL,
    mark_populated boolean NOT NULL
);


--
-- Name: ipam_prefix; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_prefix (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_prefix_id_seq'::regclass) NOT NULL,
    prefix cidr NOT NULL,
    status character varying(50) NOT NULL,
    is_pool boolean NOT NULL,
    description character varying(200) NOT NULL,
    role_id bigint,
    tenant_id bigint,
    vlan_id bigint,
    vrf_id bigint,
    _children bigint NOT NULL,
    _depth smallint NOT NULL,
    mark_utilized boolean NOT NULL,
    comments text NOT NULL,
    scope_id bigint,
    scope_type_id integer,
    _location_id bigint,
    _region_id bigint,
    _site_id bigint,
    _site_group_id bigint
);


--
-- Name: ipam_rir; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_rir (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_rir_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    is_private boolean NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: ipam_role; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_role (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_role_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    weight smallint NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: ipam_routetarget; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_routetarget (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_routetarget_id_seq'::regclass) NOT NULL,
    name character varying(21) NOT NULL COLLATE public.natural_sort,
    description character varying(200) NOT NULL,
    tenant_id bigint,
    comments text NOT NULL
);


--
-- Name: ipam_service; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_service (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_service_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    protocol character varying(50) NOT NULL,
    ports integer[] NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    parent_object_id bigint NOT NULL,
    parent_object_type_id integer NOT NULL
);


--
-- Name: ipam_service_ipaddresses; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_service_ipaddresses (
    id bigint DEFAULT nextval('public.ipam_service_ipaddresses_id_seq'::regclass) NOT NULL,
    service_id bigint NOT NULL,
    ipaddress_id bigint NOT NULL
);


--
-- Name: ipam_servicetemplate; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_servicetemplate (
    id bigint DEFAULT nextval('public.ipam_servicetemplate_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    protocol character varying(50) NOT NULL,
    ports integer[] NOT NULL,
    description character varying(200) NOT NULL,
    name character varying(100) NOT NULL,
    comments text NOT NULL
);


--
-- Name: ipam_vlan; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_vlan (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_vlan_id_seq'::regclass) NOT NULL,
    vid smallint NOT NULL,
    name character varying(64) NOT NULL,
    status character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    group_id bigint,
    role_id bigint,
    site_id bigint,
    tenant_id bigint,
    comments text NOT NULL,
    qinq_role character varying(50),
    qinq_svlan_id bigint
);


--
-- Name: ipam_vlangroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_vlangroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_vlangroup_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    scope_id bigint,
    description character varying(200) NOT NULL,
    scope_type_id integer,
    vid_ranges int4range[] NOT NULL,
    _total_vlan_ids bigint NOT NULL,
    tenant_id bigint
);


--
-- Name: ipam_vlantranslationpolicy; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_vlantranslationpolicy (
    id bigint DEFAULT nextval('public.ipam_vlantranslationpolicy_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: ipam_vlantranslationrule; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_vlantranslationrule (
    id bigint DEFAULT nextval('public.ipam_vlantranslationrule_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    local_vid smallint NOT NULL,
    remote_vid smallint NOT NULL,
    policy_id bigint NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: ipam_vrf; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_vrf (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.ipam_vrf_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    rd character varying(21),
    enforce_unique boolean NOT NULL,
    description character varying(200) NOT NULL,
    tenant_id bigint,
    comments text NOT NULL
);


--
-- Name: ipam_vrf_export_targets; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_vrf_export_targets (
    id bigint DEFAULT nextval('public.ipam_vrf_export_targets_id_seq'::regclass) NOT NULL,
    vrf_id bigint NOT NULL,
    routetarget_id bigint NOT NULL
);


--
-- Name: ipam_vrf_import_targets; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.ipam_vrf_import_targets (
    id bigint DEFAULT nextval('public.ipam_vrf_import_targets_id_seq'::regclass) NOT NULL,
    vrf_id bigint NOT NULL,
    routetarget_id bigint NOT NULL
);


--
-- Name: tenancy_contact; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.tenancy_contact (
    id bigint DEFAULT nextval('public.tenancy_contact_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    title character varying(100) NOT NULL,
    phone character varying(50) NOT NULL,
    email character varying(254) NOT NULL,
    address character varying(200) NOT NULL,
    comments text NOT NULL,
    link character varying(200) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: tenancy_contact_groups; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.tenancy_contact_groups (
    id bigint DEFAULT nextval('public.tenancy_contact_groups_id_seq'::regclass) NOT NULL,
    contact_id bigint NOT NULL,
    contactgroup_id bigint NOT NULL
);


--
-- Name: tenancy_contactassignment; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.tenancy_contactassignment (
    id bigint DEFAULT nextval('public.tenancy_contactassignment_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    object_id bigint NOT NULL,
    priority character varying(50),
    contact_id bigint NOT NULL,
    object_type_id integer NOT NULL,
    role_id bigint NOT NULL,
    custom_field_data jsonb NOT NULL
);


--
-- Name: tenancy_contactgroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.tenancy_contactgroup (
    id bigint DEFAULT nextval('public.tenancy_contactgroup_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id bigint,
    comments text NOT NULL
);


--
-- Name: tenancy_contactrole; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.tenancy_contactrole (
    id bigint DEFAULT nextval('public.tenancy_contactrole_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: tenancy_tenant; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.tenancy_tenant (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.tenancy_tenant_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    group_id bigint
);


--
-- Name: tenancy_tenantgroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.tenancy_tenantgroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.tenancy_tenantgroup_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id bigint,
    comments text NOT NULL
);


--
-- Name: virtualization_cluster; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.virtualization_cluster (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.virtualization_cluster_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    comments text NOT NULL,
    group_id bigint,
    tenant_id bigint,
    type_id bigint NOT NULL,
    status character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    scope_id bigint,
    scope_type_id integer,
    _location_id bigint,
    _region_id bigint,
    _site_id bigint,
    _site_group_id bigint
);


--
-- Name: virtualization_clustergroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.virtualization_clustergroup (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.virtualization_clustergroup_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: virtualization_clustertype; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.virtualization_clustertype (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.virtualization_clustertype_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: virtualization_virtualdisk; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.virtualization_virtualdisk (
    id bigint DEFAULT nextval('public.virtualization_virtualdisk_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    description character varying(200) NOT NULL,
    size integer NOT NULL,
    virtual_machine_id bigint NOT NULL
);


--
-- Name: virtualization_virtualmachine; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.virtualization_virtualmachine (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.virtualization_virtualmachine_id_seq'::regclass) NOT NULL,
    local_context_data jsonb,
    name character varying(64) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    vcpus numeric(6,2),
    memory integer,
    disk integer,
    comments text NOT NULL,
    cluster_id bigint,
    platform_id bigint,
    primary_ip4_id bigint,
    primary_ip6_id bigint,
    role_id bigint,
    tenant_id bigint,
    site_id bigint,
    device_id bigint,
    description character varying(200) NOT NULL,
    interface_count bigint NOT NULL,
    config_template_id bigint,
    virtual_disk_count bigint NOT NULL,
    serial character varying(50) NOT NULL
);


--
-- Name: virtualization_vminterface; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.virtualization_vminterface (
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    id bigint DEFAULT nextval('public.virtualization_vminterface_id_seq'::regclass) NOT NULL,
    enabled boolean NOT NULL,
    mtu integer,
    mode character varying(50),
    name character varying(64) NOT NULL,
    _name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    parent_id bigint,
    untagged_vlan_id bigint,
    virtual_machine_id bigint NOT NULL,
    bridge_id bigint,
    vrf_id bigint,
    vlan_translation_policy_id bigint,
    qinq_svlan_id bigint,
    primary_mac_address_id bigint
);


--
-- Name: virtualization_vminterface_tagged_vlans; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.virtualization_vminterface_tagged_vlans (
    id bigint DEFAULT nextval('public.virtualization_vminterface_tagged_vlans_id_seq'::regclass) NOT NULL,
    vminterface_id bigint NOT NULL,
    vlan_id bigint NOT NULL
);


--
-- Name: vpn_ikepolicy; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_ikepolicy (
    id bigint DEFAULT nextval('public.vpn_ikepolicy_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    version smallint NOT NULL,
    mode character varying,
    preshared_key text NOT NULL
);


--
-- Name: vpn_ikepolicy_proposals; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_ikepolicy_proposals (
    id bigint DEFAULT nextval('public.vpn_ikepolicy_proposals_id_seq'::regclass) NOT NULL,
    ikepolicy_id bigint NOT NULL,
    ikeproposal_id bigint NOT NULL
);


--
-- Name: vpn_ikeproposal; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_ikeproposal (
    id bigint DEFAULT nextval('public.vpn_ikeproposal_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    authentication_method character varying NOT NULL,
    encryption_algorithm character varying NOT NULL,
    authentication_algorithm character varying,
    "group" smallint NOT NULL,
    sa_lifetime integer
);


--
-- Name: vpn_ipsecpolicy; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_ipsecpolicy (
    id bigint DEFAULT nextval('public.vpn_ipsecpolicy_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    pfs_group smallint
);


--
-- Name: vpn_ipsecpolicy_proposals; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_ipsecpolicy_proposals (
    id bigint DEFAULT nextval('public.vpn_ipsecpolicy_proposals_id_seq'::regclass) NOT NULL,
    ipsecpolicy_id bigint NOT NULL,
    ipsecproposal_id bigint NOT NULL
);


--
-- Name: vpn_ipsecprofile; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_ipsecprofile (
    id bigint DEFAULT nextval('public.vpn_ipsecprofile_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    mode character varying NOT NULL,
    ike_policy_id bigint NOT NULL,
    ipsec_policy_id bigint NOT NULL
);


--
-- Name: vpn_ipsecproposal; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_ipsecproposal (
    id bigint DEFAULT nextval('public.vpn_ipsecproposal_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    encryption_algorithm character varying,
    authentication_algorithm character varying,
    sa_lifetime_seconds integer,
    sa_lifetime_data integer
);


--
-- Name: vpn_l2vpn; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_l2vpn (
    id bigint DEFAULT nextval('public.vpn_l2vpn_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    identifier bigint,
    description character varying(200) NOT NULL,
    tenant_id bigint,
    comments text NOT NULL,
    status character varying(50) NOT NULL
);


--
-- Name: vpn_l2vpn_export_targets; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_l2vpn_export_targets (
    id bigint DEFAULT nextval('public.vpn_l2vpn_export_targets_id_seq'::regclass) NOT NULL,
    l2vpn_id bigint NOT NULL,
    routetarget_id bigint NOT NULL
);


--
-- Name: vpn_l2vpn_import_targets; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_l2vpn_import_targets (
    id bigint DEFAULT nextval('public.vpn_l2vpn_import_targets_id_seq'::regclass) NOT NULL,
    l2vpn_id bigint NOT NULL,
    routetarget_id bigint NOT NULL
);


--
-- Name: vpn_l2vpntermination; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_l2vpntermination (
    id bigint DEFAULT nextval('public.vpn_l2vpntermination_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    assigned_object_id bigint NOT NULL,
    assigned_object_type_id integer NOT NULL,
    l2vpn_id bigint NOT NULL
);


--
-- Name: vpn_tunnel; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_tunnel (
    id bigint DEFAULT nextval('public.vpn_tunnel_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    description character varying(200) NOT NULL,
    comments text NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    status character varying(50) NOT NULL,
    group_id bigint,
    encapsulation character varying(50) NOT NULL,
    tunnel_id bigint,
    ipsec_profile_id bigint,
    tenant_id bigint
);


--
-- Name: vpn_tunnelgroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_tunnelgroup (
    id bigint DEFAULT nextval('public.vpn_tunnelgroup_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: vpn_tunneltermination; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.vpn_tunneltermination (
    id bigint DEFAULT nextval('public.vpn_tunneltermination_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    role character varying(50) NOT NULL,
    termination_id bigint,
    termination_type_id integer NOT NULL,
    outside_ip_id bigint,
    tunnel_id bigint NOT NULL
);


--
-- Name: wireless_wirelesslan; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.wireless_wirelesslan (
    id bigint DEFAULT nextval('public.wireless_wirelesslan_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    ssid character varying(32) NOT NULL,
    group_id bigint,
    description character varying(200) NOT NULL,
    auth_cipher character varying(50),
    auth_psk character varying(64) NOT NULL,
    auth_type character varying(50),
    vlan_id bigint,
    tenant_id bigint,
    comments text NOT NULL,
    status character varying(50) NOT NULL,
    _location_id bigint,
    _region_id bigint,
    _site_id bigint,
    _site_group_id bigint,
    scope_id bigint,
    scope_type_id integer
);


--
-- Name: wireless_wirelesslangroup; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.wireless_wirelesslangroup (
    id bigint DEFAULT nextval('public.wireless_wirelesslangroup_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    name character varying(100) NOT NULL COLLATE public.natural_sort,
    slug character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id bigint,
    comments text NOT NULL
);


--
-- Name: wireless_wirelesslink; Type: TABLE; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE TABLE __BRANCH_SCHEMA__.wireless_wirelesslink (
    id bigint DEFAULT nextval('public.wireless_wirelesslink_id_seq'::regclass) NOT NULL,
    created timestamp with time zone,
    last_updated timestamp with time zone,
    custom_field_data jsonb NOT NULL,
    ssid character varying(32) NOT NULL,
    status character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    auth_cipher character varying(50),
    auth_psk character varying(64) NOT NULL,
    auth_type character varying(50),
    _interface_a_device_id bigint,
    _interface_b_device_id bigint,
    interface_a_id bigint NOT NULL,
    interface_b_id bigint NOT NULL,
    tenant_id bigint,
    comments text NOT NULL,
    _abs_distance numeric(13,4),
    distance numeric(8,2),
    distance_unit character varying(50)
);


--
-- Data for Name: circuits_circuit; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_circuitgroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_circuitgroupassignment; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_circuittermination; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_circuittype; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_provider; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_provider_asns; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_provideraccount; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_providernetwork; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_virtualcircuit; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_virtualcircuittermination; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: circuits_virtualcircuittype; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: core_objectchange; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (1, '2026-05-05 16:54:45.626179-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Fixture Tag A', NULL, '{"name": "Fixture Tag A", "slug": "fixture-tag-a", "color": "9e9e9e", "weight": 1000, "created": "2026-05-05T23:54:45.618Z", "description": "", "object_types": []}', 102, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (2, '2026-05-05 16:54:45.665714-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 2, NULL, 'Fixture Tag B', NULL, '{"name": "Fixture Tag B", "slug": "fixture-tag-b", "color": "9e9e9e", "weight": 1000, "created": "2026-05-05T23:54:45.664Z", "description": "", "object_types": []}', 102, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (3, '2026-05-05 16:54:45.695764-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Acme Holdings', NULL, '{"lft": 1, "name": "Acme Holdings", "rght": 2, "slug": "acme-holdings", "tags": [], "level": 0, "parent": null, "created": "2026-05-05T23:54:45.692Z", "tree_id": 1, "comments": "", "description": "", "custom_fields": {}}', 126, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (4, '2026-05-05 16:54:45.73153-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 2, NULL, 'Acme Subsidiary', NULL, '{"lft": 2, "name": "Acme Subsidiary", "rght": 3, "slug": "acme-subsidiary", "tags": [], "level": 1, "parent": 1, "created": "2026-05-05T23:54:45.729Z", "tree_id": 1, "comments": "", "description": "", "custom_fields": {}}', 126, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (5, '2026-05-05 16:54:45.756161-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Acme Corp', NULL, '{"name": "Acme Corp", "slug": "acme-corp", "tags": ["Fixture Tag A"], "group": 2, "created": "2026-05-05T23:54:45.753Z", "comments": "", "description": "", "custom_fields": {}}', 127, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (6, '2026-05-05 16:54:45.804163-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test RIR', NULL, '{"name": "Test RIR", "slug": "test-rir", "tags": [], "created": "2026-05-05T23:54:45.801Z", "is_private": false, "description": "", "custom_fields": {}}', 90, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (7, '2026-05-05 16:54:45.838877-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'AS64512', NULL, '{"asn": 64512, "rir": 1, "tags": [], "tenant": null, "created": "2026-05-05T23:54:45.836Z", "comments": "", "description": "", "custom_fields": {}}', 85, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (8, '2026-05-05 16:54:45.85858-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 2, NULL, 'AS64513', NULL, '{"asn": 64513, "rir": 1, "tags": [], "tenant": null, "created": "2026-05-05T23:54:45.857Z", "comments": "", "description": "", "custom_fields": {}}', 85, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (9, '2026-05-05 16:54:45.879822-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'North America', NULL, '{"lft": 1, "name": "North America", "rght": 2, "slug": "north-america", "tags": [], "level": 0, "parent": null, "created": "2026-05-05T23:54:45.877Z", "tree_id": 1, "comments": "", "description": "", "custom_fields": {}}', 81, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (10, '2026-05-05 16:54:45.92892-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 2, NULL, 'United States', NULL, '{"lft": 2, "name": "United States", "rght": 3, "slug": "united-states", "tags": [], "level": 1, "parent": 1, "created": "2026-05-05T23:54:45.927Z", "tree_id": 1, "comments": "", "description": "", "custom_fields": {}}', 81, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (11, '2026-05-05 16:54:45.948994-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Datacenters', NULL, '{"lft": 1, "name": "Datacenters", "rght": 2, "slug": "datacenters", "tags": [], "level": 0, "parent": null, "created": "2026-05-05T23:54:45.946Z", "tree_id": 1, "comments": "", "description": "", "custom_fields": {}}', 82, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (12, '2026-05-05 16:54:45.968277-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 2, NULL, 'Edge', NULL, '{"lft": 2, "name": "Edge", "rght": 3, "slug": "edge", "tags": [], "level": 1, "parent": 1, "created": "2026-05-05T23:54:45.967Z", "tree_id": 1, "comments": "", "description": "", "custom_fields": {}}', 82, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (13, '2026-05-05 16:54:45.99007-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test Site', NULL, '{"asns": [1, 2], "name": "Test Site", "slug": "test-site", "tags": ["Fixture Tag A", "Fixture Tag B"], "group": 2, "region": 2, "status": "active", "tenant": 1, "created": "2026-05-05T23:54:45.986Z", "comments": "", "facility": "", "latitude": null, "longitude": null, "time_zone": null, "description": "", "custom_fields": {}, "physical_address": "", "shipping_address": ""}', 6, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (14, '2026-05-05 16:54:46.101468-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Building A', NULL, '{"lft": 1, "name": "Building A", "rght": 2, "site": 1, "slug": "bldg-a", "tags": [], "level": 0, "parent": null, "status": "active", "tenant": null, "created": "2026-05-05T23:54:46.098Z", "tree_id": 1, "comments": "", "facility": "", "description": "", "custom_fields": {}}', 83, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (15, '2026-05-05 16:54:46.134028-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 2, NULL, 'Floor 1', NULL, '{"lft": 2, "name": "Floor 1", "rght": 3, "site": 1, "slug": "floor-1", "tags": [], "level": 1, "parent": 1, "status": "active", "tenant": null, "created": "2026-05-05T23:54:46.132Z", "tree_id": 1, "comments": "", "facility": "", "description": "", "custom_fields": {}}', 83, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (16, '2026-05-05 16:54:46.168463-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 3, NULL, 'Room 101', NULL, '{"lft": 3, "name": "Room 101", "rght": 4, "site": 1, "slug": "room-101", "tags": [], "level": 2, "parent": 2, "status": "active", "tenant": null, "created": "2026-05-05T23:54:46.166Z", "tree_id": 1, "comments": "", "facility": "", "description": "", "custom_fields": {}}', 83, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (17, '2026-05-05 16:54:46.213378-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Cisco', NULL, '{"name": "Cisco", "slug": "cisco", "tags": [], "created": "2026-05-05T23:54:46.208Z", "description": "", "custom_fields": {}}', 68, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (18, '2026-05-05 16:54:46.257851-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test Device Type', NULL, '{"slug": "test-device-type", "tags": [], "model": "Test Device Type", "weight": null, "airflow": null, "created": "2026-05-05T23:54:46.253Z", "comments": "", "u_height": 1.0, "rear_image": "", "_abs_weight": null, "description": "", "front_image": "", "part_number": "", "weight_unit": null, "manufacturer": 1, "custom_fields": {}, "is_full_depth": true, "subdevice_role": null, "default_platform": null, "exclude_from_utilization": false, "interface_template_count": 0, "rear_port_template_count": 0, "device_bay_template_count": 0, "front_port_template_count": 0, "module_bay_template_count": 0, "power_port_template_count": 0, "console_port_template_count": 0, "power_outlet_template_count": 0, "inventory_item_template_count": 0, "console_server_port_template_count": 0}', 69, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (19, '2026-05-05 16:54:46.300399-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test Role', NULL, '{"lft": 1, "name": "Test Role", "rght": 2, "slug": "test-role", "tags": [], "color": "9e9e9e", "level": 0, "parent": null, "created": "2026-05-05T23:54:46.296Z", "tree_id": 1, "vm_role": true, "comments": "", "description": "", "custom_fields": {}, "config_template": null}', 70, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (20, '2026-05-05 16:54:46.348018-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test Platform', NULL, '{"lft": 1, "name": "Test Platform", "rght": 2, "slug": "test-platform", "tags": [], "level": 0, "parent": null, "created": "2026-05-05T23:54:46.344Z", "tree_id": 1, "comments": "", "description": "", "manufacturer": 1, "custom_fields": {}, "config_template": null}', 71, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (21, '2026-05-05 16:54:46.379276-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, 1, 'Rear1', NULL, '{"name": "Rear1", "type": "lc", "color": "", "label": "", "created": "2026-05-05T23:54:46.377Z", "positions": 1, "description": "", "device_type": 1, "module_type": null}', 62, 69, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (22, '2026-05-05 16:54:46.445211-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, 1, 'Front1', NULL, '{"name": "Front1", "type": "lc", "color": "", "label": "", "created": "2026-05-05T23:54:46.440Z", "rear_port": 1, "description": "", "device_type": 1, "module_type": null, "rear_port_position": 1}', 61, 69, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (23, '2026-05-05 16:54:46.483168-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Rack-01', NULL, '{"name": "Rack-01", "role": null, "site": 1, "tags": [], "width": 19, "serial": "", "status": "active", "tenant": null, "weight": null, "airflow": null, "created": "2026-05-05T23:54:46.475Z", "comments": "", "location": 3, "u_height": 42, "asset_tag": null, "rack_type": null, "desc_units": false, "max_weight": null, "outer_unit": null, "_abs_weight": null, "description": "", "facility_id": null, "form_factor": null, "outer_depth": null, "outer_width": null, "weight_unit": null, "outer_height": null, "custom_fields": {}, "starting_unit": 1, "mounting_depth": null, "_abs_max_weight": null}', 79, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (25, '2026-05-05 16:54:46.631718-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, 1, 'Rear1', NULL, '{"name": "Rear1", "tags": [], "type": "lc", "_rack": 1, "_site": 1, "cable": null, "color": "", "label": "", "device": 1, "module": null, "created": "2026-05-05T23:54:46.597Z", "_location": 3, "cable_end": null, "positions": 1, "description": "", "custom_fields": {}, "mark_connected": false}', 48, 12, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (26, '2026-05-05 16:54:46.698102-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, 1, 'Front1', NULL, '{"name": "Front1", "tags": [], "type": "lc", "_rack": 1, "_site": 1, "cable": null, "color": "", "label": "", "device": 1, "module": null, "created": "2026-05-05T23:54:46.684Z", "_location": 3, "cable_end": null, "rear_port": 1, "description": "", "custom_fields": {}, "mark_connected": false, "rear_port_position": 1}', 47, 12, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (24, '2026-05-05 16:54:46.533387-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test Device', NULL, '{"face": null, "name": "Test Device", "rack": 1, "role": 1, "site": 1, "tags": ["Fixture Tag A", "Fixture Tag B"], "oob_ip": null, "serial": "", "status": "active", "tenant": 1, "airflow": null, "cluster": null, "created": "2026-05-05T23:54:46.526Z", "comments": "", "latitude": null, "location": 3, "platform": 1, "position": null, "asset_tag": null, "longitude": null, "description": "", "device_type": 1, "primary_ip4": null, "primary_ip6": null, "vc_position": null, "vc_priority": null, "custom_fields": {}, "config_template": null, "interface_count": 0, "rear_port_count": 0, "virtual_chassis": null, "device_bay_count": 0, "front_port_count": 0, "module_bay_count": 0, "power_port_count": 0, "console_port_count": 0, "local_context_data": null, "power_outlet_count": 0, "inventory_item_count": 0, "console_server_port_count": 0}', 12, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (27, '2026-05-05 16:54:46.853315-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, 1, 'eth0', NULL, '{"lag": null, "mtu": null, "vrf": null, "wwn": null, "mode": null, "name": "eth0", "tags": ["Fixture Tag A"], "type": "1000base-t", "vdcs": [], "_name": "9999999999999999eth000000............", "_path": null, "_rack": 1, "_site": 1, "cable": null, "label": "", "speed": null, "bridge": null, "device": 1, "duplex": null, "module": null, "parent": null, "created": "2026-05-05T23:54:46.826Z", "enabled": true, "rf_role": null, "poe_mode": null, "poe_type": null, "tx_power": null, "_location": 3, "cable_end": null, "mgmt_only": false, "qinq_svlan": null, "rf_channel": null, "description": "", "tagged_vlans": [], "custom_fields": {}, "untagged_vlan": null, "wireless_lans": [], "wireless_link": null, "mark_connected": false, "rf_channel_width": null, "primary_mac_address": null, "rf_channel_frequency": null, "vlan_translation_policy": null}', 9, 12, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (28, '2026-05-05 16:54:47.068572-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test VRF (65000:1)', NULL, '{"rd": "65000:1", "name": "Test VRF", "tags": [], "tenant": 1, "created": "2026-05-05T23:54:47.054Z", "comments": "", "description": "", "custom_fields": {}, "enforce_unique": true, "export_targets": [], "import_targets": []}', 88, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (29, '2026-05-05 16:54:47.164944-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, '10.0.0.0/8', NULL, '{"rir": 1, "tags": [], "prefix": "10.0.0.0/8", "tenant": 1, "created": "2026-05-05T23:54:47.152Z", "comments": "", "date_added": null, "description": "", "custom_fields": {}}', 91, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (30, '2026-05-05 16:54:47.244076-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, '10.0.0.0/24', NULL, '{"vrf": 1, "role": null, "tags": [], "vlan": null, "_site": 1, "_depth": 0, "prefix": "10.0.0.0/24", "status": "active", "tenant": 1, "_region": 2, "created": "2026-05-05T23:54:47.227Z", "is_pool": false, "comments": "", "scope_id": 1, "_children": 0, "_location": null, "scope_type": 6, "_site_group": 2, "description": "", "custom_fields": {}, "mark_utilized": false}', 93, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (31, '2026-05-05 16:54:47.313167-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, 1, '10.0.0.1/24', NULL, '{"vrf": 1, "role": null, "tags": [], "status": "active", "tenant": 1, "address": "10.0.0.1/24", "created": "2026-05-05T23:54:47.306Z", "comments": "", "dns_name": "", "nat_inside": null, "description": "", "custom_fields": {}, "assigned_object_id": 1, "assigned_object_type": 9}', 95, 9, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (32, '2026-05-05 16:54:47.383129-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test VLAN Group', NULL, '{"name": "Test VLAN Group", "slug": "test-vlan-group", "tags": [], "tenant": null, "created": "2026-05-05T23:54:47.370Z", "scope_id": null, "scope_type": null, "vid_ranges": "[\"{\\\"bounds\\\": \\\"[]\\\", \\\"lower\\\": \\\"1\\\", \\\"upper\\\": \\\"4094\\\"}\"]", "description": "", "custom_fields": {}, "_total_vlan_ids": 4093}', 98, NULL, 1, '');
INSERT INTO __BRANCH_SCHEMA__.core_objectchange VALUES (33, '2026-05-05 16:54:47.443437-07', '_fixture_admin', '48471ac2-8b84-49a7-8118-5bf3bf885bae', 'create', 1, NULL, 'Test VLAN (100)', NULL, '{"vid": 100, "name": "Test VLAN", "role": null, "site": null, "tags": [], "group": 1, "status": "active", "tenant": 1, "created": "2026-05-05T23:54:47.431Z", "comments": "", "qinq_role": null, "qinq_svlan": null, "description": "", "custom_fields": {}}', 99, NULL, 1, '');


--
-- Data for Name: dcim_cable; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_cablepath; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_cabletermination; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_consoleport; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_consoleporttemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_consoleserverport; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_consoleserverporttemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_device; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_device VALUES ('2026-05-05 16:54:46.526023-07', '2026-05-05 16:54:46.52603-07', '{}', 1, NULL, 'Test Device', '', NULL, NULL, NULL, 'active', NULL, NULL, '', NULL, 1, 1, 3, 1, NULL, NULL, 1, 1, 1, NULL, NULL, '', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0);


--
-- Data for Name: dcim_devicebay; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_devicebaytemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_devicerole; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_devicerole VALUES ('2026-05-05 16:54:46.296888-07', '2026-05-05 16:54:46.296895-07', '{}', 1, 'Test Role', 'test-role', '9e9e9e', true, '', NULL, 0, 1, 2, 1, NULL, '');


--
-- Data for Name: dcim_devicetype; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_devicetype VALUES ('2026-05-05 16:54:46.253031-07', '2026-05-05 16:54:46.253044-07', '{}', 1, 'Test Device Type', 'test-device-type', '', 1.0, true, NULL, '', '', '', 1, NULL, NULL, NULL, NULL, '', NULL, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, false);


--
-- Data for Name: dcim_frontport; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_frontport VALUES ('2026-05-05 16:54:46.68491-07', '2026-05-05 16:54:46.684924-07', '{}', 1, 'Front1', '', '', false, 'lc', 1, NULL, 1, 1, '', NULL, NULL, 3, 1, 1);


--
-- Data for Name: dcim_frontporttemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_frontporttemplate VALUES ('2026-05-05 16:54:46.440983-07', '2026-05-05 16:54:46.440997-07', 1, 'Front1', '', '', 'lc', 1, 1, 1, '', NULL);


--
-- Data for Name: dcim_interface; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_interface VALUES ('2026-05-05 16:54:46.826903-07', '2026-05-05 16:54:46.826921-07', '{}', 1, 'eth0', '', '', false, true, NULL, NULL, '9999999999999999eth000000............', '1000base-t', false, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 1, 1);


--
-- Data for Name: dcim_interface_tagged_vlans; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_interface_vdcs; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_interface_wireless_lans; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_interfacetemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_inventoryitem; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_inventoryitemrole; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_inventoryitemtemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_location; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_location VALUES ('2026-05-05 16:54:46.098117-07', '2026-05-05 16:54:46.098126-07', '{}', 1, 'Building A', 'bldg-a', '', 1, 6, 1, 0, NULL, 1, NULL, 'active', '', '');
INSERT INTO __BRANCH_SCHEMA__.dcim_location VALUES ('2026-05-05 16:54:46.132537-07', '2026-05-05 16:54:46.132545-07', '{}', 2, 'Floor 1', 'floor-1', '', 2, 5, 1, 1, 1, 1, NULL, 'active', '', '');
INSERT INTO __BRANCH_SCHEMA__.dcim_location VALUES ('2026-05-05 16:54:46.166647-07', '2026-05-05 16:54:46.166653-07', '{}', 3, 'Room 101', 'room-101', '', 3, 4, 1, 2, 2, 1, NULL, 'active', '', '');


--
-- Data for Name: dcim_macaddress; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_manufacturer; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_manufacturer VALUES ('2026-05-05 16:54:46.208425-07', '2026-05-05 16:54:46.208434-07', '{}', 1, 'Cisco', 'cisco', '');


--
-- Data for Name: dcim_module; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_modulebay; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_modulebaytemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_moduletype; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_moduletypeprofile; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_moduletypeprofile VALUES (1, '2026-05-05 16:53:53.389124-07', '2026-05-05 16:53:53.389135-07', '{}', '', '', 'CPU', '{"properties": {"cores": {"type": "integer", "description": "Number of cores present"}, "speed": {"type": "number", "title": "Speed", "description": "Clock speed in GHz"}, "architecture": {"type": "string", "title": "Architecture"}}}');
INSERT INTO __BRANCH_SCHEMA__.dcim_moduletypeprofile VALUES (2, '2026-05-05 16:53:53.408224-07', '2026-05-05 16:53:53.408231-07', '{}', '', '', 'Fan', '{"properties": {"rpm": {"type": "integer", "title": "RPM", "description": "Fan speed (RPM)"}}}');
INSERT INTO __BRANCH_SCHEMA__.dcim_moduletypeprofile VALUES (3, '2026-05-05 16:53:53.415508-07', '2026-05-05 16:53:53.415512-07', '{}', '', '', 'GPU', '{"required": ["memory"], "properties": {"gpu": {"type": "string", "title": "GPU"}, "memory": {"type": "integer", "title": "Memory (GB)", "description": "Total memory capacity (in GB)"}, "interface": {"enum": ["PCIe 4.0", "PCIe 4.0 x8", "PCIe 4.0 x16", "PCIe 5.0 x16"], "type": "string"}}}');
INSERT INTO __BRANCH_SCHEMA__.dcim_moduletypeprofile VALUES (4, '2026-05-05 16:53:53.422101-07', '2026-05-05 16:53:53.422105-07', '{}', '', '', 'Hard disk', '{"required": ["size"], "properties": {"size": {"type": "integer", "title": "Size (GB)", "description": "Raw disk capacity"}, "type": {"enum": ["HD", "SSD", "NVME"], "type": "string", "title": "Disk type", "default": "SSD"}, "speed": {"type": "integer", "title": "Speed (RPM)"}}}');
INSERT INTO __BRANCH_SCHEMA__.dcim_moduletypeprofile VALUES (5, '2026-05-05 16:53:53.428156-07', '2026-05-05 16:53:53.428162-07', '{}', '', '', 'Memory', '{"required": ["class", "size"], "properties": {"ecc": {"type": "boolean", "title": "ECC", "description": "Error-correcting code is enabled"}, "size": {"type": "integer", "title": "Size (GB)", "description": "Raw capacity of the module"}, "class": {"enum": ["DDR3", "DDR4", "DDR5"], "type": "string", "title": "Memory class", "default": "DDR5"}, "data_rate": {"type": "integer", "title": "Data rate", "description": "Speed in MT/s"}}}');
INSERT INTO __BRANCH_SCHEMA__.dcim_moduletypeprofile VALUES (6, '2026-05-05 16:53:53.434504-07', '2026-05-05 16:53:53.434509-07', '{}', '', '', 'Power supply', '{"required": ["input_current", "input_voltage"], "properties": {"wattage": {"type": "integer", "description": "Available output power (watts)"}, "hot_swappable": {"type": "boolean", "title": "Hot-swappable", "default": false}, "input_current": {"enum": ["AC", "DC"], "type": "string", "title": "Current type", "default": "AC"}, "input_voltage": {"type": "integer", "title": "Voltage", "default": 120}}}');
INSERT INTO __BRANCH_SCHEMA__.dcim_moduletypeprofile VALUES (7, '2026-05-05 16:53:53.440195-07', '2026-05-05 16:53:53.440199-07', '{}', '', '', 'Expansion card', '{"properties": {"bandwidth": {"type": "integer", "description": "Total Bandwidth for this module"}, "connector_type": {"type": "string", "description": "Connector type e.g. PCIe x4"}}}');


--
-- Data for Name: dcim_platform; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_platform VALUES ('2026-05-05 16:54:46.344658-07', '2026-05-05 16:54:46.344666-07', '{}', 1, 'Test Platform', 'test-platform', '', 1, NULL, NULL, 0, 1, 2, 1, '');


--
-- Data for Name: dcim_powerfeed; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_poweroutlet; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_poweroutlettemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_powerpanel; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_powerport; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_powerporttemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_rack; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_rack VALUES ('2026-05-05 16:54:46.47553-07', '2026-05-05 16:54:46.475541-07', '{}', 1, 'Rack-01', NULL, 'active', '', NULL, NULL, 19, 42, false, NULL, NULL, NULL, '', 3, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 1, NULL, NULL, NULL);


--
-- Data for Name: dcim_rackreservation; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_rackrole; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_racktype; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_rearport; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_rearport VALUES ('2026-05-05 16:54:46.597232-07', '2026-05-05 16:54:46.597241-07', '{}', 1, 'Rear1', '', '', false, 'lc', 1, NULL, 1, '', NULL, NULL, 3, 1, 1);


--
-- Data for Name: dcim_rearporttemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_rearporttemplate VALUES ('2026-05-05 16:54:46.377252-07', '2026-05-05 16:54:46.377262-07', 1, 'Rear1', '', '', 'lc', 1, 1, '', NULL);


--
-- Data for Name: dcim_region; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_region VALUES ('2026-05-05 16:54:45.87723-07', '2026-05-05 16:54:45.877238-07', '{}', 1, 'North America', 'north-america', '', 1, 4, 1, 0, NULL, '');
INSERT INTO __BRANCH_SCHEMA__.dcim_region VALUES ('2026-05-05 16:54:45.927451-07', '2026-05-05 16:54:45.927458-07', '{}', 2, 'United States', 'united-states', '', 2, 3, 1, 1, 1, '');


--
-- Data for Name: dcim_site; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_site VALUES ('2026-05-05 16:54:45.986391-07', '2026-05-05 16:54:45.986398-07', '{}', 1, 'Test Site', 'test-site', 'active', '', '', '', '', '', NULL, NULL, '', 2, 2, 1);


--
-- Data for Name: dcim_site_asns; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_site_asns VALUES (1, 1, 1);
INSERT INTO __BRANCH_SCHEMA__.dcim_site_asns VALUES (2, 1, 2);


--
-- Data for Name: dcim_sitegroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.dcim_sitegroup VALUES ('2026-05-05 16:54:45.946964-07', '2026-05-05 16:54:45.946972-07', '{}', 1, 'Datacenters', 'datacenters', '', 1, 4, 1, 0, NULL, '');
INSERT INTO __BRANCH_SCHEMA__.dcim_sitegroup VALUES ('2026-05-05 16:54:45.967023-07', '2026-05-05 16:54:45.967029-07', '{}', 2, 'Edge', 'edge', '', 2, 3, 1, 1, 1, '');


--
-- Data for Name: dcim_virtualchassis; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: dcim_virtualdevicecontext; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (1, 'contenttypes', '0001_initial', '2026-05-05 16:52:46.76199-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (2, 'contenttypes', '0002_remove_content_type_name', '2026-05-05 16:52:46.766857-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (3, 'auth', '0001_initial', '2026-05-05 16:52:46.791321-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (4, 'auth', '0002_alter_permission_name_max_length', '2026-05-05 16:52:46.794679-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (5, 'auth', '0003_alter_user_email_max_length', '2026-05-05 16:52:46.797297-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (6, 'auth', '0004_alter_user_username_opts', '2026-05-05 16:52:46.799951-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (7, 'auth', '0005_alter_user_last_login_null', '2026-05-05 16:52:46.802774-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (8, 'auth', '0006_require_contenttypes_0002', '2026-05-05 16:52:46.803938-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (9, 'auth', '0007_alter_validators_add_error_messages', '2026-05-05 16:52:46.806713-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (10, 'auth', '0008_alter_user_username_max_length', '2026-05-05 16:52:46.809635-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (11, 'auth', '0009_alter_user_last_name_max_length', '2026-05-05 16:52:46.812692-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (12, 'auth', '0010_alter_group_name_max_length', '2026-05-05 16:52:46.816631-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (13, 'auth', '0011_update_proxy_permissions', '2026-05-05 16:52:46.819149-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (14, 'auth', '0012_alter_user_first_name_max_length', '2026-05-05 16:52:46.821907-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (15, 'users', '0001_api_tokens', '2026-05-05 16:52:46.89626-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (16, 'users', '0002_unicode_literals', '2026-05-05 16:52:46.897732-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (17, 'users', '0003_token_permissions', '2026-05-05 16:52:46.898125-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (18, 'users', '0004_standardize_description', '2026-05-05 16:52:46.898492-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (19, 'users', '0005_userconfig', '2026-05-05 16:52:46.898883-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (20, 'users', '0006_create_userconfigs', '2026-05-05 16:52:46.899223-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (21, 'users', '0007_proxy_group_user', '2026-05-05 16:52:46.89956-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (22, 'users', '0008_objectpermission', '2026-05-05 16:52:46.899892-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (23, 'users', '0009_replicate_permissions', '2026-05-05 16:52:46.900236-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (24, 'users', '0010_update_jsonfield', '2026-05-05 16:52:46.900573-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (25, 'users', '0011_standardize_models', '2026-05-05 16:52:46.90091-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (26, 'users', '0002_standardize_id_fields', '2026-05-05 16:52:46.936382-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (27, 'users', '0003_token_allowed_ips_last_used', '2026-05-05 16:52:46.936882-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (28, 'users', '0004_netboxgroup_netboxuser', '2026-05-05 16:52:46.937229-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (29, 'account', '0001_initial', '2026-05-05 16:52:46.940261-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (30, 'extras', '0001_initial', '2026-05-05 16:52:47.151516-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (31, 'tenancy', '0001_initial', '2026-05-05 16:52:47.173493-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (32, 'tenancy', '0002_tenant_group_optional', '2026-05-05 16:52:47.174065-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (33, 'tenancy', '0003_unicode_literals', '2026-05-05 16:52:47.174438-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (34, 'tenancy', '0004_tags', '2026-05-05 16:52:47.17479-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (35, 'tenancy', '0005_change_logging', '2026-05-05 16:52:47.175134-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (36, 'tenancy', '0006_custom_tag_models', '2026-05-05 16:52:47.17548-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (37, 'tenancy', '0007_nested_tenantgroups', '2026-05-05 16:52:47.175833-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (38, 'tenancy', '0008_nested_tenantgroups_rebuild', '2026-05-05 16:52:47.176175-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (39, 'tenancy', '0009_standardize_description', '2026-05-05 16:52:47.176526-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (40, 'tenancy', '0010_custom_field_data', '2026-05-05 16:52:47.176844-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (41, 'tenancy', '0011_standardize_name_length', '2026-05-05 16:52:47.17718-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (42, 'tenancy', '0012_standardize_models', '2026-05-05 16:52:47.177509-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (43, 'dcim', '0001_initial', '2026-05-05 16:52:47.343504-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (44, 'dcim', '0002_auto_20160622_1821', '2026-05-05 16:52:48.443544-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (45, 'ipam', '0001_initial', '2026-05-05 16:52:48.620288-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (46, 'virtualization', '0001_virtualization', '2026-05-05 16:52:48.888949-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (47, 'virtualization', '0002_virtualmachine_add_status', '2026-05-05 16:52:48.889805-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (48, 'virtualization', '0003_cluster_add_site', '2026-05-05 16:52:48.890134-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (49, 'virtualization', '0004_virtualmachine_add_role', '2026-05-05 16:52:48.890448-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (50, 'virtualization', '0005_django2', '2026-05-05 16:52:48.890752-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (51, 'virtualization', '0006_tags', '2026-05-05 16:52:48.891053-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (52, 'virtualization', '0007_change_logging', '2026-05-05 16:52:48.89135-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (53, 'virtualization', '0008_virtualmachine_local_context_data', '2026-05-05 16:52:48.891646-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (54, 'virtualization', '0009_custom_tag_models', '2026-05-05 16:52:48.891945-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (55, 'virtualization', '0010_cluster_add_tenant', '2026-05-05 16:52:48.892288-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (56, 'virtualization', '0011_3569_virtualmachine_fields', '2026-05-05 16:52:48.892638-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (57, 'virtualization', '0012_vm_name_nonunique', '2026-05-05 16:52:48.892978-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (58, 'virtualization', '0013_deterministic_ordering', '2026-05-05 16:52:48.893314-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (59, 'virtualization', '0014_standardize_description', '2026-05-05 16:52:48.893661-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (60, 'virtualization', '0015_vminterface', '2026-05-05 16:52:48.893995-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (61, 'virtualization', '0016_replicate_interfaces', '2026-05-05 16:52:48.894331-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (62, 'virtualization', '0017_update_jsonfield', '2026-05-05 16:52:48.894671-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (63, 'virtualization', '0018_custom_field_data', '2026-05-05 16:52:48.895006-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (64, 'virtualization', '0019_standardize_name_length', '2026-05-05 16:52:48.895342-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (65, 'virtualization', '0020_standardize_models', '2026-05-05 16:52:48.895678-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (66, 'virtualization', '0021_virtualmachine_vcpus_decimal', '2026-05-05 16:52:48.896019-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (67, 'virtualization', '0022_vminterface_parent', '2026-05-05 16:52:48.896359-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (68, 'extras', '0002_custom_fields', '2026-05-05 16:52:49.484193-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (69, 'extras', '0003_exporttemplate_add_description', '2026-05-05 16:52:49.485188-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (70, 'extras', '0004_topologymap_change_comma_to_semicolon', '2026-05-05 16:52:49.485517-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (71, 'extras', '0005_useraction_add_bulk_create', '2026-05-05 16:52:49.485826-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (72, 'extras', '0006_add_imageattachments', '2026-05-05 16:52:49.486118-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (73, 'extras', '0007_unicode_literals', '2026-05-05 16:52:49.486407-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (74, 'extras', '0008_reports', '2026-05-05 16:52:49.486697-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (75, 'extras', '0009_topologymap_type', '2026-05-05 16:52:49.487019-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (76, 'extras', '0010_customfield_filter_logic', '2026-05-05 16:52:49.487304-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (77, 'extras', '0011_django2', '2026-05-05 16:52:49.487584-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (78, 'extras', '0012_webhooks', '2026-05-05 16:52:49.487859-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (79, 'extras', '0013_objectchange', '2026-05-05 16:52:49.488138-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (80, 'extras', '0014_configcontexts', '2026-05-05 16:52:49.488407-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (81, 'extras', '0015_remove_useraction', '2026-05-05 16:52:49.488684-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (82, 'extras', '0016_exporttemplate_add_cable', '2026-05-05 16:52:49.488994-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (83, 'extras', '0017_exporttemplate_mime_type_length', '2026-05-05 16:52:49.489314-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (84, 'extras', '0018_exporttemplate_add_jinja2', '2026-05-05 16:52:49.489641-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (85, 'extras', '0019_tag_taggeditem', '2026-05-05 16:52:49.48996-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (86, 'extras', '0020_tag_data', '2026-05-05 16:52:49.490281-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (87, 'extras', '0021_add_color_comments_changelog_to_tag', '2026-05-05 16:52:49.490596-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (88, 'extras', '0022_custom_links', '2026-05-05 16:52:49.490916-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (89, 'extras', '0023_fix_tag_sequences', '2026-05-05 16:52:49.491236-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (90, 'extras', '0024_scripts', '2026-05-05 16:52:49.49155-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (91, 'extras', '0025_objectchange_time_index', '2026-05-05 16:52:49.491868-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (92, 'extras', '0026_webhook_ca_file_path', '2026-05-05 16:52:49.492186-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (93, 'extras', '0027_webhook_additional_headers', '2026-05-05 16:52:49.49251-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (94, 'extras', '0028_remove_topology_maps', '2026-05-05 16:52:49.492777-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (95, 'extras', '0029_3569_customfield_fields', '2026-05-05 16:52:49.493043-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (96, 'extras', '0030_3569_objectchange_fields', '2026-05-05 16:52:49.493328-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (97, 'extras', '0031_3569_exporttemplate_fields', '2026-05-05 16:52:49.493605-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (98, 'extras', '0032_3569_webhook_fields', '2026-05-05 16:52:49.493889-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (99, 'extras', '0033_graph_type_template_language', '2026-05-05 16:52:49.494174-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (100, 'extras', '0034_configcontext_tags', '2026-05-05 16:52:49.494448-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (101, 'extras', '0035_deterministic_ordering', '2026-05-05 16:52:49.49472-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (102, 'extras', '0036_contenttype_filters_to_q_objects', '2026-05-05 16:52:49.495142-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (103, 'extras', '0037_configcontexts_clusters', '2026-05-05 16:52:49.495422-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (104, 'extras', '0038_webhook_template_support', '2026-05-05 16:52:49.4957-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (105, 'extras', '0039_update_features_content_types', '2026-05-05 16:52:49.495978-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (106, 'extras', '0040_standardize_description', '2026-05-05 16:52:49.496262-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (107, 'extras', '0041_tag_description', '2026-05-05 16:52:49.496536-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (108, 'extras', '0042_customfield_manager', '2026-05-05 16:52:49.49685-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (109, 'extras', '0043_report', '2026-05-05 16:52:49.497162-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (110, 'extras', '0044_jobresult', '2026-05-05 16:52:49.497481-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (111, 'extras', '0045_configcontext_changelog', '2026-05-05 16:52:49.497802-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (112, 'extras', '0046_update_jsonfield', '2026-05-05 16:52:49.49834-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (113, 'extras', '0047_tag_ordering', '2026-05-05 16:52:49.498652-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (114, 'extras', '0048_exporttemplate_remove_template_language', '2026-05-05 16:52:49.498979-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (115, 'extras', '0049_remove_graph', '2026-05-05 16:52:49.4993-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (116, 'extras', '0050_customfield_changes', '2026-05-05 16:52:49.499624-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (117, 'extras', '0051_migrate_customfields', '2026-05-05 16:52:49.499937-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (118, 'extras', '0052_customfield_cleanup', '2026-05-05 16:52:49.500259-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (119, 'extras', '0053_rename_webhook_obj_type', '2026-05-05 16:52:49.500577-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (120, 'extras', '0054_standardize_models', '2026-05-05 16:52:49.500907-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (121, 'extras', '0055_objectchange_data', '2026-05-05 16:52:49.501186-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (122, 'extras', '0056_extend_configcontext', '2026-05-05 16:52:49.501476-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (123, 'extras', '0057_customlink_rename_fields', '2026-05-05 16:52:49.501755-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (124, 'extras', '0058_journalentry', '2026-05-05 16:52:49.502038-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (125, 'extras', '0059_exporttemplate_as_attachment', '2026-05-05 16:52:49.50232-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (126, 'tenancy', '0002_tenant_ordering', '2026-05-05 16:52:50.299902-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (127, 'tenancy', '0003_contacts', '2026-05-05 16:52:50.30436-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (128, 'tenancy', '0004_extend_tag_support', '2026-05-05 16:52:50.304727-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (129, 'tenancy', '0005_standardize_id_fields', '2026-05-05 16:52:50.3051-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (130, 'tenancy', '0006_created_datetimefield', '2026-05-05 16:52:50.30544-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (131, 'tenancy', '0007_contact_link', '2026-05-05 16:52:50.30579-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (132, 'tenancy', '0008_unique_constraints', '2026-05-05 16:52:50.306121-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (133, 'tenancy', '0009_standardize_description_comments', '2026-05-05 16:52:50.306438-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (134, 'tenancy', '0010_tenant_relax_uniqueness', '2026-05-05 16:52:50.306778-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (135, 'tenancy', '0011_contactassignment_tags', '2026-05-05 16:52:50.307087-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (136, 'dcim', '0003_auto_20160628_1721', '2026-05-05 16:52:53.167511-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (137, 'dcim', '0004_auto_20160701_2049', '2026-05-05 16:52:53.168205-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (138, 'dcim', '0005_auto_20160706_1722', '2026-05-05 16:52:53.168576-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (139, 'dcim', '0006_add_device_primary_ip4_ip6', '2026-05-05 16:52:53.16891-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (140, 'dcim', '0007_device_copy_primary_ip', '2026-05-05 16:52:53.169233-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (141, 'dcim', '0008_device_remove_primary_ip', '2026-05-05 16:52:53.169558-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (142, 'dcim', '0009_site_32bit_asn_support', '2026-05-05 16:52:53.169878-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (143, 'dcim', '0010_devicebay_installed_device_set_null', '2026-05-05 16:52:53.170244-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (144, 'dcim', '0011_devicetype_part_number', '2026-05-05 16:52:53.170576-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (145, 'dcim', '0012_site_rack_device_add_tenant', '2026-05-05 16:52:53.170896-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (146, 'dcim', '0013_add_interface_form_factors', '2026-05-05 16:52:53.171217-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (147, 'dcim', '0014_rack_add_type_width', '2026-05-05 16:52:53.171525-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (148, 'dcim', '0015_rack_add_u_height_validator', '2026-05-05 16:52:53.171836-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (149, 'dcim', '0016_module_add_manufacturer', '2026-05-05 16:52:53.172151-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (150, 'dcim', '0017_rack_add_role', '2026-05-05 16:52:53.172462-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (151, 'dcim', '0018_device_add_asset_tag', '2026-05-05 16:52:53.172781-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (152, 'dcim', '0019_new_iface_form_factors', '2026-05-05 16:52:53.173086-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (153, 'dcim', '0020_rack_desc_units', '2026-05-05 16:52:53.173401-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (154, 'dcim', '0021_add_ff_flexstack', '2026-05-05 16:52:53.173718-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (155, 'dcim', '0022_color_names_to_rgb', '2026-05-05 16:52:53.17404-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (156, 'dcim', '0023_devicetype_comments', '2026-05-05 16:52:53.174354-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (157, 'dcim', '0024_site_add_contact_fields', '2026-05-05 16:52:53.17468-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (158, 'dcim', '0025_devicetype_add_interface_ordering', '2026-05-05 16:52:53.174986-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (159, 'dcim', '0026_add_rack_reservations', '2026-05-05 16:52:53.1753-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (160, 'dcim', '0027_device_add_site', '2026-05-05 16:52:53.175611-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (161, 'dcim', '0028_device_copy_rack_to_site', '2026-05-05 16:52:53.175922-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (162, 'dcim', '0029_allow_rackless_devices', '2026-05-05 16:52:53.176247-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (163, 'dcim', '0030_interface_add_lag', '2026-05-05 16:52:53.176555-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (164, 'dcim', '0031_regions', '2026-05-05 16:52:53.17687-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (165, 'dcim', '0032_device_increase_name_length', '2026-05-05 16:52:53.177457-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (166, 'dcim', '0033_rackreservation_rack_editable', '2026-05-05 16:52:53.177764-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (167, 'dcim', '0034_rename_module_to_inventoryitem', '2026-05-05 16:52:53.178128-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (168, 'dcim', '0035_device_expand_status_choices', '2026-05-05 16:52:53.178455-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (169, 'dcim', '0036_add_ff_juniper_vcp', '2026-05-05 16:52:53.178773-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (170, 'dcim', '0037_unicode_literals', '2026-05-05 16:52:53.179086-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (171, 'dcim', '0038_wireless_interfaces', '2026-05-05 16:52:53.179403-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (172, 'dcim', '0039_interface_add_enabled_mtu', '2026-05-05 16:52:53.179709-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (173, 'dcim', '0040_inventoryitem_add_asset_tag_description', '2026-05-05 16:52:53.180029-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (174, 'dcim', '0041_napalm_integration', '2026-05-05 16:52:53.180355-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (175, 'dcim', '0042_interface_ff_10ge_cx4', '2026-05-05 16:52:53.180673-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (176, 'dcim', '0043_device_component_name_lengths', '2026-05-05 16:52:53.180981-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (177, 'dcim', '0044_virtualization', '2026-05-05 16:52:53.181285-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (178, 'dcim', '0045_devicerole_vm_role', '2026-05-05 16:52:53.181595-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (179, 'dcim', '0046_rack_lengthen_facility_id', '2026-05-05 16:52:53.181908-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (180, 'dcim', '0047_more_100ge_form_factors', '2026-05-05 16:52:53.182191-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (181, 'dcim', '0048_rack_serial', '2026-05-05 16:52:53.18248-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (182, 'dcim', '0049_rackreservation_change_user', '2026-05-05 16:52:53.182769-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (183, 'dcim', '0050_interface_vlan_tagging', '2026-05-05 16:52:53.183058-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (184, 'dcim', '0051_rackreservation_tenant', '2026-05-05 16:52:53.183339-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (185, 'dcim', '0052_virtual_chassis', '2026-05-05 16:52:53.183624-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (186, 'dcim', '0053_platform_manufacturer', '2026-05-05 16:52:53.183942-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (187, 'dcim', '0054_site_status_timezone_description', '2026-05-05 16:52:53.184281-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (188, 'dcim', '0055_virtualchassis_ordering', '2026-05-05 16:52:53.184573-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (189, 'dcim', '0056_django2', '2026-05-05 16:52:53.184859-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (190, 'dcim', '0057_tags', '2026-05-05 16:52:53.185143-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (191, 'dcim', '0058_relax_rack_naming_constraints', '2026-05-05 16:52:53.185436-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (192, 'dcim', '0059_site_latitude_longitude', '2026-05-05 16:52:53.185731-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (193, 'dcim', '0060_change_logging', '2026-05-05 16:52:53.186042-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (194, 'dcim', '0061_platform_napalm_args', '2026-05-05 16:52:53.186329-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (195, 'dcim', '0062_interface_mtu', '2026-05-05 16:52:53.186611-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (196, 'dcim', '0063_device_local_context_data', '2026-05-05 16:52:53.186892-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (197, 'dcim', '0064_remove_platform_rpc_client', '2026-05-05 16:52:53.187182-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (198, 'dcim', '0065_front_rear_ports', '2026-05-05 16:52:53.187462-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (199, 'dcim', '0066_cables', '2026-05-05 16:52:53.187742-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (200, 'dcim', '0067_device_type_remove_qualifiers', '2026-05-05 16:52:53.188024-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (201, 'dcim', '0068_rack_new_fields', '2026-05-05 16:52:53.18831-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (702, 'ipam', '0054_squashed_0067', '2026-05-05 16:54:18.633163-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (202, 'dcim', '0069_deprecate_nullablecharfield', '2026-05-05 16:52:53.188591-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (203, 'dcim', '0070_custom_tag_models', '2026-05-05 16:52:53.188908-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (204, 'dcim', '0071_device_components_add_description', '2026-05-05 16:52:53.189211-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (205, 'dcim', '0072_powerfeeds', '2026-05-05 16:52:53.189495-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (206, 'dcim', '0073_interface_form_factor_to_type', '2026-05-05 16:52:53.189784-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (207, 'dcim', '0074_increase_field_length_platform_name_slug', '2026-05-05 16:52:53.190055-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (208, 'dcim', '0075_cable_devices', '2026-05-05 16:52:53.190331-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (209, 'dcim', '0076_console_port_types', '2026-05-05 16:52:53.190599-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (210, 'dcim', '0077_power_types', '2026-05-05 16:52:53.190866-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (211, 'dcim', '0078_3569_site_fields', '2026-05-05 16:52:53.19114-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (212, 'dcim', '0079_3569_rack_fields', '2026-05-05 16:52:53.191411-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (213, 'dcim', '0080_3569_devicetype_fields', '2026-05-05 16:52:53.191678-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (214, 'dcim', '0081_3569_device_fields', '2026-05-05 16:52:53.191954-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (215, 'dcim', '0082_3569_interface_fields', '2026-05-05 16:52:53.192225-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (216, 'dcim', '0082_3569_port_fields', '2026-05-05 16:52:53.192497-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (217, 'dcim', '0083_3569_cable_fields', '2026-05-05 16:52:53.192763-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (218, 'dcim', '0084_3569_powerfeed_fields', '2026-05-05 16:52:53.193029-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (219, 'dcim', '0085_3569_poweroutlet_fields', '2026-05-05 16:52:53.1933-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (220, 'dcim', '0086_device_name_nonunique', '2026-05-05 16:52:53.193565-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (221, 'dcim', '0087_role_descriptions', '2026-05-05 16:52:53.193831-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (222, 'dcim', '0088_powerfeed_available_power', '2026-05-05 16:52:53.194068-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (223, 'dcim', '0089_deterministic_ordering', '2026-05-05 16:52:53.194348-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (224, 'dcim', '0090_cable_termination_models', '2026-05-05 16:52:53.194591-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (225, 'dcim', '0091_interface_type_other', '2026-05-05 16:52:53.194804-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (226, 'dcim', '0092_fix_rack_outer_unit', '2026-05-05 16:52:53.195018-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (227, 'dcim', '0093_device_component_ordering', '2026-05-05 16:52:53.195223-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (228, 'dcim', '0094_device_component_template_ordering', '2026-05-05 16:52:53.195458-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (229, 'dcim', '0095_primary_model_ordering', '2026-05-05 16:52:53.195689-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (230, 'dcim', '0096_interface_ordering', '2026-05-05 16:52:53.195896-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (231, 'dcim', '0097_interfacetemplate_type_other', '2026-05-05 16:52:53.196103-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (232, 'dcim', '0098_devicetype_images', '2026-05-05 16:52:53.196334-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (233, 'dcim', '0099_powerfeed_negative_voltage', '2026-05-05 16:52:53.196552-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (234, 'dcim', '0100_mptt_remove_indexes', '2026-05-05 16:52:53.19676-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (235, 'dcim', '0101_nested_rackgroups', '2026-05-05 16:52:53.196985-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (236, 'dcim', '0102_nested_rackgroups_rebuild', '2026-05-05 16:52:53.197206-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (237, 'dcim', '0103_standardize_description', '2026-05-05 16:52:53.197414-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (238, 'dcim', '0104_correct_infiniband_types', '2026-05-05 16:52:53.197621-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (239, 'dcim', '0105_interface_name_collation', '2026-05-05 16:52:53.19783-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (240, 'dcim', '0106_role_default_color', '2026-05-05 16:52:53.198038-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (241, 'dcim', '0107_component_labels', '2026-05-05 16:52:53.19842-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (242, 'dcim', '0108_add_tags', '2026-05-05 16:52:53.198621-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (243, 'dcim', '0109_interface_remove_vm', '2026-05-05 16:52:53.198831-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (244, 'dcim', '0110_virtualchassis_name', '2026-05-05 16:52:53.199035-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (245, 'dcim', '0111_component_template_description', '2026-05-05 16:52:53.19923-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (246, 'dcim', '0112_standardize_components', '2026-05-05 16:52:53.199428-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (247, 'dcim', '0113_nullbooleanfield_to_booleanfield', '2026-05-05 16:52:53.19963-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (248, 'dcim', '0114_update_jsonfield', '2026-05-05 16:52:53.199834-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (249, 'dcim', '0115_rackreservation_order', '2026-05-05 16:52:53.200041-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (250, 'dcim', '0116_rearport_max_positions', '2026-05-05 16:52:53.200242-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (251, 'dcim', '0117_custom_field_data', '2026-05-05 16:52:53.200462-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (252, 'dcim', '0118_inventoryitem_mptt', '2026-05-05 16:52:53.200682-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (253, 'dcim', '0119_inventoryitem_mptt_rebuild', '2026-05-05 16:52:53.200905-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (254, 'dcim', '0120_cache_cable_peer', '2026-05-05 16:52:53.20111-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (255, 'dcim', '0121_cablepath', '2026-05-05 16:52:53.201312-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (256, 'dcim', '0122_standardize_name_length', '2026-05-05 16:52:53.201509-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (257, 'dcim', '0123_standardize_models', '2026-05-05 16:52:53.201776-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (258, 'dcim', '0124_mark_connected', '2026-05-05 16:52:53.201999-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (259, 'dcim', '0125_console_port_speed', '2026-05-05 16:52:53.202215-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (260, 'dcim', '0126_rename_rackgroup_location', '2026-05-05 16:52:53.202426-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (261, 'dcim', '0127_device_location', '2026-05-05 16:52:53.202641-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (262, 'dcim', '0128_device_location_populate', '2026-05-05 16:52:53.202851-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (263, 'dcim', '0129_interface_parent', '2026-05-05 16:52:53.203067-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (264, 'dcim', '0130_sitegroup', '2026-05-05 16:52:53.203285-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (265, 'ipam', '0002_vrf_add_enforce_unique', '2026-05-05 16:52:54.157825-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (266, 'ipam', '0003_ipam_add_vlangroups', '2026-05-05 16:52:54.158583-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (267, 'ipam', '0004_ipam_vlangroup_uniqueness', '2026-05-05 16:52:54.159013-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (268, 'ipam', '0005_auto_20160725_1842', '2026-05-05 16:52:54.159413-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (269, 'ipam', '0006_vrf_vlan_add_tenant', '2026-05-05 16:52:54.159803-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (270, 'ipam', '0007_prefix_ipaddress_add_tenant', '2026-05-05 16:52:54.160192-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (271, 'ipam', '0008_prefix_change_order', '2026-05-05 16:52:54.160579-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (272, 'ipam', '0009_ipaddress_add_status', '2026-05-05 16:52:54.160968-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (273, 'ipam', '0010_ipaddress_help_texts', '2026-05-05 16:52:54.161356-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (274, 'ipam', '0011_rir_add_is_private', '2026-05-05 16:52:54.161746-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (275, 'ipam', '0012_services', '2026-05-05 16:52:54.163282-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (276, 'ipam', '0013_prefix_add_is_pool', '2026-05-05 16:52:54.163823-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (277, 'ipam', '0014_ipaddress_status_add_deprecated', '2026-05-05 16:52:54.164231-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (278, 'ipam', '0015_global_vlans', '2026-05-05 16:52:54.164658-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (279, 'ipam', '0016_unicode_literals', '2026-05-05 16:52:54.16505-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (280, 'ipam', '0017_ipaddress_roles', '2026-05-05 16:52:54.165443-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (281, 'ipam', '0018_remove_service_uniqueness_constraint', '2026-05-05 16:52:54.165824-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (282, 'ipam', '0019_virtualization', '2026-05-05 16:52:54.166198-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (283, 'ipam', '0020_ipaddress_add_role_carp', '2026-05-05 16:52:54.166549-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (284, 'ipam', '0021_vrf_ordering', '2026-05-05 16:52:54.166887-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (285, 'ipam', '0022_tags', '2026-05-05 16:52:54.167229-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (286, 'ipam', '0023_change_logging', '2026-05-05 16:52:54.167583-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (287, 'ipam', '0024_vrf_allow_null_rd', '2026-05-05 16:52:54.167926-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (288, 'ipam', '0025_custom_tag_models', '2026-05-05 16:52:54.168268-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (289, 'ipam', '0026_prefix_ordering_vrf_nulls_first', '2026-05-05 16:52:54.16861-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (290, 'ipam', '0027_ipaddress_add_dns_name', '2026-05-05 16:52:54.168954-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (291, 'ipam', '0028_3569_prefix_fields', '2026-05-05 16:52:54.169289-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (292, 'ipam', '0029_3569_ipaddress_fields', '2026-05-05 16:52:54.169633-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (293, 'ipam', '0030_3569_vlan_fields', '2026-05-05 16:52:54.170046-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (294, 'ipam', '0031_3569_service_fields', '2026-05-05 16:52:54.170377-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (295, 'ipam', '0032_role_description', '2026-05-05 16:52:54.170711-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (296, 'ipam', '0033_deterministic_ordering', '2026-05-05 16:52:54.171043-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (297, 'ipam', '0034_fix_ipaddress_status_dhcp', '2026-05-05 16:52:54.171372-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (298, 'ipam', '0035_drop_ip_family', '2026-05-05 16:52:54.171701-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (299, 'ipam', '0036_standardize_description', '2026-05-05 16:52:54.17204-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (300, 'ipam', '0037_ipaddress_assignment', '2026-05-05 16:52:54.172413-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (301, 'ipam', '0038_custom_field_data', '2026-05-05 16:52:54.172746-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (302, 'ipam', '0039_service_ports_array', '2026-05-05 16:52:54.173076-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (303, 'ipam', '0040_service_drop_port', '2026-05-05 16:52:54.173411-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (304, 'ipam', '0041_routetarget', '2026-05-05 16:52:54.17375-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (703, 'ipam', '0001_squashed', '2026-05-05 16:54:18.633462-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (305, 'ipam', '0042_standardize_name_length', '2026-05-05 16:52:54.174081-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (306, 'ipam', '0043_add_tenancy_to_aggregates', '2026-05-05 16:52:54.174499-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (307, 'ipam', '0044_standardize_models', '2026-05-05 16:52:54.17483-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (308, 'ipam', '0045_vlangroup_scope', '2026-05-05 16:52:54.175167-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (309, 'ipam', '0046_set_vlangroup_scope_types', '2026-05-05 16:52:54.175503-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (310, 'wireless', '0001_wireless', '2026-05-05 16:52:54.555262-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (311, 'wireless', '0002_standardize_id_fields', '2026-05-05 16:52:54.555949-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (312, 'wireless', '0003_created_datetimefield', '2026-05-05 16:52:54.556275-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (313, 'wireless', '0004_wireless_tenancy', '2026-05-05 16:52:54.556577-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (314, 'wireless', '0005_wirelesslink_interface_types', '2026-05-05 16:52:54.55688-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (315, 'wireless', '0006_unique_constraints', '2026-05-05 16:52:54.557163-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (316, 'wireless', '0007_standardize_description_comments', '2026-05-05 16:52:54.55745-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (317, 'wireless', '0008_wirelesslan_status', '2026-05-05 16:52:54.557733-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (318, 'ipam', '0047_prefix_depth_children', '2026-05-05 16:52:55.133894-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (319, 'ipam', '0048_prefix_populate_depth_children', '2026-05-05 16:52:55.13459-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (320, 'ipam', '0049_prefix_mark_utilized', '2026-05-05 16:52:55.134912-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (321, 'ipam', '0050_iprange', '2026-05-05 16:52:55.135212-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (322, 'ipam', '0051_extend_tag_support', '2026-05-05 16:52:55.135507-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (323, 'ipam', '0052_fhrpgroup', '2026-05-05 16:52:55.135794-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (324, 'ipam', '0053_asn_model', '2026-05-05 16:52:55.136263-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (325, 'dcim', '0131_consoleport_speed', '2026-05-05 16:53:05.904244-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (326, 'dcim', '0132_cable_length', '2026-05-05 16:53:05.905733-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (327, 'dcim', '0133_port_colors', '2026-05-05 16:53:05.906109-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (328, 'dcim', '0134_interface_wwn_bridge', '2026-05-05 16:53:05.906456-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (329, 'dcim', '0135_tenancy_extensions', '2026-05-05 16:53:05.906779-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (330, 'dcim', '0136_device_airflow', '2026-05-05 16:53:05.907093-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (331, 'dcim', '0137_relax_uniqueness_constraints', '2026-05-05 16:53:05.907407-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (332, 'dcim', '0138_extend_tag_support', '2026-05-05 16:53:05.907716-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (333, 'dcim', '0139_rename_cable_peer', '2026-05-05 16:53:05.908029-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (334, 'dcim', '0140_wireless', '2026-05-05 16:53:05.908337-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (335, 'dcim', '0141_asn_model', '2026-05-05 16:53:05.908647-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (336, 'dcim', '0142_rename_128gfc_qsfp28', '2026-05-05 16:53:05.908955-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (337, 'dcim', '0143_remove_primary_for_related_name', '2026-05-05 16:53:05.909259-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (338, 'dcim', '0144_fix_cable_abs_length', '2026-05-05 16:53:05.909562-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (339, 'dcim', '0145_site_remove_deprecated_fields', '2026-05-05 16:53:05.910047-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (340, 'dcim', '0146_modules', '2026-05-05 16:53:05.910473-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (341, 'dcim', '0147_inventoryitemrole', '2026-05-05 16:53:05.910817-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (342, 'dcim', '0148_inventoryitem_component', '2026-05-05 16:53:05.911132-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (343, 'dcim', '0149_inventoryitem_templates', '2026-05-05 16:53:05.911461-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (344, 'dcim', '0150_interface_vrf', '2026-05-05 16:53:05.911984-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (345, 'dcim', '0151_interface_speed_duplex', '2026-05-05 16:53:05.912325-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (346, 'dcim', '0152_standardize_id_fields', '2026-05-05 16:53:05.912657-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (347, 'dcim', '0153_created_datetimefield', '2026-05-05 16:53:05.91299-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (348, 'dcim', '0154_half_height_rack_units', '2026-05-05 16:53:05.913322-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (349, 'dcim', '0155_interface_poe_mode_type', '2026-05-05 16:53:05.913711-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (350, 'dcim', '0156_location_status', '2026-05-05 16:53:05.914023-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (351, 'dcim', '0157_new_cabling_models', '2026-05-05 16:53:05.914347-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (352, 'dcim', '0158_populate_cable_terminations', '2026-05-05 16:53:05.914656-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (353, 'dcim', '0159_populate_cable_paths', '2026-05-05 16:53:05.914959-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (354, 'circuits', '0001_initial', '2026-05-05 16:53:05.939099-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (355, 'circuits', '0002_auto_20160622_1821', '2026-05-05 16:53:06.878604-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (356, 'circuits', '0003_provider_32bit_asn_support', '2026-05-05 16:53:06.879342-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (357, 'circuits', '0004_circuit_add_tenant', '2026-05-05 16:53:06.879773-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (358, 'circuits', '0005_circuit_add_upstream_speed', '2026-05-05 16:53:06.880189-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (359, 'circuits', '0006_terminations', '2026-05-05 16:53:06.880602-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (360, 'circuits', '0007_circuit_add_description', '2026-05-05 16:53:06.880994-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (361, 'circuits', '0008_circuittermination_interface_protect_on_delete', '2026-05-05 16:53:06.881385-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (362, 'circuits', '0009_unicode_literals', '2026-05-05 16:53:06.881788-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (363, 'circuits', '0010_circuit_status', '2026-05-05 16:53:06.882177-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (364, 'circuits', '0011_tags', '2026-05-05 16:53:06.882563-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (365, 'circuits', '0012_change_logging', '2026-05-05 16:53:06.88296-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (366, 'circuits', '0013_cables', '2026-05-05 16:53:06.883387-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (367, 'circuits', '0014_circuittermination_description', '2026-05-05 16:53:06.884066-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (368, 'circuits', '0015_custom_tag_models', '2026-05-05 16:53:06.88445-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (369, 'circuits', '0016_3569_circuit_fields', '2026-05-05 16:53:06.884833-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (370, 'circuits', '0017_circuittype_description', '2026-05-05 16:53:06.885221-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (371, 'circuits', '0018_standardize_description', '2026-05-05 16:53:06.885608-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (372, 'circuits', '0019_nullbooleanfield_to_booleanfield', '2026-05-05 16:53:06.885989-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (373, 'circuits', '0020_custom_field_data', '2026-05-05 16:53:06.886382-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (374, 'circuits', '0021_cache_cable_peer', '2026-05-05 16:53:06.886807-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (375, 'circuits', '0022_cablepath', '2026-05-05 16:53:06.887205-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (376, 'circuits', '0023_circuittermination_port_speed_optional', '2026-05-05 16:53:06.887827-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (377, 'circuits', '0024_standardize_name_length', '2026-05-05 16:53:06.888222-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (378, 'circuits', '0025_standardize_models', '2026-05-05 16:53:06.888651-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (379, 'circuits', '0026_mark_connected', '2026-05-05 16:53:06.889073-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (380, 'circuits', '0027_providernetwork', '2026-05-05 16:53:06.889468-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (381, 'circuits', '0028_cache_circuit_terminations', '2026-05-05 16:53:06.889844-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (382, 'circuits', '0029_circuit_tracing', '2026-05-05 16:53:06.89023-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (383, 'circuits', '0003_extend_tag_support', '2026-05-05 16:53:08.197309-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (384, 'circuits', '0004_rename_cable_peer', '2026-05-05 16:53:08.198521-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (385, 'circuits', '0032_provider_service_id', '2026-05-05 16:53:08.198962-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (386, 'circuits', '0033_standardize_id_fields', '2026-05-05 16:53:08.199333-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (387, 'circuits', '0034_created_datetimefield', '2026-05-05 16:53:08.199701-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (388, 'circuits', '0035_provider_asns', '2026-05-05 16:53:08.200052-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (389, 'circuits', '0036_circuit_termination_date_tags_custom_fields', '2026-05-05 16:53:08.200408-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (390, 'circuits', '0037_new_cabling_models', '2026-05-05 16:53:08.200755-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (391, 'dcim', '0160_populate_cable_ends', '2026-05-05 16:53:14.996789-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (392, 'dcim', '0161_cabling_cleanup', '2026-05-05 16:53:14.997335-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (393, 'dcim', '0162_unique_constraints', '2026-05-05 16:53:14.997679-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (394, 'dcim', '0163_weight_fields', '2026-05-05 16:53:14.997988-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (395, 'dcim', '0164_rack_mounting_depth', '2026-05-05 16:53:14.998288-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (396, 'dcim', '0165_standardize_description_comments', '2026-05-05 16:53:14.998582-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (397, 'dcim', '0166_virtualdevicecontext', '2026-05-05 16:53:14.998877-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (398, 'core', '0001_initial', '2026-05-05 16:53:15.488407-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (399, 'core', '0002_managedfile', '2026-05-05 16:53:15.489278-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (400, 'core', '0003_job', '2026-05-05 16:53:15.489594-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (401, 'core', '0004_replicate_jobresults', '2026-05-05 16:53:15.489897-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (402, 'core', '0005_job_created_auto_now', '2026-05-05 16:53:15.490186-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (403, 'circuits', '0038_cabling_cleanup', '2026-05-05 16:53:16.626141-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (404, 'circuits', '0039_unique_constraints', '2026-05-05 16:53:16.627803-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (405, 'circuits', '0040_provider_remove_deprecated_fields', '2026-05-05 16:53:16.628339-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (406, 'circuits', '0041_standardize_description_comments', '2026-05-05 16:53:16.628837-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (407, 'circuits', '0042_provideraccount', '2026-05-05 16:53:16.629366-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (408, 'extras', '0060_customlink_button_class', '2026-05-05 16:53:19.841979-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (409, 'extras', '0061_extras_change_logging', '2026-05-05 16:53:19.843939-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (410, 'extras', '0062_clear_secrets_changelog', '2026-05-05 16:53:19.844384-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (411, 'extras', '0063_webhook_conditions', '2026-05-05 16:53:19.844778-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (412, 'extras', '0064_configrevision', '2026-05-05 16:53:19.845169-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (413, 'extras', '0065_imageattachment_change_logging', '2026-05-05 16:53:19.845549-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (414, 'extras', '0066_customfield_name_validation', '2026-05-05 16:53:19.845929-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (415, 'extras', '0067_customfield_min_max_values', '2026-05-05 16:53:19.846306-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (416, 'extras', '0068_configcontext_cluster_types', '2026-05-05 16:53:19.846686-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (417, 'extras', '0069_custom_object_field', '2026-05-05 16:53:19.847052-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (418, 'extras', '0070_customlink_enabled', '2026-05-05 16:53:19.847428-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (419, 'extras', '0071_standardize_id_fields', '2026-05-05 16:53:19.847806-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (420, 'extras', '0072_created_datetimefield', '2026-05-05 16:53:19.848177-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (421, 'extras', '0073_journalentry_tags_custom_fields', '2026-05-05 16:53:19.848547-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (422, 'extras', '0074_customfield_extensions', '2026-05-05 16:53:19.848923-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (423, 'extras', '0075_configcontext_locations', '2026-05-05 16:53:19.849297-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (424, 'extras', '0076_tag_slug_unicode', '2026-05-05 16:53:19.849664-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (425, 'extras', '0077_customlink_extend_text_and_url', '2026-05-05 16:53:19.850026-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (426, 'extras', '0078_unique_constraints', '2026-05-05 16:53:19.850405-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (427, 'extras', '0079_scheduled_jobs', '2026-05-05 16:53:19.850778-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (428, 'extras', '0080_customlink_content_types', '2026-05-05 16:53:19.851146-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (429, 'extras', '0081_exporttemplate_content_types', '2026-05-05 16:53:19.851531-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (430, 'extras', '0082_savedfilter', '2026-05-05 16:53:19.85188-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (431, 'extras', '0083_search', '2026-05-05 16:53:19.852228-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (432, 'extras', '0084_staging', '2026-05-05 16:53:19.852578-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (433, 'extras', '0085_synced_data', '2026-05-05 16:53:19.852927-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (434, 'extras', '0086_configtemplate', '2026-05-05 16:53:19.853269-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (435, 'extras', '0087_dashboard', '2026-05-05 16:53:20.459727-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (436, 'extras', '0088_jobresult_webhooks', '2026-05-05 16:53:20.461449-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (437, 'extras', '0089_customfield_is_cloneable', '2026-05-05 16:53:20.461835-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (438, 'extras', '0090_objectchange_index_request_id', '2026-05-05 16:53:20.462205-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (439, 'extras', '0091_create_managedfiles', '2026-05-05 16:53:20.462559-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (440, 'extras', '0092_delete_jobresult', '2026-05-05 16:53:20.462918-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (441, 'extras', '0093_configrevision_ordering', '2026-05-05 16:53:20.463294-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (442, 'extras', '0094_tag_object_types', '2026-05-05 16:53:20.46365-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (443, 'extras', '0095_bookmarks', '2026-05-05 16:53:20.463998-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (444, 'extras', '0096_customfieldchoiceset', '2026-05-05 16:53:20.464339-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (445, 'extras', '0097_customfield_remove_choices', '2026-05-05 16:53:20.465081-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (446, 'extras', '0098_webhook_custom_field_data_webhook_tags', '2026-05-05 16:53:20.465468-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (447, 'extras', '0099_cachedvalue_ordering', '2026-05-05 16:53:20.483698-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (448, 'extras', '0100_customfield_ui_attrs', '2026-05-05 16:53:20.608019-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (449, 'extras', '0101_eventrule', '2026-05-05 16:53:21.675221-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (450, 'extras', '0102_move_configrevision', '2026-05-05 16:53:21.746545-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (451, 'extras', '0103_gfk_indexes', '2026-05-05 16:53:21.967544-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (452, 'extras', '0104_stagedchange_remove_change_logging', '2026-05-05 16:53:22.004969-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (453, 'extras', '0105_customfield_min_max_values', '2026-05-05 16:53:22.072151-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (454, 'extras', '0106_bookmark_user_cascade_deletion', '2026-05-05 16:53:22.156973-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (455, 'extras', '0107_cachedvalue_extras_cachedvalue_object', '2026-05-05 16:53:22.18093-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (456, 'extras', '0108_convert_reports_to_scripts', '2026-05-05 16:53:22.263386-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (457, 'extras', '0109_script_model', '2026-05-05 16:53:22.6874-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (458, 'extras', '0110_remove_eventrule_action_parameters', '2026-05-05 16:53:22.751994-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (459, 'core', '0006_datasource_type_remove_choices', '2026-05-05 16:53:22.803413-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (460, 'core', '0007_job_add_error_field', '2026-05-05 16:53:22.826385-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (461, 'core', '0008_contenttype_proxy', '2026-05-05 16:53:22.828456-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (462, 'core', '0009_configrevision', '2026-05-05 16:53:22.830305-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (463, 'core', '0010_gfk_indexes', '2026-05-05 16:53:22.852172-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (464, 'extras', '0111_rename_content_types', '2026-05-05 16:53:23.648804-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (465, 'extras', '0112_tag_update_object_types', '2026-05-05 16:53:23.738699-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (466, 'extras', '0113_customfield_rename_object_type', '2026-05-05 16:53:23.770449-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (467, 'users', '0005_alter_user_table', '2026-05-05 16:53:23.898942-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (468, 'users', '0006_custom_group_model', '2026-05-05 16:53:24.30862-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (469, 'users', '0007_objectpermission_update_object_types', '2026-05-05 16:53:24.385678-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (470, 'users', '0008_flip_objectpermission_assignments', '2026-05-05 16:53:24.677032-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (471, 'users', '0009_update_group_perms', '2026-05-05 16:53:24.814812-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (472, 'extras', '0114_customfield_add_comments', '2026-05-05 16:53:24.8356-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (473, 'extras', '0115_convert_dashboard_widgets', '2026-05-05 16:53:24.904519-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (474, 'extras', '0116_custom_link_button_color', '2026-05-05 16:53:24.993552-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (475, 'core', '0011_move_objectchange', '2026-05-05 16:53:25.062083-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (476, 'extras', '0117_move_objectchange', '2026-05-05 16:53:25.230911-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (477, 'extras', '0118_customfield_uniqueness', '2026-05-05 16:53:25.250957-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (478, 'extras', '0119_notifications', '2026-05-05 16:53:25.752663-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (479, 'extras', '0120_eventrule_event_types', '2026-05-05 16:53:26.29218-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (480, 'extras', '0121_customfield_related_object_filter', '2026-05-05 16:53:26.314401-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (481, 'extras', '0122_charfield_null_choices', '2026-05-05 16:53:26.40738-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (482, 'tenancy', '0012_contactassignment_custom_fields', '2026-05-05 16:53:26.487387-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (483, 'tenancy', '0013_gfk_indexes', '2026-05-05 16:53:26.558606-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (484, 'tenancy', '0014_contactassignment_ordering', '2026-05-05 16:53:26.631373-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (485, 'tenancy', '0015_contactassignment_rename_content_type', '2026-05-05 16:53:27.461328-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (486, 'tenancy', '0016_charfield_null_choices', '2026-05-05 16:53:27.590348-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (487, 'ipam', '0054_vlangroup_min_max_vids', '2026-05-05 16:53:31.944993-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (488, 'ipam', '0055_servicetemplate', '2026-05-05 16:53:31.946262-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (489, 'ipam', '0056_standardize_id_fields', '2026-05-05 16:53:31.946584-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (490, 'ipam', '0057_created_datetimefield', '2026-05-05 16:53:31.946876-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (491, 'ipam', '0058_ipaddress_nat_inside_nonunique', '2026-05-05 16:53:31.947155-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (492, 'ipam', '0059_l2vpn', '2026-05-05 16:53:31.947488-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (493, 'ipam', '0060_alter_l2vpn_slug', '2026-05-05 16:53:31.947773-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (494, 'ipam', '0061_fhrpgroup_name', '2026-05-05 16:53:31.948056-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (495, 'ipam', '0062_unique_constraints', '2026-05-05 16:53:31.948355-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (496, 'ipam', '0063_standardize_description_comments', '2026-05-05 16:53:31.948652-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (497, 'ipam', '0064_clear_search_cache', '2026-05-05 16:53:31.948948-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (498, 'ipam', '0065_asnrange', '2026-05-05 16:53:31.949236-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (499, 'ipam', '0066_iprange_mark_utilized', '2026-05-05 16:53:31.949529-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (500, 'ipam', '0067_ipaddress_index_host', '2026-05-05 16:53:31.949825-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (501, 'ipam', '0068_move_l2vpn', '2026-05-05 16:53:32.55553-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (502, 'ipam', '0069_gfk_indexes', '2026-05-05 16:53:32.697804-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (503, 'ipam', '0070_vlangroup_vlan_id_ranges', '2026-05-05 16:53:32.999506-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (504, 'ipam', '0071_prefix_scope', '2026-05-05 16:53:33.203395-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (505, 'dcim', '0167_module_status', '2026-05-05 16:53:36.368791-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (506, 'dcim', '0168_interface_template_enabled', '2026-05-05 16:53:36.369584-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (507, 'dcim', '0169_devicetype_default_platform', '2026-05-05 16:53:36.369903-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (508, 'dcim', '0170_configtemplate', '2026-05-05 16:53:36.370203-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (509, 'dcim', '0171_cabletermination_change_logging', '2026-05-05 16:53:36.37087-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (510, 'dcim', '0172_larger_power_draw_values', '2026-05-05 16:53:36.371166-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (511, 'dcim', '0173_remove_napalm_fields', '2026-05-05 16:53:36.371446-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (512, 'dcim', '0174_device_latitude_device_longitude', '2026-05-05 16:53:36.371732-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (513, 'dcim', '0174_rack_starting_unit', '2026-05-05 16:53:36.372023-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (514, 'dcim', '0175_device_oob_ip', '2026-05-05 16:53:36.3723-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (515, 'dcim', '0176_device_component_counters', '2026-05-05 16:53:36.37263-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (516, 'dcim', '0177_devicetype_component_counters', '2026-05-05 16:53:36.372998-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (517, 'dcim', '0178_virtual_chassis_member_counter', '2026-05-05 16:53:36.373359-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (518, 'dcim', '0179_interfacetemplate_rf_role', '2026-05-05 16:53:36.373681-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (519, 'dcim', '0180_powerfeed_tenant', '2026-05-05 16:53:36.373991-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (520, 'dcim', '0181_rename_device_role_device_role', '2026-05-05 16:53:36.374299-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (521, 'dcim', '0182_zero_length_cable_fix', '2026-05-05 16:53:36.374621-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (522, 'dcim', '0183_devicetype_exclude_from_utilization', '2026-05-05 16:53:36.433164-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (523, 'dcim', '0184_protect_child_interfaces', '2026-05-05 16:53:36.514855-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (524, 'dcim', '0185_gfk_indexes', '2026-05-05 16:53:36.664644-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (525, 'dcim', '0186_location_facility', '2026-05-05 16:53:36.719966-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (526, 'dcim', '0187_alter_device_vc_position', '2026-05-05 16:53:36.805983-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (527, 'dcim', '0188_racktype', '2026-05-05 16:53:37.135776-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (528, 'dcim', '0189_moduletype_rack_airflow', '2026-05-05 16:53:37.254064-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (529, 'dcim', '0190_nested_modules', '2026-05-05 16:53:38.20359-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (530, 'dcim', '0191_module_bay_rebuild', '2026-05-05 16:53:38.287717-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (531, 'dcim', '0192_inventoryitem_status', '2026-05-05 16:53:38.359324-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (532, 'dcim', '0193_poweroutlet_color', '2026-05-05 16:53:38.471872-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (533, 'ipam', '0072_prefix_cached_relations', '2026-05-05 16:53:39.063182-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (534, 'ipam', '0073_charfield_null_choices', '2026-05-05 16:53:39.341528-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (535, 'ipam', '0074_vlantranslationpolicy_vlantranslationrule', '2026-05-05 16:53:39.688292-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (536, 'ipam', '0075_vlan_qinq', '2026-05-05 16:53:39.989757-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (537, 'dcim', '0194_charfield_null_choices', '2026-05-05 16:53:42.56864-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (538, 'dcim', '0195_interface_vlan_translation_policy', '2026-05-05 16:53:42.67959-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (539, 'dcim', '0196_qinq_svlan', '2026-05-05 16:53:43.018673-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (540, 'dcim', '0197_natural_sort_collation', '2026-05-05 16:53:43.043919-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (541, 'circuits', '0043_circuittype_color', '2026-05-05 16:53:43.101542-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (542, 'circuits', '0044_circuit_groups', '2026-05-05 16:53:43.455562-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (543, 'circuits', '0045_circuit_distance', '2026-05-05 16:53:43.649068-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (544, 'circuits', '0046_charfield_null_choices', '2026-05-05 16:53:43.951544-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (545, 'circuits', '0047_circuittermination__termination', '2026-05-05 16:53:44.257587-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (546, 'circuits', '0048_circuitterminations_cached_relations', '2026-05-05 16:53:44.824416-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (547, 'circuits', '0049_natural_ordering', '2026-05-05 16:53:44.938943-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (548, 'circuits', '0050_virtual_circuits', '2026-05-05 16:53:45.325717-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (549, 'circuits', '0051_virtualcircuit_group_assignment', '2026-05-05 16:53:46.127174-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (550, 'circuits', '0052_extend_circuit_abs_distance_upper_limit', '2026-05-05 16:53:46.240132-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (551, 'core', '0012_job_object_type_optional', '2026-05-05 16:53:46.341891-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (552, 'core', '0013_job_data_encoder', '2026-05-05 16:53:46.367555-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (553, 'core', '0014_datasource_sync_interval', '2026-05-05 16:53:46.439446-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (554, 'core', '0015_remove_redundant_indexes', '2026-05-05 16:53:46.511328-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (555, 'core', '0016_job_log_entries', '2026-05-05 16:53:46.54072-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (556, 'core', '0017_objectchange_message', '2026-05-05 16:53:46.571811-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (557, 'core', '0018_concrete_objecttype', '2026-05-05 16:53:46.702177-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (558, 'core', '0019_configrevision_active', '2026-05-05 16:53:46.796269-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (559, 'extras', '0123_journalentry_kind_default', '2026-05-05 16:53:46.886835-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (560, 'extras', '0124_remove_staging', '2026-05-05 16:53:47.12394-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (561, 'extras', '0125_alter_tag_options_tag_weight', '2026-05-05 16:53:47.306836-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (562, 'extras', '0126_exporttemplate_file_name', '2026-05-05 16:53:47.338398-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (563, 'extras', '0127_configtemplate_as_attachment_and_more', '2026-05-05 16:53:47.663268-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (564, 'extras', '0128_tableconfig', '2026-05-05 16:53:47.78649-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (565, 'extras', '0129_fix_script_paths', '2026-05-05 16:53:48.004063-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (566, 'dcim', '0198_natural_ordering', '2026-05-05 16:53:51.47557-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (567, 'dcim', '0199_macaddress', '2026-05-05 16:53:51.604253-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (568, 'dcim', '0200_populate_mac_addresses', '2026-05-05 16:53:51.891977-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (569, 'dcim', '0201_add_power_outlet_status', '2026-05-05 16:53:51.971823-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (570, 'dcim', '0202_location_comments_region_comments_sitegroup_comments', '2026-05-05 16:53:52.186942-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (571, 'dcim', '0203_add_rack_outer_height', '2026-05-05 16:53:52.340559-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (572, 'dcim', '0203_device_role_nested', '2026-05-05 16:53:52.941268-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (573, 'dcim', '0204_device_role_rebuild', '2026-05-05 16:53:53.024387-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (574, 'dcim', '0205_moduletypeprofile', '2026-05-05 16:53:53.312665-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (575, 'dcim', '0206_load_module_type_profiles', '2026-05-05 16:53:53.445343-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (576, 'dcim', '0207_remove_redundant_indexes', '2026-05-05 16:53:53.499888-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (577, 'dcim', '0208_devicerole_uniqueness', '2026-05-05 16:53:53.73746-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (578, 'dcim', '0209_device_component_denorm_site_location', '2026-05-05 16:53:57.405479-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (579, 'dcim', '0210_macaddress_ordering', '2026-05-05 16:53:57.528482-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (580, 'dcim', '0211_platform_manufacturer_uniqueness', '2026-05-05 16:53:57.956855-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (581, 'dcim', '0212_interface_tx_power_negative', '2026-05-05 16:53:58.024367-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (582, 'dcim', '0213_platform_parent', '2026-05-05 16:53:58.405297-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (583, 'dcim', '0214_platform_rebuild', '2026-05-05 16:53:58.48883-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (584, 'dcim', '0215_rackreservation_status', '2026-05-05 16:53:58.561186-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (585, 'dcim', '0216_latitude_longitude_validators', '2026-05-05 16:53:59.109839-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (586, 'django_rq', '0001_initial', '2026-05-05 16:53:59.112856-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (587, 'extras', '0130_imageattachment_description', '2026-05-05 16:53:59.133417-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (588, 'extras', '0131_concrete_objecttype', '2026-05-05 16:53:59.757402-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (589, 'extras', '0132_configcontextprofile', '2026-05-05 16:53:59.990994-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (590, 'extras', '0133_make_cf_minmax_decimal', '2026-05-05 16:54:00.065773-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (591, 'tenancy', '0017_natural_ordering', '2026-05-05 16:54:00.521396-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (592, 'tenancy', '0018_contact_groups', '2026-05-05 16:54:01.109499-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (593, 'tenancy', '0019_contactgroup_comments_tenantgroup_comments', '2026-05-05 16:54:01.259533-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (594, 'tenancy', '0020_remove_contactgroupmembership', '2026-05-05 16:54:01.491425-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (595, 'virtualization', '0023_virtualmachine_natural_ordering', '2026-05-05 16:54:04.584303-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (596, 'virtualization', '0024_cluster_relax_uniqueness', '2026-05-05 16:54:04.58543-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (597, 'virtualization', '0025_extend_tag_support', '2026-05-05 16:54:04.585809-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (598, 'virtualization', '0026_vminterface_bridge', '2026-05-05 16:54:04.586243-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (599, 'virtualization', '0027_standardize_id_fields', '2026-05-05 16:54:04.58662-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (600, 'virtualization', '0028_vminterface_vrf', '2026-05-05 16:54:04.587018-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (601, 'virtualization', '0029_created_datetimefield', '2026-05-05 16:54:04.587379-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (602, 'virtualization', '0030_cluster_status', '2026-05-05 16:54:04.587733-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (603, 'virtualization', '0031_virtualmachine_site_device', '2026-05-05 16:54:04.588083-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (604, 'virtualization', '0032_virtualmachine_update_sites', '2026-05-05 16:54:04.58843-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (605, 'virtualization', '0033_unique_constraints', '2026-05-05 16:54:04.588781-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (704, 'ipam', '0002_squashed_0046', '2026-05-05 16:54:18.633764-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (606, 'virtualization', '0034_standardize_description_comments', '2026-05-05 16:54:04.589126-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (607, 'virtualization', '0035_virtualmachine_interface_count', '2026-05-05 16:54:04.589722-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (608, 'virtualization', '0036_virtualmachine_config_template', '2026-05-05 16:54:04.590063-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (609, 'virtualization', '0037_protect_child_interfaces', '2026-05-05 16:54:04.685686-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (610, 'virtualization', '0038_virtualdisk', '2026-05-05 16:54:04.988283-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (611, 'virtualization', '0039_virtualmachine_serial_number', '2026-05-05 16:54:05.055502-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (612, 'virtualization', '0040_convert_disk_size', '2026-05-05 16:54:05.158844-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (613, 'virtualization', '0041_charfield_null_choices', '2026-05-05 16:54:05.981226-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (614, 'virtualization', '0042_vminterface_vlan_translation_policy', '2026-05-05 16:54:06.072321-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (615, 'virtualization', '0043_qinq_svlan', '2026-05-05 16:54:06.331733-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (616, 'virtualization', '0044_cluster_scope', '2026-05-05 16:54:06.642367-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (617, 'virtualization', '0045_clusters_cached_relations', '2026-05-05 16:54:07.499167-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (618, 'virtualization', '0046_alter_cluster__location_alter_cluster__region_and_more', '2026-05-05 16:54:07.929607-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (619, 'virtualization', '0047_natural_ordering', '2026-05-05 16:54:08.38684-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (620, 'virtualization', '0048_populate_mac_addresses', '2026-05-05 16:54:08.626572-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (621, 'ipam', '0076_natural_ordering', '2026-05-05 16:54:08.914794-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (622, 'ipam', '0077_vlangroup_tenant', '2026-05-05 16:54:09.007615-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (623, 'ipam', '0078_iprange_mark_utilized', '2026-05-05 16:54:09.327767-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (624, 'ipam', '0079_add_service_fhrp_group_parent_gfk', '2026-05-05 16:54:09.482045-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (625, 'ipam', '0080_populate_service_parent', '2026-05-05 16:54:09.579158-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (626, 'ipam', '0081_remove_service_device_virtual_machine_add_parent_gfk_index', '2026-05-05 16:54:10.0779-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (627, 'ipam', '0082_add_prefix_network_containment_indexes', '2026-05-05 16:54:10.170779-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (628, 'ipam', '0083_vlangroup_populate_total_vlan_ids', '2026-05-05 16:54:10.272713-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (629, 'netbox_branching', '0001_initial', '2026-05-05 16:54:10.768132-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (630, 'netbox_branching', '0002_branch_schema_id_unique', '2026-05-05 16:54:10.862165-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (631, 'netbox_branching', '0003_rename_indexes', '2026-05-05 16:54:10.966165-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (632, 'netbox_branching', '0004_copy_migrations', '2026-05-05 16:54:11.092529-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (633, 'netbox_branching', '0005_branch_applied_migrations', '2026-05-05 16:54:11.174309-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (634, 'netbox_branching', '0006_tag_object_types', '2026-05-05 16:54:11.278727-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (635, 'netbox_branching', '0007_branch_merge_strategy', '2026-05-05 16:54:11.367695-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (636, 'netbox_branching', '0008_branch_custom_permissions', '2026-05-05 16:54:11.463926-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (637, 'sessions', '0001_initial', '2026-05-05 16:54:11.473712-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (638, 'default', '0001_initial', '2026-05-05 16:54:11.635832-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (639, 'social_auth', '0001_initial', '2026-05-05 16:54:11.63681-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (640, 'default', '0002_add_related_name', '2026-05-05 16:54:11.795388-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (641, 'social_auth', '0002_add_related_name', '2026-05-05 16:54:11.796733-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (642, 'default', '0003_alter_email_max_length', '2026-05-05 16:54:11.808328-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (643, 'social_auth', '0003_alter_email_max_length', '2026-05-05 16:54:11.808787-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (644, 'default', '0004_auto_20160423_0400', '2026-05-05 16:54:11.822846-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (645, 'social_auth', '0004_auto_20160423_0400', '2026-05-05 16:54:11.82376-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (646, 'social_auth', '0005_auto_20160727_2333', '2026-05-05 16:54:11.830587-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (647, 'social_django', '0006_partial', '2026-05-05 16:54:11.839848-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (648, 'social_django', '0007_code_timestamp', '2026-05-05 16:54:11.847873-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (649, 'social_django', '0008_partial_timestamp', '2026-05-05 16:54:11.853627-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (650, 'social_django', '0009_auto_20191118_0520', '2026-05-05 16:54:11.882838-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (651, 'social_django', '0010_uid_db_index', '2026-05-05 16:54:11.900454-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (652, 'social_django', '0011_alter_id_fields', '2026-05-05 16:54:11.976853-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (653, 'social_django', '0012_usersocialauth_extra_data_new', '2026-05-05 16:54:12.002662-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (654, 'social_django', '0013_migrate_extra_data', '2026-05-05 16:54:12.09165-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (655, 'social_django', '0014_remove_usersocialauth_extra_data', '2026-05-05 16:54:12.112749-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (656, 'social_django', '0015_rename_extra_data_new_usersocialauth_extra_data', '2026-05-05 16:54:12.133377-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (657, 'social_django', '0016_alter_usersocialauth_extra_data', '2026-05-05 16:54:12.148284-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (658, 'social_django', '0017_usersocialauth_user_social_auth_uid_required', '2026-05-05 16:54:12.164668-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (659, 'taggit', '0001_initial', '2026-05-05 16:54:12.264024-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (660, 'taggit', '0002_auto_20150616_2121', '2026-05-05 16:54:12.289649-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (661, 'taggit', '0003_taggeditem_add_unique_index', '2026-05-05 16:54:12.314841-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (662, 'taggit', '0004_alter_taggeditem_content_type_alter_taggeditem_tag', '2026-05-05 16:54:12.483066-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (663, 'taggit', '0005_auto_20220424_2025', '2026-05-05 16:54:12.489511-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (664, 'taggit', '0006_rename_taggeditem_content_type_object_id_taggit_tagg_content_8fc721_idx', '2026-05-05 16:54:12.541302-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (665, 'thumbnail', '0001_initial', '2026-05-05 16:54:12.548964-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (666, 'users', '0010_add_token_meta_ordering', '2026-05-05 16:54:12.562465-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (667, 'users', '0011_concrete_objecttype', '2026-05-05 16:54:12.655953-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (668, 'users', '0012_drop_django_admin_log_table', '2026-05-05 16:54:12.659648-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (669, 'vpn', '0001_initial', '2026-05-05 16:54:14.217431-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (670, 'vpn', '0002_move_l2vpn', '2026-05-05 16:54:14.623227-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (671, 'vpn', '0003_ipaddress_multiple_tunnel_terminations', '2026-05-05 16:54:14.75213-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (672, 'vpn', '0004_alter_ikepolicy_mode', '2026-05-05 16:54:14.839998-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (673, 'vpn', '0005_rename_indexes', '2026-05-05 16:54:14.865249-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (674, 'vpn', '0006_charfield_null_choices', '2026-05-05 16:54:15.431005-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (675, 'vpn', '0007_natural_ordering', '2026-05-05 16:54:16.127647-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (676, 'vpn', '0008_add_l2vpn_status', '2026-05-05 16:54:16.20269-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (677, 'vpn', '0009_remove_redundant_indexes', '2026-05-05 16:54:16.359127-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (678, 'wireless', '0009_wirelesslink_distance', '2026-05-05 16:54:16.560636-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (679, 'wireless', '0010_charfield_null_choices', '2026-05-05 16:54:17.041475-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (680, 'wireless', '0011_wirelesslan__location_wirelesslan__region_and_more', '2026-05-05 16:54:17.860963-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (681, 'wireless', '0012_alter_wirelesslan__location_and_more', '2026-05-05 16:54:18.343574-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (682, 'wireless', '0013_natural_ordering', '2026-05-05 16:54:18.449048-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (683, 'wireless', '0014_wirelesslangroup_comments', '2026-05-05 16:54:18.530367-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (684, 'wireless', '0015_extend_wireless_link_abs_distance_upper_limit', '2026-05-05 16:54:18.62167-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (685, 'social_django', '0002_add_related_name', '2026-05-05 16:54:18.627179-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (686, 'social_django', '0003_alter_email_max_length', '2026-05-05 16:54:18.627799-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (687, 'social_django', '0005_auto_20160727_2333', '2026-05-05 16:54:18.628312-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (688, 'social_django', '0004_auto_20160423_0400', '2026-05-05 16:54:18.628658-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (689, 'social_django', '0001_initial', '2026-05-05 16:54:18.628971-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (690, 'core', '0001_squashed_0005', '2026-05-05 16:54:18.629396-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (691, 'circuits', '0002_squashed_0029', '2026-05-05 16:54:18.62976-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (692, 'circuits', '0001_squashed', '2026-05-05 16:54:18.630051-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (693, 'circuits', '0038_squashed_0042', '2026-05-05 16:54:18.630339-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (694, 'circuits', '0003_squashed_0037', '2026-05-05 16:54:18.630617-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (695, 'dcim', '0003_squashed_0130', '2026-05-05 16:54:18.631102-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (696, 'dcim', '0167_squashed_0182', '2026-05-05 16:54:18.631387-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (697, 'dcim', '0002_squashed', '2026-05-05 16:54:18.631662-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (698, 'dcim', '0131_squashed_0159', '2026-05-05 16:54:18.631971-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (699, 'dcim', '0001_squashed', '2026-05-05 16:54:18.632268-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (700, 'dcim', '0160_squashed_0166', '2026-05-05 16:54:18.632566-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (701, 'ipam', '0047_squashed_0053', '2026-05-05 16:54:18.632868-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (705, 'extras', '0002_squashed_0059', '2026-05-05 16:54:18.634064-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (706, 'extras', '0001_squashed', '2026-05-05 16:54:18.634396-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (707, 'extras', '0087_squashed_0098', '2026-05-05 16:54:18.63469-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (708, 'extras', '0060_squashed_0086', '2026-05-05 16:54:18.634973-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (709, 'tenancy', '0001_squashed_0012', '2026-05-05 16:54:18.635275-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (710, 'tenancy', '0002_squashed_0011', '2026-05-05 16:54:18.63557-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (711, 'users', '0002_squashed_0004', '2026-05-05 16:54:18.635853-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (712, 'users', '0001_squashed_0011', '2026-05-05 16:54:18.636143-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (713, 'virtualization', '0023_squashed_0036', '2026-05-05 16:54:18.636434-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (714, 'virtualization', '0001_squashed_0022', '2026-05-05 16:54:18.636737-07');
INSERT INTO __BRANCH_SCHEMA__.django_migrations VALUES (715, 'wireless', '0001_squashed_0008', '2026-05-05 16:54:18.63702-07');


--
-- Data for Name: extras_cachedvalue; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('6fe7c04a-46fd-452a-9066-8aa09b8c145f', '2026-05-05 16:53:53.405998-07', 1, 'name', 'str', 'CPU', 100, 10);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('57f93b16-3d04-4e3c-8f5f-567828ec6e2b', '2026-05-05 16:53:53.414802-07', 2, 'name', 'str', 'Fan', 100, 10);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('348c9e86-e1ab-4290-bf12-c5a715fbf1bc', '2026-05-05 16:53:53.421446-07', 3, 'name', 'str', 'GPU', 100, 10);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('9d80ffd1-8d9f-4b72-b81f-052bbb44087d', '2026-05-05 16:53:53.427639-07', 4, 'name', 'str', 'Hard disk', 100, 10);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('5178a183-ef56-42c2-9d93-3453acf860d0', '2026-05-05 16:53:53.433717-07', 5, 'name', 'str', 'Memory', 100, 10);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('846b6ed4-7f57-4346-988c-1c0332275cc7', '2026-05-05 16:53:53.439726-07', 6, 'name', 'str', 'Power supply', 100, 10);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('36d063c0-699f-48db-90d4-799065cf3a81', '2026-05-05 16:53:53.444973-07', 7, 'name', 'str', 'Expansion card', 100, 10);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('bf51cc87-437d-4376-8337-d76019c0c84a', '2026-05-05 16:54:44.724054-07', 1, 'name', 'str', '_fixture_dump', 100, 154);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('f74d7c4c-883f-4a7f-9c07-863e833f95d9', '2026-05-05 16:54:45.6629-07', 1, 'name', 'str', 'Fixture Tag A', 100, 102);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('448c32e7-3a35-480b-be68-39299bb2a1cb', '2026-05-05 16:54:45.662925-07', 1, 'slug', 'str', 'fixture-tag-a', 110, 102);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('8b5bab56-36b1-4d58-bf86-5134ffcf407d', '2026-05-05 16:54:45.677149-07', 2, 'name', 'str', 'Fixture Tag B', 100, 102);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('15574d1f-4a94-491d-80d3-750ca550f74c', '2026-05-05 16:54:45.677173-07', 2, 'slug', 'str', 'fixture-tag-b', 110, 102);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('5b558077-0f9e-405b-9ebe-60fa8a77e253', '2026-05-05 16:54:45.723911-07', 1, 'name', 'str', 'Acme Holdings', 100, 126);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('42ad9726-f8a0-4aa9-874d-b8b7478ded4d', '2026-05-05 16:54:45.723938-07', 1, 'slug', 'str', 'acme-holdings', 110, 126);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('92108f8f-ee37-4d36-8e47-099b2d2f5f81', '2026-05-05 16:54:45.747925-07', 2, 'name', 'str', 'Acme Subsidiary', 100, 126);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('e8b18452-be46-4f47-8c02-4957df8d09d5', '2026-05-05 16:54:45.747952-07', 2, 'slug', 'str', 'acme-subsidiary', 110, 126);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('99075075-dae9-46e6-b8a4-98d9b883b022', '2026-05-05 16:54:45.773736-07', 1, 'name', 'str', 'Acme Corp', 100, 127);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('6b7e5fc4-36b5-46a4-a76f-bb07717335fc', '2026-05-05 16:54:45.773764-07', 1, 'slug', 'str', 'acme-corp', 110, 127);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('aea08946-40da-432c-a4d3-b090119ddc68', '2026-05-05 16:54:45.83284-07', 1, 'name', 'str', 'Test RIR', 100, 90);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('b8cd7501-e234-464e-ad96-2febe4f8b051', '2026-05-05 16:54:45.832869-07', 1, 'slug', 'str', 'test-rir', 110, 90);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('ee6ff8e1-2928-4cbc-a669-01eb64ca1ccc', '2026-05-05 16:54:45.853529-07', 1, 'asn', 'int', '64512', 100, 85);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('068d7ced-787e-4a55-8287-6beab0b234d7', '2026-05-05 16:54:45.853552-07', 1, 'prefixed_name', 'str', 'AS64512', 110, 85);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('c6ef4e1e-566b-41fe-9a3c-aa6f122e8fdf', '2026-05-05 16:54:45.871598-07', 2, 'asn', 'int', '64513', 100, 85);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('7043577c-97c7-4ca7-8ee5-a690ca94c340', '2026-05-05 16:54:45.871619-07', 2, 'prefixed_name', 'str', 'AS64513', 110, 85);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('81dd32ac-eb02-42a6-b3d1-8a0a4e0421a1', '2026-05-05 16:54:45.922737-07', 1, 'name', 'str', 'North America', 100, 81);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('8ecf9480-4df6-43e3-b424-f3d4eab0b09f', '2026-05-05 16:54:45.922759-07', 1, 'slug', 'str', 'north-america', 110, 81);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('f5be48ba-ad72-4801-bd21-d56a352e7155', '2026-05-05 16:54:45.941386-07', 2, 'name', 'str', 'United States', 100, 81);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('018e10ca-7ef2-452b-b77b-51dbd516bd98', '2026-05-05 16:54:45.941406-07', 2, 'slug', 'str', 'united-states', 110, 81);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('32f371cf-58c8-4dd6-8dd5-07ba29623c1e', '2026-05-05 16:54:45.96267-07', 1, 'name', 'str', 'Datacenters', 100, 82);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('d967e58d-7fa3-491c-97d4-7e5ecc93e8c8', '2026-05-05 16:54:45.96269-07', 1, 'slug', 'str', 'datacenters', 110, 82);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('46008ca0-61bf-4c1f-999a-406466455816', '2026-05-05 16:54:45.982559-07', 2, 'name', 'str', 'Edge', 100, 82);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('ab987489-cf2e-48fd-af50-5208c63f8102', '2026-05-05 16:54:45.982582-07', 2, 'slug', 'str', 'edge', 110, 82);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('6b82b64c-13e5-4bc4-bf33-6a88453f3862', '2026-05-05 16:54:46.016513-07', 1, 'name', 'str', 'Test Site', 100, 6);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('6c9fe2a2-09e8-4595-97fe-61d7ec6745c6', '2026-05-05 16:54:46.016537-07', 1, 'slug', 'str', 'test-site', 110, 6);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('0ac1eca6-889c-43a7-bfde-1b2bd65bae03', '2026-05-05 16:54:46.127327-07', 1, 'name', 'str', 'Building A', 100, 83);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('62bcdf26-ab26-4c0c-88ce-fea34d87bb15', '2026-05-05 16:54:46.127353-07', 1, 'slug', 'str', 'bldg-a', 110, 83);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('6f940ffc-4633-4818-8896-84487a90e14e', '2026-05-05 16:54:46.155483-07', 2, 'name', 'str', 'Floor 1', 100, 83);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('7bf0e0a0-b444-41f9-98f2-6a5e3ce117d3', '2026-05-05 16:54:46.155513-07', 2, 'slug', 'str', 'floor-1', 110, 83);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('d6b8190c-9a4e-4fce-82fb-a569c8806600', '2026-05-05 16:54:46.200567-07', 3, 'name', 'str', 'Room 101', 100, 83);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('2d53b70e-1d75-423c-8449-2c59670ca8f4', '2026-05-05 16:54:46.200593-07', 3, 'slug', 'str', 'room-101', 110, 83);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('866282e0-4724-4aff-a6cb-1599bc9f5b4e', '2026-05-05 16:54:46.245774-07', 1, 'name', 'str', 'Cisco', 100, 68);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('cb9381f3-eba7-4743-a798-d72a5fc6faa9', '2026-05-05 16:54:46.245803-07', 1, 'slug', 'str', 'cisco', 110, 68);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('991fa0a6-da36-4c63-b66f-dd1b133c2678', '2026-05-05 16:54:46.286387-07', 1, 'model', 'str', 'Test Device Type', 100, 69);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('b28cf711-7dff-42f2-b3e0-42eb32760b23', '2026-05-05 16:54:46.332861-07', 1, 'name', 'str', 'Test Role', 100, 70);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('0a1cfd31-719e-4809-8746-383e7d63c8c5', '2026-05-05 16:54:46.332891-07', 1, 'slug', 'str', 'test-role', 110, 70);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('d1eb6643-5a95-4663-9d42-b403c6d6b8e7', '2026-05-05 16:54:46.375892-07', 1, 'name', 'str', 'Test Platform', 100, 71);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('2b5ca94d-347f-4e30-a6eb-e3d9a33d2792', '2026-05-05 16:54:46.375923-07', 1, 'slug', 'str', 'test-platform', 110, 71);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('bca5d6d8-deec-4f9a-abc9-4b755adcd6ef', '2026-05-05 16:54:46.519455-07', 1, 'name', 'str', 'Rack-01', 100, 79);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('d31ad971-b0cc-4f1f-846c-dfc13a548df2', '2026-05-05 16:54:46.568798-07', 1, 'name', 'str', 'Test Device', 100, 12);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('478332b7-ee1b-4310-ab10-5ba350dd2bda', '2026-05-05 16:54:46.672266-07', 1, 'name', 'str', 'Rear1', 100, 48);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('2dd5054f-d1a3-4af7-9723-280c37665ede', '2026-05-05 16:54:46.731007-07', 1, 'name', 'str', 'Front1', 100, 47);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('829628f9-6c9f-406a-96e0-99c5856afff4', '2026-05-05 16:54:46.93887-07', 1, 'name', 'str', 'eth0', 100, 9);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('de8c2a54-80e5-483e-a232-7dba50168cc4', '2026-05-05 16:54:47.133451-07', 1, 'name', 'str', 'Test VRF', 100, 88);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('f45727fc-60c1-4899-bb58-a2b70fd8e2d2', '2026-05-05 16:54:47.133509-07', 1, 'rd', 'str', '65000:1', 200, 88);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('612ce7d8-6cc7-434d-8787-2f0a64def8c7', '2026-05-05 16:54:47.21704-07', 1, 'prefix', 'cidr', '10.0.0.0/8', 120, 91);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('254fda40-8474-42bf-b7f6-61b4c1bb1311', '2026-05-05 16:54:47.296992-07', 1, 'prefix', 'cidr', '10.0.0.0/24', 110, 93);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('3bd70f25-44e6-4ae8-965f-a39bb9b507ed', '2026-05-05 16:54:47.359742-07', 1, 'address', 'inet', '10.0.0.1/24', 100, 95);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('c06f5161-8906-4585-a704-7599fb1431fb', '2026-05-05 16:54:47.420071-07', 1, 'name', 'str', 'Test VLAN Group', 100, 98);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('21a5115a-8ffa-4534-90f2-50478350e0f2', '2026-05-05 16:54:47.420136-07', 1, 'slug', 'str', 'test-vlan-group', 110, 98);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('ee18758c-3162-45b8-ad61-05928b0ae89a', '2026-05-05 16:54:47.493219-07', 1, 'name', 'str', 'Test VLAN', 100, 99);
INSERT INTO __BRANCH_SCHEMA__.extras_cachedvalue VALUES ('f70c455d-ebcb-41cf-be31-0eb5daf23deb', '2026-05-05 16:54:47.493265-07', 1, 'vid', 'int', '100', 100, 99);


--
-- Data for Name: extras_configcontext; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_cluster_groups; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_cluster_types; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_clusters; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_device_types; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_locations; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_platforms; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_regions; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_roles; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_site_groups; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_sites; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_tags; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_tenant_groups; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontext_tenants; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configcontextprofile; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_configtemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_imageattachment; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_journalentry; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_tableconfig; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_tag; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.extras_tag VALUES ('Fixture Tag A', 'fixture-tag-a', '2026-05-05 16:54:45.61837-07', '2026-05-05 16:54:45.61838-07', 1, '9e9e9e', '', 1000);
INSERT INTO __BRANCH_SCHEMA__.extras_tag VALUES ('Fixture Tag B', 'fixture-tag-b', '2026-05-05 16:54:45.664277-07', '2026-05-05 16:54:45.664283-07', 2, '9e9e9e', '', 1000);


--
-- Data for Name: extras_tag_object_types; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: extras_taggeditem; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.extras_taggeditem VALUES (1, 1, 127, 1);
INSERT INTO __BRANCH_SCHEMA__.extras_taggeditem VALUES (1, 2, 6, 1);
INSERT INTO __BRANCH_SCHEMA__.extras_taggeditem VALUES (1, 3, 6, 2);
INSERT INTO __BRANCH_SCHEMA__.extras_taggeditem VALUES (1, 4, 12, 1);
INSERT INTO __BRANCH_SCHEMA__.extras_taggeditem VALUES (1, 5, 12, 2);
INSERT INTO __BRANCH_SCHEMA__.extras_taggeditem VALUES (1, 6, 9, 1);


--
-- Data for Name: ipam_aggregate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.ipam_aggregate VALUES ('2026-05-05 16:54:47.152963-07', '2026-05-05 16:54:47.152978-07', '{}', 1, '10.0.0.0/8', NULL, '', 1, 1, '');


--
-- Data for Name: ipam_asn; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.ipam_asn VALUES ('2026-05-05 16:54:45.836646-07', '2026-05-05 16:54:45.836652-07', '{}', 1, 64512, '', 1, NULL, '');
INSERT INTO __BRANCH_SCHEMA__.ipam_asn VALUES ('2026-05-05 16:54:45.857088-07', '2026-05-05 16:54:45.857094-07', '{}', 2, 64513, '', 1, NULL, '');


--
-- Data for Name: ipam_asnrange; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_fhrpgroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_fhrpgroupassignment; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_ipaddress; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.ipam_ipaddress VALUES ('2026-05-05 16:54:47.306097-07', '2026-05-05 16:54:47.306107-07', '{}', 1, '10.0.0.1/24', 'active', NULL, 1, '', '', 9, NULL, 1, 1, '');


--
-- Data for Name: ipam_iprange; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_prefix; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.ipam_prefix VALUES ('2026-05-05 16:54:47.227409-07', '2026-05-05 16:54:47.227424-07', '{}', 1, '10.0.0.0/24', 'active', false, '', NULL, 1, NULL, 1, 0, 0, false, '', 1, 6, NULL, 2, 1, 2);


--
-- Data for Name: ipam_rir; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.ipam_rir VALUES ('2026-05-05 16:54:45.801687-07', '2026-05-05 16:54:45.801696-07', '{}', 1, 'Test RIR', 'test-rir', false, '');


--
-- Data for Name: ipam_role; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_routetarget; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_service; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_service_ipaddresses; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_servicetemplate; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_vlan; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.ipam_vlan VALUES ('2026-05-05 16:54:47.431129-07', '2026-05-05 16:54:47.431149-07', '{}', 1, 100, 'Test VLAN', 'active', '', 1, NULL, NULL, 1, '', NULL, NULL);


--
-- Data for Name: ipam_vlangroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.ipam_vlangroup VALUES ('2026-05-05 16:54:47.370901-07', '2026-05-05 16:54:47.37091-07', '{}', 1, 'Test VLAN Group', 'test-vlan-group', NULL, '', NULL, '{"[1,4095)"}', 4093, NULL);


--
-- Data for Name: ipam_vlantranslationpolicy; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_vlantranslationrule; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_vrf; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.ipam_vrf VALUES ('2026-05-05 16:54:47.054422-07', '2026-05-05 16:54:47.054453-07', '{}', 1, 'Test VRF', '65000:1', true, '', 1, '');


--
-- Data for Name: ipam_vrf_export_targets; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: ipam_vrf_import_targets; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: tenancy_contact; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: tenancy_contact_groups; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: tenancy_contactassignment; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: tenancy_contactgroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: tenancy_contactrole; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: tenancy_tenant; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.tenancy_tenant VALUES ('2026-05-05 16:54:45.753328-07', '2026-05-05 16:54:45.753337-07', '{}', 1, 'Acme Corp', 'acme-corp', '', '', 2);


--
-- Data for Name: tenancy_tenantgroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--

INSERT INTO __BRANCH_SCHEMA__.tenancy_tenantgroup VALUES ('2026-05-05 16:54:45.692501-07', '2026-05-05 16:54:45.692514-07', '{}', 1, 'Acme Holdings', 'acme-holdings', '', 1, 4, 1, 0, NULL, '');
INSERT INTO __BRANCH_SCHEMA__.tenancy_tenantgroup VALUES ('2026-05-05 16:54:45.72985-07', '2026-05-05 16:54:45.729862-07', '{}', 2, 'Acme Subsidiary', 'acme-subsidiary', '', 2, 3, 1, 1, 1, '');


--
-- Data for Name: virtualization_cluster; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: virtualization_clustergroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: virtualization_clustertype; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: virtualization_virtualdisk; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: virtualization_virtualmachine; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: virtualization_vminterface; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: virtualization_vminterface_tagged_vlans; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_ikepolicy; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_ikepolicy_proposals; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_ikeproposal; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_ipsecpolicy; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_ipsecpolicy_proposals; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_ipsecprofile; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_ipsecproposal; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_l2vpn; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_l2vpn_export_targets; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_l2vpn_import_targets; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_l2vpntermination; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_tunnel; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_tunnelgroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: vpn_tunneltermination; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: wireless_wirelesslan; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: wireless_wirelesslangroup; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Data for Name: wireless_wirelesslink; Type: TABLE DATA; Schema: __BRANCH_SCHEMA__; Owner: -
--



--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: __BRANCH_SCHEMA__; Owner: -
--

SELECT pg_catalog.setval('__BRANCH_SCHEMA__.django_migrations_id_seq', 716, false);


--
-- Name: circuits_circuit circuits_circuit_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuit
    ADD CONSTRAINT circuits_circuit_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuit circuits_circuit_unique_provider_cid; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuit
    ADD CONSTRAINT circuits_circuit_unique_provider_cid UNIQUE (provider_id, cid);


--
-- Name: circuits_circuit circuits_circuit_unique_provideraccount_cid; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuit
    ADD CONSTRAINT circuits_circuit_unique_provideraccount_cid UNIQUE (provider_account_id, cid);


--
-- Name: circuits_circuitgroup circuits_circuitgroup_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuitgroup
    ADD CONSTRAINT circuits_circuitgroup_name_key UNIQUE (name);


--
-- Name: circuits_circuitgroup circuits_circuitgroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuitgroup
    ADD CONSTRAINT circuits_circuitgroup_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuitgroup circuits_circuitgroup_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuitgroup
    ADD CONSTRAINT circuits_circuitgroup_slug_key UNIQUE (slug);


--
-- Name: circuits_circuitgroupassignment circuits_circuitgroupassignment_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuitgroupassignment
    ADD CONSTRAINT circuits_circuitgroupassignment_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuitgroupassignment circuits_circuitgroupassignment_unique_member_group; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuitgroupassignment
    ADD CONSTRAINT circuits_circuitgroupassignment_unique_member_group UNIQUE (member_type_id, member_id, group_id);


--
-- Name: circuits_circuittermination circuits_circuittermination_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuittermination
    ADD CONSTRAINT circuits_circuittermination_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuittermination circuits_circuittermination_unique_circuit_term_side; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuittermination
    ADD CONSTRAINT circuits_circuittermination_unique_circuit_term_side UNIQUE (circuit_id, term_side);


--
-- Name: circuits_circuittype circuits_circuittype_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuittype
    ADD CONSTRAINT circuits_circuittype_name_key UNIQUE (name);


--
-- Name: circuits_circuittype circuits_circuittype_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuittype
    ADD CONSTRAINT circuits_circuittype_pkey PRIMARY KEY (id);


--
-- Name: circuits_circuittype circuits_circuittype_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_circuittype
    ADD CONSTRAINT circuits_circuittype_slug_key UNIQUE (slug);


--
-- Name: circuits_provider_asns circuits_provider_asns_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_provider_asns
    ADD CONSTRAINT circuits_provider_asns_pkey PRIMARY KEY (id);


--
-- Name: circuits_provider_asns circuits_provider_asns_provider_id_asn_id_6e573798_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_provider_asns
    ADD CONSTRAINT circuits_provider_asns_provider_id_asn_id_6e573798_uniq UNIQUE (provider_id, asn_id);


--
-- Name: circuits_provider circuits_provider_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_provider
    ADD CONSTRAINT circuits_provider_name_key UNIQUE (name);


--
-- Name: circuits_provider circuits_provider_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_provider
    ADD CONSTRAINT circuits_provider_pkey PRIMARY KEY (id);


--
-- Name: circuits_provider circuits_provider_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_provider
    ADD CONSTRAINT circuits_provider_slug_key UNIQUE (slug);


--
-- Name: circuits_provideraccount circuits_provideraccount_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_provideraccount
    ADD CONSTRAINT circuits_provideraccount_pkey PRIMARY KEY (id);


--
-- Name: circuits_provideraccount circuits_provideraccount_unique_provider_account; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_provideraccount
    ADD CONSTRAINT circuits_provideraccount_unique_provider_account UNIQUE (provider_id, account);


--
-- Name: circuits_providernetwork circuits_providernetwork_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_providernetwork
    ADD CONSTRAINT circuits_providernetwork_pkey PRIMARY KEY (id);


--
-- Name: circuits_providernetwork circuits_providernetwork_unique_provider_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_providernetwork
    ADD CONSTRAINT circuits_providernetwork_unique_provider_name UNIQUE (provider_id, name);


--
-- Name: circuits_virtualcircuit circuits_virtualcircuit_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcircuit_pkey PRIMARY KEY (id);


--
-- Name: circuits_virtualcircuit circuits_virtualcircuit_unique_provider_network_cid; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcircuit_unique_provider_network_cid UNIQUE (provider_network_id, cid);


--
-- Name: circuits_virtualcircuit circuits_virtualcircuit_unique_provideraccount_cid; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_virtualcircuit
    ADD CONSTRAINT circuits_virtualcircuit_unique_provideraccount_cid UNIQUE (provider_account_id, cid);


--
-- Name: circuits_virtualcircuittermination circuits_virtualcircuittermination_interface_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_virtualcircuittermination
    ADD CONSTRAINT circuits_virtualcircuittermination_interface_id_key UNIQUE (interface_id);


--
-- Name: circuits_virtualcircuittermination circuits_virtualcircuittermination_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_virtualcircuittermination
    ADD CONSTRAINT circuits_virtualcircuittermination_pkey PRIMARY KEY (id);


--
-- Name: circuits_virtualcircuittype circuits_virtualcircuittype_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_virtualcircuittype
    ADD CONSTRAINT circuits_virtualcircuittype_name_key UNIQUE (name);


--
-- Name: circuits_virtualcircuittype circuits_virtualcircuittype_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_virtualcircuittype
    ADD CONSTRAINT circuits_virtualcircuittype_pkey PRIMARY KEY (id);


--
-- Name: circuits_virtualcircuittype circuits_virtualcircuittype_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.circuits_virtualcircuittype
    ADD CONSTRAINT circuits_virtualcircuittype_slug_key UNIQUE (slug);


--
-- Name: core_objectchange core_objectchange_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.core_objectchange
    ADD CONSTRAINT core_objectchange_pkey PRIMARY KEY (id);


--
-- Name: dcim_cable dcim_cable_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_cable
    ADD CONSTRAINT dcim_cable_pkey PRIMARY KEY (id);


--
-- Name: dcim_cablepath dcim_cablepath_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_cablepath
    ADD CONSTRAINT dcim_cablepath_pkey PRIMARY KEY (id);


--
-- Name: dcim_cabletermination dcim_cabletermination_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination_pkey PRIMARY KEY (id);


--
-- Name: dcim_cabletermination dcim_cabletermination_unique_termination; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_cabletermination
    ADD CONSTRAINT dcim_cabletermination_unique_termination UNIQUE (termination_type_id, termination_id);


--
-- Name: dcim_consoleport dcim_consoleport_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport_pkey PRIMARY KEY (id);


--
-- Name: dcim_consoleport dcim_consoleport_unique_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleport
    ADD CONSTRAINT dcim_consoleport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_consoleporttemplate dcim_consoleporttemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleporttemplate
    ADD CONSTRAINT dcim_consoleporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_consoleporttemplate dcim_consoleporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleporttemplate
    ADD CONSTRAINT dcim_consoleporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_consoleporttemplate dcim_consoleporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleporttemplate
    ADD CONSTRAINT dcim_consoleporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_consoleserverport dcim_consoleserverport_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport_pkey PRIMARY KEY (id);


--
-- Name: dcim_consoleserverport dcim_consoleserverport_unique_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleserverport
    ADD CONSTRAINT dcim_consoleserverport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_consoleserverporttemplate dcim_consoleserverporttemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleserverporttemplate
    ADD CONSTRAINT dcim_consoleserverporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_consoleserverporttemplate dcim_consoleserverporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleserverporttemplate
    ADD CONSTRAINT dcim_consoleserverporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_consoleserverporttemplate dcim_consoleserverporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_consoleserverporttemplate
    ADD CONSTRAINT dcim_consoleserverporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_device dcim_device_asset_tag_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_device
    ADD CONSTRAINT dcim_device_asset_tag_key UNIQUE (asset_tag);


--
-- Name: dcim_device dcim_device_oob_ip_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_device
    ADD CONSTRAINT dcim_device_oob_ip_id_key UNIQUE (oob_ip_id);


--
-- Name: dcim_device dcim_device_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_device
    ADD CONSTRAINT dcim_device_pkey PRIMARY KEY (id);


--
-- Name: dcim_device dcim_device_primary_ip4_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_device
    ADD CONSTRAINT dcim_device_primary_ip4_id_key UNIQUE (primary_ip4_id);


--
-- Name: dcim_device dcim_device_primary_ip6_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_device
    ADD CONSTRAINT dcim_device_primary_ip6_id_key UNIQUE (primary_ip6_id);


--
-- Name: dcim_device dcim_device_unique_rack_position_face; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_device
    ADD CONSTRAINT dcim_device_unique_rack_position_face UNIQUE (rack_id, "position", face);


--
-- Name: dcim_device dcim_device_unique_virtual_chassis_vc_position; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_device
    ADD CONSTRAINT dcim_device_unique_virtual_chassis_vc_position UNIQUE (virtual_chassis_id, vc_position);


--
-- Name: dcim_devicebay dcim_devicebay_installed_device_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_installed_device_id_key UNIQUE (installed_device_id);


--
-- Name: dcim_devicebay dcim_devicebay_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_pkey PRIMARY KEY (id);


--
-- Name: dcim_devicebay dcim_devicebay_unique_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicebay
    ADD CONSTRAINT dcim_devicebay_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_devicebaytemplate dcim_devicebaytemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicebaytemplate
    ADD CONSTRAINT dcim_devicebaytemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_devicebaytemplate dcim_devicebaytemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicebaytemplate
    ADD CONSTRAINT dcim_devicebaytemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_devicerole dcim_devicerole_parent_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_parent_name UNIQUE (parent_id, name);


--
-- Name: dcim_devicerole dcim_devicerole_parent_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_parent_slug UNIQUE (parent_id, slug);


--
-- Name: dcim_devicerole dcim_devicerole_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicerole
    ADD CONSTRAINT dcim_devicerole_pkey PRIMARY KEY (id);


--
-- Name: dcim_devicetype dcim_devicetype_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_pkey PRIMARY KEY (id);


--
-- Name: dcim_devicetype dcim_devicetype_unique_manufacturer_model; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_unique_manufacturer_model UNIQUE (manufacturer_id, model);


--
-- Name: dcim_devicetype dcim_devicetype_unique_manufacturer_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_devicetype
    ADD CONSTRAINT dcim_devicetype_unique_manufacturer_slug UNIQUE (manufacturer_id, slug);


--
-- Name: dcim_frontport dcim_frontport_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_frontport
    ADD CONSTRAINT dcim_frontport_pkey PRIMARY KEY (id);


--
-- Name: dcim_frontport dcim_frontport_unique_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_frontport
    ADD CONSTRAINT dcim_frontport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_frontport dcim_frontport_unique_rear_port_position; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_frontport
    ADD CONSTRAINT dcim_frontport_unique_rear_port_position UNIQUE (rear_port_id, rear_port_position);


--
-- Name: dcim_frontporttemplate dcim_frontporttemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_frontporttemplate dcim_frontporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_frontporttemplate dcim_frontporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_frontporttemplate dcim_frontporttemplate_unique_rear_port_position; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_frontporttemplate
    ADD CONSTRAINT dcim_frontporttemplate_unique_rear_port_position UNIQUE (rear_port_id, rear_port_position);


--
-- Name: dcim_interface dcim_interface_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface
    ADD CONSTRAINT dcim_interface_pkey PRIMARY KEY (id);


--
-- Name: dcim_interface dcim_interface_primary_mac_address_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface
    ADD CONSTRAINT dcim_interface_primary_mac_address_id_key UNIQUE (primary_mac_address_id);


--
-- Name: dcim_interface_tagged_vlans dcim_interface_tagged_vlans_interface_id_vlan_id_0d55c576_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface_tagged_vlans
    ADD CONSTRAINT dcim_interface_tagged_vlans_interface_id_vlan_id_0d55c576_uniq UNIQUE (interface_id, vlan_id);


--
-- Name: dcim_interface_tagged_vlans dcim_interface_tagged_vlans_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface_tagged_vlans
    ADD CONSTRAINT dcim_interface_tagged_vlans_pkey PRIMARY KEY (id);


--
-- Name: dcim_interface dcim_interface_unique_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface
    ADD CONSTRAINT dcim_interface_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_interface_vdcs dcim_interface_vdcs_interface_id_virtualdevi_cca9c2a6_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface_vdcs
    ADD CONSTRAINT dcim_interface_vdcs_interface_id_virtualdevi_cca9c2a6_uniq UNIQUE (interface_id, virtualdevicecontext_id);


--
-- Name: dcim_interface_vdcs dcim_interface_vdcs_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface_vdcs
    ADD CONSTRAINT dcim_interface_vdcs_pkey PRIMARY KEY (id);


--
-- Name: dcim_interface_wireless_lans dcim_interface_wireless__interface_id_wirelesslan_b52fb3d8_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface_wireless_lans
    ADD CONSTRAINT dcim_interface_wireless__interface_id_wirelesslan_b52fb3d8_uniq UNIQUE (interface_id, wirelesslan_id);


--
-- Name: dcim_interface_wireless_lans dcim_interface_wireless_lans_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interface_wireless_lans
    ADD CONSTRAINT dcim_interface_wireless_lans_pkey PRIMARY KEY (id);


--
-- Name: dcim_interfacetemplate dcim_interfacetemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_interfacetemplate dcim_interfacetemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_interfacetemplate dcim_interfacetemplate_unique_module_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_interfacetemplate
    ADD CONSTRAINT dcim_interfacetemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_inventoryitem dcim_inventoryitem_asset_tag_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_asset_tag_key UNIQUE (asset_tag);


--
-- Name: dcim_inventoryitem dcim_inventoryitem_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_pkey PRIMARY KEY (id);


--
-- Name: dcim_inventoryitem dcim_inventoryitem_unique_device_parent_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_inventoryitem
    ADD CONSTRAINT dcim_inventoryitem_unique_device_parent_name UNIQUE (device_id, parent_id, name);


--
-- Name: dcim_inventoryitemrole dcim_inventoryitemrole_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_inventoryitemrole
    ADD CONSTRAINT dcim_inventoryitemrole_name_key UNIQUE (name);


--
-- Name: dcim_inventoryitemrole dcim_inventoryitemrole_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_inventoryitemrole
    ADD CONSTRAINT dcim_inventoryitemrole_pkey PRIMARY KEY (id);


--
-- Name: dcim_inventoryitemrole dcim_inventoryitemrole_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_inventoryitemrole
    ADD CONSTRAINT dcim_inventoryitemrole_slug_key UNIQUE (slug);


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemtemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemtemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_inventoryitemtemplate dcim_inventoryitemtemplate_unique_device_type_parent_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_inventoryitemtemplate
    ADD CONSTRAINT dcim_inventoryitemtemplate_unique_device_type_parent_name UNIQUE (device_type_id, parent_id, name);


--
-- Name: dcim_location dcim_location_parent_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_location
    ADD CONSTRAINT dcim_location_parent_name UNIQUE (site_id, parent_id, name);


--
-- Name: dcim_location dcim_location_parent_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_location
    ADD CONSTRAINT dcim_location_parent_slug UNIQUE (site_id, parent_id, slug);


--
-- Name: dcim_location dcim_location_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_location
    ADD CONSTRAINT dcim_location_pkey PRIMARY KEY (id);


--
-- Name: dcim_macaddress dcim_macaddress_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_macaddress
    ADD CONSTRAINT dcim_macaddress_pkey PRIMARY KEY (id);


--
-- Name: dcim_manufacturer dcim_manufacturer_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_manufacturer
    ADD CONSTRAINT dcim_manufacturer_name_key UNIQUE (name);


--
-- Name: dcim_manufacturer dcim_manufacturer_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_manufacturer
    ADD CONSTRAINT dcim_manufacturer_pkey PRIMARY KEY (id);


--
-- Name: dcim_manufacturer dcim_manufacturer_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_manufacturer
    ADD CONSTRAINT dcim_manufacturer_slug_key UNIQUE (slug);


--
-- Name: dcim_module dcim_module_asset_tag_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_module
    ADD CONSTRAINT dcim_module_asset_tag_key UNIQUE (asset_tag);


--
-- Name: dcim_module dcim_module_module_bay_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_module
    ADD CONSTRAINT dcim_module_module_bay_id_key UNIQUE (module_bay_id);


--
-- Name: dcim_module dcim_module_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_module
    ADD CONSTRAINT dcim_module_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebay dcim_modulebay_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebay dcim_modulebay_unique_device_module_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_modulebay
    ADD CONSTRAINT dcim_modulebay_unique_device_module_name UNIQUE (device_id, module_id, name);


--
-- Name: dcim_modulebaytemplate dcim_modulebaytemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_modulebaytemplate
    ADD CONSTRAINT dcim_modulebaytemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_modulebaytemplate dcim_modulebaytemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_modulebaytemplate
    ADD CONSTRAINT dcim_modulebaytemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_modulebaytemplate dcim_modulebaytemplate_unique_module_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_modulebaytemplate
    ADD CONSTRAINT dcim_modulebaytemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_moduletype dcim_moduletype_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_moduletype
    ADD CONSTRAINT dcim_moduletype_pkey PRIMARY KEY (id);


--
-- Name: dcim_moduletype dcim_moduletype_unique_manufacturer_model; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_moduletype
    ADD CONSTRAINT dcim_moduletype_unique_manufacturer_model UNIQUE (manufacturer_id, model);


--
-- Name: dcim_moduletypeprofile dcim_moduletypeprofile_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_moduletypeprofile
    ADD CONSTRAINT dcim_moduletypeprofile_name_key UNIQUE (name);


--
-- Name: dcim_moduletypeprofile dcim_moduletypeprofile_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_moduletypeprofile
    ADD CONSTRAINT dcim_moduletypeprofile_pkey PRIMARY KEY (id);


--
-- Name: dcim_platform dcim_platform_manufacturer_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_platform
    ADD CONSTRAINT dcim_platform_manufacturer_name UNIQUE (manufacturer_id, name);


--
-- Name: dcim_platform dcim_platform_manufacturer_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_platform
    ADD CONSTRAINT dcim_platform_manufacturer_slug UNIQUE (manufacturer_id, slug);


--
-- Name: dcim_platform dcim_platform_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_platform
    ADD CONSTRAINT dcim_platform_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerfeed dcim_powerfeed_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerfeed dcim_powerfeed_unique_power_panel_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerfeed
    ADD CONSTRAINT dcim_powerfeed_unique_power_panel_name UNIQUE (power_panel_id, name);


--
-- Name: dcim_poweroutlet dcim_poweroutlet_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_pkey PRIMARY KEY (id);


--
-- Name: dcim_poweroutlet dcim_poweroutlet_unique_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_poweroutlet
    ADD CONSTRAINT dcim_poweroutlet_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_poweroutlettemplate dcim_poweroutlettemplate_unique_module_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_poweroutlettemplate
    ADD CONSTRAINT dcim_poweroutlettemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_powerpanel dcim_powerpanel_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerpanel
    ADD CONSTRAINT dcim_powerpanel_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerpanel dcim_powerpanel_unique_site_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerpanel
    ADD CONSTRAINT dcim_powerpanel_unique_site_name UNIQUE (site_id, name);


--
-- Name: dcim_powerport dcim_powerport_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerport
    ADD CONSTRAINT dcim_powerport_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerport dcim_powerport_unique_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerport
    ADD CONSTRAINT dcim_powerport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_powerporttemplate dcim_powerporttemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerporttemplate
    ADD CONSTRAINT dcim_powerporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_powerporttemplate dcim_powerporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerporttemplate
    ADD CONSTRAINT dcim_powerporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_powerporttemplate dcim_powerporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_powerporttemplate
    ADD CONSTRAINT dcim_powerporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_rack dcim_rack_asset_tag_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rack
    ADD CONSTRAINT dcim_rack_asset_tag_key UNIQUE (asset_tag);


--
-- Name: dcim_rack dcim_rack_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rack
    ADD CONSTRAINT dcim_rack_pkey PRIMARY KEY (id);


--
-- Name: dcim_rack dcim_rack_unique_location_facility_id; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rack
    ADD CONSTRAINT dcim_rack_unique_location_facility_id UNIQUE (location_id, facility_id);


--
-- Name: dcim_rack dcim_rack_unique_location_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rack
    ADD CONSTRAINT dcim_rack_unique_location_name UNIQUE (location_id, name);


--
-- Name: dcim_rackreservation dcim_rackreservation_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rackreservation
    ADD CONSTRAINT dcim_rackreservation_pkey PRIMARY KEY (id);


--
-- Name: dcim_rackrole dcim_rackrole_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rackrole
    ADD CONSTRAINT dcim_rackrole_name_key UNIQUE (name);


--
-- Name: dcim_rackrole dcim_rackrole_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rackrole
    ADD CONSTRAINT dcim_rackrole_pkey PRIMARY KEY (id);


--
-- Name: dcim_rackrole dcim_rackrole_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rackrole
    ADD CONSTRAINT dcim_rackrole_slug_key UNIQUE (slug);


--
-- Name: dcim_racktype dcim_racktype_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_racktype
    ADD CONSTRAINT dcim_racktype_pkey PRIMARY KEY (id);


--
-- Name: dcim_racktype dcim_racktype_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_racktype
    ADD CONSTRAINT dcim_racktype_slug_key UNIQUE (slug);


--
-- Name: dcim_racktype dcim_racktype_unique_manufacturer_model; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_racktype
    ADD CONSTRAINT dcim_racktype_unique_manufacturer_model UNIQUE (manufacturer_id, model);


--
-- Name: dcim_racktype dcim_racktype_unique_manufacturer_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_racktype
    ADD CONSTRAINT dcim_racktype_unique_manufacturer_slug UNIQUE (manufacturer_id, slug);


--
-- Name: dcim_rearport dcim_rearport_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rearport
    ADD CONSTRAINT dcim_rearport_pkey PRIMARY KEY (id);


--
-- Name: dcim_rearport dcim_rearport_unique_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rearport
    ADD CONSTRAINT dcim_rearport_unique_device_name UNIQUE (device_id, name);


--
-- Name: dcim_rearporttemplate dcim_rearporttemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rearporttemplate
    ADD CONSTRAINT dcim_rearporttemplate_pkey PRIMARY KEY (id);


--
-- Name: dcim_rearporttemplate dcim_rearporttemplate_unique_device_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rearporttemplate
    ADD CONSTRAINT dcim_rearporttemplate_unique_device_type_name UNIQUE (device_type_id, name);


--
-- Name: dcim_rearporttemplate dcim_rearporttemplate_unique_module_type_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_rearporttemplate
    ADD CONSTRAINT dcim_rearporttemplate_unique_module_type_name UNIQUE (module_type_id, name);


--
-- Name: dcim_region dcim_region_parent_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_region
    ADD CONSTRAINT dcim_region_parent_name UNIQUE (parent_id, name);


--
-- Name: dcim_region dcim_region_parent_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_region
    ADD CONSTRAINT dcim_region_parent_slug UNIQUE (parent_id, slug);


--
-- Name: dcim_region dcim_region_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_region
    ADD CONSTRAINT dcim_region_pkey PRIMARY KEY (id);


--
-- Name: dcim_site_asns dcim_site_asns_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_site_asns
    ADD CONSTRAINT dcim_site_asns_pkey PRIMARY KEY (id);


--
-- Name: dcim_site_asns dcim_site_asns_site_id_asn_id_1a5a6f23_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_site_asns
    ADD CONSTRAINT dcim_site_asns_site_id_asn_id_1a5a6f23_uniq UNIQUE (site_id, asn_id);


--
-- Name: dcim_site dcim_site_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_site
    ADD CONSTRAINT dcim_site_name_key UNIQUE (name);


--
-- Name: dcim_site dcim_site_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_site
    ADD CONSTRAINT dcim_site_pkey PRIMARY KEY (id);


--
-- Name: dcim_site dcim_site_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_site
    ADD CONSTRAINT dcim_site_slug_key UNIQUE (slug);


--
-- Name: dcim_sitegroup dcim_sitegroup_parent_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_sitegroup
    ADD CONSTRAINT dcim_sitegroup_parent_name UNIQUE (parent_id, name);


--
-- Name: dcim_sitegroup dcim_sitegroup_parent_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_sitegroup
    ADD CONSTRAINT dcim_sitegroup_parent_slug UNIQUE (parent_id, slug);


--
-- Name: dcim_sitegroup dcim_sitegroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_sitegroup
    ADD CONSTRAINT dcim_sitegroup_pkey PRIMARY KEY (id);


--
-- Name: dcim_virtualchassis dcim_virtualchassis_master_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_virtualchassis
    ADD CONSTRAINT dcim_virtualchassis_master_id_key UNIQUE (master_id);


--
-- Name: dcim_virtualchassis dcim_virtualchassis_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_virtualchassis
    ADD CONSTRAINT dcim_virtualchassis_pkey PRIMARY KEY (id);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_device_identifier; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_device_identifier UNIQUE (device_id, identifier);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_device_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_device_name UNIQUE (device_id, name);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_pkey PRIMARY KEY (id);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_primary_ip4_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_primary_ip4_id_key UNIQUE (primary_ip4_id);


--
-- Name: dcim_virtualdevicecontext dcim_virtualdevicecontext_primary_ip6_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.dcim_virtualdevicecontext
    ADD CONSTRAINT dcim_virtualdevicecontext_primary_ip6_id_key UNIQUE (primary_ip6_id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: extras_cachedvalue extras_cachedvalue_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_cachedvalue
    ADD CONSTRAINT extras_cachedvalue_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_clusters extras_configcontext_clu_configcontext_id_cluster_0c7e5d20_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_clusters
    ADD CONSTRAINT extras_configcontext_clu_configcontext_id_cluster_0c7e5d20_uniq UNIQUE (configcontext_id, cluster_id);


--
-- Name: extras_configcontext_cluster_types extras_configcontext_clu_configcontext_id_cluster_4a2d5e56_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_cluster_types
    ADD CONSTRAINT extras_configcontext_clu_configcontext_id_cluster_4a2d5e56_uniq UNIQUE (configcontext_id, clustertype_id);


--
-- Name: extras_configcontext_cluster_groups extras_configcontext_clu_configcontext_id_cluster_bc530192_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_cluster_groups
    ADD CONSTRAINT extras_configcontext_clu_configcontext_id_cluster_bc530192_uniq UNIQUE (configcontext_id, clustergroup_id);


--
-- Name: extras_configcontext_cluster_groups extras_configcontext_cluster_groups_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_cluster_groups
    ADD CONSTRAINT extras_configcontext_cluster_groups_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_cluster_types extras_configcontext_cluster_types_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_cluster_types
    ADD CONSTRAINT extras_configcontext_cluster_types_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_clusters extras_configcontext_clusters_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_clusters
    ADD CONSTRAINT extras_configcontext_clusters_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_device_types extras_configcontext_dev_configcontext_id_devicet_a0aaba6f_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_device_types
    ADD CONSTRAINT extras_configcontext_dev_configcontext_id_devicet_a0aaba6f_uniq UNIQUE (configcontext_id, devicetype_id);


--
-- Name: extras_configcontext_device_types extras_configcontext_device_types_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_device_types
    ADD CONSTRAINT extras_configcontext_device_types_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_locations extras_configcontext_loc_configcontext_id_locatio_15d9b342_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_locations
    ADD CONSTRAINT extras_configcontext_loc_configcontext_id_locatio_15d9b342_uniq UNIQUE (configcontext_id, location_id);


--
-- Name: extras_configcontext_locations extras_configcontext_locations_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_locations
    ADD CONSTRAINT extras_configcontext_locations_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext extras_configcontext_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext
    ADD CONSTRAINT extras_configcontext_name_key UNIQUE (name);


--
-- Name: extras_configcontext extras_configcontext_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext
    ADD CONSTRAINT extras_configcontext_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_platforms extras_configcontext_pla_configcontext_id_platfor_3c67c104_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_platforms
    ADD CONSTRAINT extras_configcontext_pla_configcontext_id_platfor_3c67c104_uniq UNIQUE (configcontext_id, platform_id);


--
-- Name: extras_configcontext_platforms extras_configcontext_platforms_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_platforms
    ADD CONSTRAINT extras_configcontext_platforms_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_regions extras_configcontext_reg_configcontext_id_region__d4a1d77f_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_regions
    ADD CONSTRAINT extras_configcontext_reg_configcontext_id_region__d4a1d77f_uniq UNIQUE (configcontext_id, region_id);


--
-- Name: extras_configcontext_regions extras_configcontext_regions_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_regions
    ADD CONSTRAINT extras_configcontext_regions_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_roles extras_configcontext_rol_configcontext_id_devicer_4d8dbb50_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_roles
    ADD CONSTRAINT extras_configcontext_rol_configcontext_id_devicer_4d8dbb50_uniq UNIQUE (configcontext_id, devicerole_id);


--
-- Name: extras_configcontext_roles extras_configcontext_roles_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_roles
    ADD CONSTRAINT extras_configcontext_roles_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_sites extras_configcontext_sit_configcontext_id_site_id_a4fe5f4f_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_sites
    ADD CONSTRAINT extras_configcontext_sit_configcontext_id_site_id_a4fe5f4f_uniq UNIQUE (configcontext_id, site_id);


--
-- Name: extras_configcontext_site_groups extras_configcontext_sit_configcontext_id_sitegro_4caa52ec_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_site_groups
    ADD CONSTRAINT extras_configcontext_sit_configcontext_id_sitegro_4caa52ec_uniq UNIQUE (configcontext_id, sitegroup_id);


--
-- Name: extras_configcontext_site_groups extras_configcontext_site_groups_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_site_groups
    ADD CONSTRAINT extras_configcontext_site_groups_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_sites extras_configcontext_sites_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_sites
    ADD CONSTRAINT extras_configcontext_sites_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_tags extras_configcontext_tags_configcontext_id_tag_id_f6c53016_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_tags
    ADD CONSTRAINT extras_configcontext_tags_configcontext_id_tag_id_f6c53016_uniq UNIQUE (configcontext_id, tag_id);


--
-- Name: extras_configcontext_tags extras_configcontext_tags_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_tags
    ADD CONSTRAINT extras_configcontext_tags_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_tenants extras_configcontext_ten_configcontext_id_tenant__aefb257d_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_tenants
    ADD CONSTRAINT extras_configcontext_ten_configcontext_id_tenant__aefb257d_uniq UNIQUE (configcontext_id, tenant_id);


--
-- Name: extras_configcontext_tenant_groups extras_configcontext_ten_configcontext_id_tenantg_d6afc6f5_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_tenant_groups
    ADD CONSTRAINT extras_configcontext_ten_configcontext_id_tenantg_d6afc6f5_uniq UNIQUE (configcontext_id, tenantgroup_id);


--
-- Name: extras_configcontext_tenant_groups extras_configcontext_tenant_groups_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_tenant_groups
    ADD CONSTRAINT extras_configcontext_tenant_groups_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontext_tenants extras_configcontext_tenants_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontext_tenants
    ADD CONSTRAINT extras_configcontext_tenants_pkey PRIMARY KEY (id);


--
-- Name: extras_configcontextprofile extras_configcontextprofile_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontextprofile
    ADD CONSTRAINT extras_configcontextprofile_name_key UNIQUE (name);


--
-- Name: extras_configcontextprofile extras_configcontextprofile_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configcontextprofile
    ADD CONSTRAINT extras_configcontextprofile_pkey PRIMARY KEY (id);


--
-- Name: extras_configtemplate extras_configtemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_configtemplate
    ADD CONSTRAINT extras_configtemplate_pkey PRIMARY KEY (id);


--
-- Name: extras_imageattachment extras_imageattachment_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_imageattachment
    ADD CONSTRAINT extras_imageattachment_pkey PRIMARY KEY (id);


--
-- Name: extras_journalentry extras_journalentry_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_journalentry
    ADD CONSTRAINT extras_journalentry_pkey PRIMARY KEY (id);


--
-- Name: extras_tableconfig extras_tableconfig_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_tableconfig
    ADD CONSTRAINT extras_tableconfig_pkey PRIMARY KEY (id);


--
-- Name: extras_tag extras_tag_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_tag
    ADD CONSTRAINT extras_tag_name_key UNIQUE (name);


--
-- Name: extras_tag_object_types extras_tag_object_types_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_tag_object_types
    ADD CONSTRAINT extras_tag_object_types_pkey PRIMARY KEY (id);


--
-- Name: extras_tag_object_types extras_tag_object_types_tag_id_contenttype_id_2ff9910c_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_tag_object_types
    ADD CONSTRAINT extras_tag_object_types_tag_id_contenttype_id_2ff9910c_uniq UNIQUE (tag_id, contenttype_id);


--
-- Name: extras_tag extras_tag_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_tag
    ADD CONSTRAINT extras_tag_pkey PRIMARY KEY (id);


--
-- Name: extras_tag extras_tag_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_tag
    ADD CONSTRAINT extras_tag_slug_key UNIQUE (slug);


--
-- Name: extras_taggeditem extras_taggeditem_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.extras_taggeditem
    ADD CONSTRAINT extras_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: ipam_aggregate ipam_aggregate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_aggregate
    ADD CONSTRAINT ipam_aggregate_pkey PRIMARY KEY (id);


--
-- Name: ipam_asn ipam_asn_asn_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_asn
    ADD CONSTRAINT ipam_asn_asn_key UNIQUE (asn);


--
-- Name: ipam_asn ipam_asn_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_asn
    ADD CONSTRAINT ipam_asn_pkey PRIMARY KEY (id);


--
-- Name: ipam_asnrange ipam_asnrange_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_name_key UNIQUE (name);


--
-- Name: ipam_asnrange ipam_asnrange_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_pkey PRIMARY KEY (id);


--
-- Name: ipam_asnrange ipam_asnrange_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_asnrange
    ADD CONSTRAINT ipam_asnrange_slug_key UNIQUE (slug);


--
-- Name: ipam_fhrpgroup ipam_fhrpgroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_fhrpgroup
    ADD CONSTRAINT ipam_fhrpgroup_pkey PRIMARY KEY (id);


--
-- Name: ipam_fhrpgroupassignment ipam_fhrpgroupassignment_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_fhrpgroupassignment
    ADD CONSTRAINT ipam_fhrpgroupassignment_pkey PRIMARY KEY (id);


--
-- Name: ipam_fhrpgroupassignment ipam_fhrpgroupassignment_unique_interface_group; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_fhrpgroupassignment
    ADD CONSTRAINT ipam_fhrpgroupassignment_unique_interface_group UNIQUE (interface_type_id, interface_id, group_id);


--
-- Name: ipam_ipaddress ipam_ipaddress_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_ipaddress
    ADD CONSTRAINT ipam_ipaddress_pkey PRIMARY KEY (id);


--
-- Name: ipam_iprange ipam_iprange_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_iprange
    ADD CONSTRAINT ipam_iprange_pkey PRIMARY KEY (id);


--
-- Name: vpn_l2vpn_export_targets ipam_l2vpn_export_targets_l2vpn_id_routetarget_id_eea90661_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpn_export_targets
    ADD CONSTRAINT ipam_l2vpn_export_targets_l2vpn_id_routetarget_id_eea90661_uniq UNIQUE (l2vpn_id, routetarget_id);


--
-- Name: vpn_l2vpn_export_targets ipam_l2vpn_export_targets_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpn_export_targets
    ADD CONSTRAINT ipam_l2vpn_export_targets_pkey PRIMARY KEY (id);


--
-- Name: vpn_l2vpn_import_targets ipam_l2vpn_import_targets_l2vpn_id_routetarget_id_96af344c_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpn_import_targets
    ADD CONSTRAINT ipam_l2vpn_import_targets_l2vpn_id_routetarget_id_96af344c_uniq UNIQUE (l2vpn_id, routetarget_id);


--
-- Name: vpn_l2vpn_import_targets ipam_l2vpn_import_targets_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpn_import_targets
    ADD CONSTRAINT ipam_l2vpn_import_targets_pkey PRIMARY KEY (id);


--
-- Name: ipam_prefix ipam_prefix_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_prefix
    ADD CONSTRAINT ipam_prefix_pkey PRIMARY KEY (id);


--
-- Name: ipam_rir ipam_rir_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_rir
    ADD CONSTRAINT ipam_rir_name_key UNIQUE (name);


--
-- Name: ipam_rir ipam_rir_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_rir
    ADD CONSTRAINT ipam_rir_pkey PRIMARY KEY (id);


--
-- Name: ipam_rir ipam_rir_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_rir
    ADD CONSTRAINT ipam_rir_slug_key UNIQUE (slug);


--
-- Name: ipam_role ipam_role_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_role
    ADD CONSTRAINT ipam_role_name_key UNIQUE (name);


--
-- Name: ipam_role ipam_role_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_role
    ADD CONSTRAINT ipam_role_pkey PRIMARY KEY (id);


--
-- Name: ipam_role ipam_role_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_role
    ADD CONSTRAINT ipam_role_slug_key UNIQUE (slug);


--
-- Name: ipam_routetarget ipam_routetarget_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_routetarget
    ADD CONSTRAINT ipam_routetarget_name_key UNIQUE (name);


--
-- Name: ipam_routetarget ipam_routetarget_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_routetarget
    ADD CONSTRAINT ipam_routetarget_pkey PRIMARY KEY (id);


--
-- Name: ipam_service_ipaddresses ipam_service_ipaddresses_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_service_ipaddresses
    ADD CONSTRAINT ipam_service_ipaddresses_pkey PRIMARY KEY (id);


--
-- Name: ipam_service_ipaddresses ipam_service_ipaddresses_service_id_ipaddress_id_d019a805_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_service_ipaddresses
    ADD CONSTRAINT ipam_service_ipaddresses_service_id_ipaddress_id_d019a805_uniq UNIQUE (service_id, ipaddress_id);


--
-- Name: ipam_service ipam_service_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_service
    ADD CONSTRAINT ipam_service_pkey PRIMARY KEY (id);


--
-- Name: ipam_servicetemplate ipam_servicetemplate_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_servicetemplate
    ADD CONSTRAINT ipam_servicetemplate_name_key UNIQUE (name);


--
-- Name: ipam_servicetemplate ipam_servicetemplate_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_servicetemplate
    ADD CONSTRAINT ipam_servicetemplate_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlan ipam_vlan_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlan
    ADD CONSTRAINT ipam_vlan_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlan ipam_vlan_unique_group_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlan
    ADD CONSTRAINT ipam_vlan_unique_group_name UNIQUE (group_id, name);


--
-- Name: ipam_vlan ipam_vlan_unique_group_vid; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlan
    ADD CONSTRAINT ipam_vlan_unique_group_vid UNIQUE (group_id, vid);


--
-- Name: ipam_vlan ipam_vlan_unique_qinq_svlan_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlan
    ADD CONSTRAINT ipam_vlan_unique_qinq_svlan_name UNIQUE (qinq_svlan_id, name);


--
-- Name: ipam_vlan ipam_vlan_unique_qinq_svlan_vid; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlan
    ADD CONSTRAINT ipam_vlan_unique_qinq_svlan_vid UNIQUE (qinq_svlan_id, vid);


--
-- Name: ipam_vlangroup ipam_vlangroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlangroup ipam_vlangroup_unique_scope_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_unique_scope_name UNIQUE (scope_type_id, scope_id, name);


--
-- Name: ipam_vlangroup ipam_vlangroup_unique_scope_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlangroup
    ADD CONSTRAINT ipam_vlangroup_unique_scope_slug UNIQUE (scope_type_id, scope_id, slug);


--
-- Name: ipam_vlantranslationpolicy ipam_vlantranslationpolicy_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlantranslationpolicy
    ADD CONSTRAINT ipam_vlantranslationpolicy_name_key UNIQUE (name);


--
-- Name: ipam_vlantranslationpolicy ipam_vlantranslationpolicy_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlantranslationpolicy
    ADD CONSTRAINT ipam_vlantranslationpolicy_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlantranslationrule ipam_vlantranslationrule_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlantranslationrule
    ADD CONSTRAINT ipam_vlantranslationrule_pkey PRIMARY KEY (id);


--
-- Name: ipam_vlantranslationrule ipam_vlantranslationrule_unique_policy_local_vid; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlantranslationrule
    ADD CONSTRAINT ipam_vlantranslationrule_unique_policy_local_vid UNIQUE (policy_id, local_vid);


--
-- Name: ipam_vlantranslationrule ipam_vlantranslationrule_unique_policy_remote_vid; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vlantranslationrule
    ADD CONSTRAINT ipam_vlantranslationrule_unique_policy_remote_vid UNIQUE (policy_id, remote_vid);


--
-- Name: ipam_vrf_export_targets ipam_vrf_export_targets_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vrf_export_targets
    ADD CONSTRAINT ipam_vrf_export_targets_pkey PRIMARY KEY (id);


--
-- Name: ipam_vrf_export_targets ipam_vrf_export_targets_vrf_id_routetarget_id_63ba8c62_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vrf_export_targets
    ADD CONSTRAINT ipam_vrf_export_targets_vrf_id_routetarget_id_63ba8c62_uniq UNIQUE (vrf_id, routetarget_id);


--
-- Name: ipam_vrf_import_targets ipam_vrf_import_targets_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vrf_import_targets
    ADD CONSTRAINT ipam_vrf_import_targets_pkey PRIMARY KEY (id);


--
-- Name: ipam_vrf_import_targets ipam_vrf_import_targets_vrf_id_routetarget_id_399b155f_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vrf_import_targets
    ADD CONSTRAINT ipam_vrf_import_targets_vrf_id_routetarget_id_399b155f_uniq UNIQUE (vrf_id, routetarget_id);


--
-- Name: ipam_vrf ipam_vrf_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vrf
    ADD CONSTRAINT ipam_vrf_pkey PRIMARY KEY (id);


--
-- Name: ipam_vrf ipam_vrf_rd_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.ipam_vrf
    ADD CONSTRAINT ipam_vrf_rd_key UNIQUE (rd);


--
-- Name: tenancy_contact_groups tenancy_contact_groups_contact_id_contactgroup_id_f4434f2c_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contact_groups
    ADD CONSTRAINT tenancy_contact_groups_contact_id_contactgroup_id_f4434f2c_uniq UNIQUE (contactgroup_id, contact_id);


--
-- Name: tenancy_contact_groups tenancy_contact_groups_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contact_groups
    ADD CONSTRAINT tenancy_contact_groups_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contact tenancy_contact_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contact
    ADD CONSTRAINT tenancy_contact_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contactassignment tenancy_contactassignment_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contactassignment
    ADD CONSTRAINT tenancy_contactassignment_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contactassignment tenancy_contactassignment_unique_object_contact_role; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contactassignment
    ADD CONSTRAINT tenancy_contactassignment_unique_object_contact_role UNIQUE (object_type_id, object_id, contact_id, role_id);


--
-- Name: tenancy_contactgroup tenancy_contactgroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contactgroup
    ADD CONSTRAINT tenancy_contactgroup_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contactgroup tenancy_contactgroup_unique_parent_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contactgroup
    ADD CONSTRAINT tenancy_contactgroup_unique_parent_name UNIQUE (parent_id, name);


--
-- Name: tenancy_contactrole tenancy_contactrole_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contactrole
    ADD CONSTRAINT tenancy_contactrole_name_key UNIQUE (name);


--
-- Name: tenancy_contactrole tenancy_contactrole_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contactrole
    ADD CONSTRAINT tenancy_contactrole_pkey PRIMARY KEY (id);


--
-- Name: tenancy_contactrole tenancy_contactrole_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_contactrole
    ADD CONSTRAINT tenancy_contactrole_slug_key UNIQUE (slug);


--
-- Name: tenancy_tenant tenancy_tenant_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_tenant
    ADD CONSTRAINT tenancy_tenant_pkey PRIMARY KEY (id);


--
-- Name: tenancy_tenant tenancy_tenant_unique_group_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_tenant
    ADD CONSTRAINT tenancy_tenant_unique_group_name UNIQUE (group_id, name);


--
-- Name: tenancy_tenant tenancy_tenant_unique_group_slug; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_tenant
    ADD CONSTRAINT tenancy_tenant_unique_group_slug UNIQUE (group_id, slug);


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_tenantgroup
    ADD CONSTRAINT tenancy_tenantgroup_name_key UNIQUE (name);


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_tenantgroup
    ADD CONSTRAINT tenancy_tenantgroup_pkey PRIMARY KEY (id);


--
-- Name: tenancy_tenantgroup tenancy_tenantgroup_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.tenancy_tenantgroup
    ADD CONSTRAINT tenancy_tenantgroup_slug_key UNIQUE (slug);


--
-- Name: virtualization_cluster virtualization_cluster_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster_pkey PRIMARY KEY (id);


--
-- Name: virtualization_cluster virtualization_cluster_unique__site_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster_unique__site_name UNIQUE (_site_id, name);


--
-- Name: virtualization_cluster virtualization_cluster_unique_group_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_cluster
    ADD CONSTRAINT virtualization_cluster_unique_group_name UNIQUE (group_id, name);


--
-- Name: virtualization_clustergroup virtualization_clustergroup_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_clustergroup
    ADD CONSTRAINT virtualization_clustergroup_name_key UNIQUE (name);


--
-- Name: virtualization_clustergroup virtualization_clustergroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_clustergroup
    ADD CONSTRAINT virtualization_clustergroup_pkey PRIMARY KEY (id);


--
-- Name: virtualization_clustergroup virtualization_clustergroup_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_clustergroup
    ADD CONSTRAINT virtualization_clustergroup_slug_key UNIQUE (slug);


--
-- Name: virtualization_clustertype virtualization_clustertype_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_clustertype
    ADD CONSTRAINT virtualization_clustertype_name_key UNIQUE (name);


--
-- Name: virtualization_clustertype virtualization_clustertype_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_clustertype
    ADD CONSTRAINT virtualization_clustertype_pkey PRIMARY KEY (id);


--
-- Name: virtualization_clustertype virtualization_clustertype_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_clustertype
    ADD CONSTRAINT virtualization_clustertype_slug_key UNIQUE (slug);


--
-- Name: virtualization_virtualdisk virtualization_virtualdisk_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_virtualdisk
    ADD CONSTRAINT virtualization_virtualdisk_pkey PRIMARY KEY (id);


--
-- Name: virtualization_virtualdisk virtualization_virtualdisk_unique_virtual_machine_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_virtualdisk
    ADD CONSTRAINT virtualization_virtualdisk_unique_virtual_machine_name UNIQUE (virtual_machine_id, name);


--
-- Name: virtualization_virtualmachine virtualization_virtualmachine_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtualmachine_pkey PRIMARY KEY (id);


--
-- Name: virtualization_virtualmachine virtualization_virtualmachine_primary_ip4_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtualmachine_primary_ip4_id_key UNIQUE (primary_ip4_id);


--
-- Name: virtualization_virtualmachine virtualization_virtualmachine_primary_ip6_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_virtualmachine
    ADD CONSTRAINT virtualization_virtualmachine_primary_ip6_id_key UNIQUE (primary_ip6_id);


--
-- Name: virtualization_vminterface_tagged_vlans virtualization_vminterfa_vminterface_id_vlan_id_27e907db_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_vminterface_tagged_vlans
    ADD CONSTRAINT virtualization_vminterfa_vminterface_id_vlan_id_27e907db_uniq UNIQUE (vminterface_id, vlan_id);


--
-- Name: virtualization_vminterface virtualization_vminterface_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_vminterface
    ADD CONSTRAINT virtualization_vminterface_pkey PRIMARY KEY (id);


--
-- Name: virtualization_vminterface virtualization_vminterface_primary_mac_address_id_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_vminterface
    ADD CONSTRAINT virtualization_vminterface_primary_mac_address_id_key UNIQUE (primary_mac_address_id);


--
-- Name: virtualization_vminterface_tagged_vlans virtualization_vminterface_tagged_vlans_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_vminterface_tagged_vlans
    ADD CONSTRAINT virtualization_vminterface_tagged_vlans_pkey PRIMARY KEY (id);


--
-- Name: virtualization_vminterface virtualization_vminterface_unique_virtual_machine_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.virtualization_vminterface
    ADD CONSTRAINT virtualization_vminterface_unique_virtual_machine_name UNIQUE (virtual_machine_id, name);


--
-- Name: vpn_ikepolicy vpn_ikepolicy_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ikepolicy
    ADD CONSTRAINT vpn_ikepolicy_name_key UNIQUE (name);


--
-- Name: vpn_ikepolicy vpn_ikepolicy_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ikepolicy
    ADD CONSTRAINT vpn_ikepolicy_pkey PRIMARY KEY (id);


--
-- Name: vpn_ikepolicy_proposals vpn_ikepolicy_proposals_ikepolicy_id_ikeproposal_0c3baa9c_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ikepolicy_proposals
    ADD CONSTRAINT vpn_ikepolicy_proposals_ikepolicy_id_ikeproposal_0c3baa9c_uniq UNIQUE (ikepolicy_id, ikeproposal_id);


--
-- Name: vpn_ikepolicy_proposals vpn_ikepolicy_proposals_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ikepolicy_proposals
    ADD CONSTRAINT vpn_ikepolicy_proposals_pkey PRIMARY KEY (id);


--
-- Name: vpn_ikeproposal vpn_ikeproposal_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ikeproposal
    ADD CONSTRAINT vpn_ikeproposal_name_key UNIQUE (name);


--
-- Name: vpn_ikeproposal vpn_ikeproposal_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ikeproposal
    ADD CONSTRAINT vpn_ikeproposal_pkey PRIMARY KEY (id);


--
-- Name: vpn_ipsecpolicy vpn_ipsecpolicy_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ipsecpolicy
    ADD CONSTRAINT vpn_ipsecpolicy_name_key UNIQUE (name);


--
-- Name: vpn_ipsecpolicy vpn_ipsecpolicy_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ipsecpolicy
    ADD CONSTRAINT vpn_ipsecpolicy_pkey PRIMARY KEY (id);


--
-- Name: vpn_ipsecpolicy_proposals vpn_ipsecpolicy_proposal_ipsecpolicy_id_ipsecprop_72096768_uniq; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ipsecpolicy_proposals
    ADD CONSTRAINT vpn_ipsecpolicy_proposal_ipsecpolicy_id_ipsecprop_72096768_uniq UNIQUE (ipsecpolicy_id, ipsecproposal_id);


--
-- Name: vpn_ipsecpolicy_proposals vpn_ipsecpolicy_proposals_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ipsecpolicy_proposals
    ADD CONSTRAINT vpn_ipsecpolicy_proposals_pkey PRIMARY KEY (id);


--
-- Name: vpn_ipsecprofile vpn_ipsecprofile_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ipsecprofile
    ADD CONSTRAINT vpn_ipsecprofile_name_key UNIQUE (name);


--
-- Name: vpn_ipsecprofile vpn_ipsecprofile_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ipsecprofile
    ADD CONSTRAINT vpn_ipsecprofile_pkey PRIMARY KEY (id);


--
-- Name: vpn_ipsecproposal vpn_ipsecproposal_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ipsecproposal
    ADD CONSTRAINT vpn_ipsecproposal_name_key UNIQUE (name);


--
-- Name: vpn_ipsecproposal vpn_ipsecproposal_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_ipsecproposal
    ADD CONSTRAINT vpn_ipsecproposal_pkey PRIMARY KEY (id);


--
-- Name: vpn_l2vpn vpn_l2vpn_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpn
    ADD CONSTRAINT vpn_l2vpn_name_key UNIQUE (name);


--
-- Name: vpn_l2vpn vpn_l2vpn_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpn
    ADD CONSTRAINT vpn_l2vpn_pkey PRIMARY KEY (id);


--
-- Name: vpn_l2vpn vpn_l2vpn_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpn
    ADD CONSTRAINT vpn_l2vpn_slug_key UNIQUE (slug);


--
-- Name: vpn_l2vpntermination vpn_l2vpntermination_assigned_object; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpntermination
    ADD CONSTRAINT vpn_l2vpntermination_assigned_object UNIQUE (assigned_object_type_id, assigned_object_id);


--
-- Name: vpn_l2vpntermination vpn_l2vpntermination_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_l2vpntermination
    ADD CONSTRAINT vpn_l2vpntermination_pkey PRIMARY KEY (id);


--
-- Name: vpn_tunnel vpn_tunnel_group_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_group_name UNIQUE (group_id, name);


--
-- Name: vpn_tunnel vpn_tunnel_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_name_key UNIQUE (name);


--
-- Name: vpn_tunnel vpn_tunnel_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_tunnel
    ADD CONSTRAINT vpn_tunnel_pkey PRIMARY KEY (id);


--
-- Name: vpn_tunnelgroup vpn_tunnelgroup_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_tunnelgroup
    ADD CONSTRAINT vpn_tunnelgroup_name_key UNIQUE (name);


--
-- Name: vpn_tunnelgroup vpn_tunnelgroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_tunnelgroup
    ADD CONSTRAINT vpn_tunnelgroup_pkey PRIMARY KEY (id);


--
-- Name: vpn_tunnelgroup vpn_tunnelgroup_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_tunnelgroup
    ADD CONSTRAINT vpn_tunnelgroup_slug_key UNIQUE (slug);


--
-- Name: vpn_tunneltermination vpn_tunneltermination_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_tunneltermination
    ADD CONSTRAINT vpn_tunneltermination_pkey PRIMARY KEY (id);


--
-- Name: vpn_tunneltermination vpn_tunneltermination_termination; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.vpn_tunneltermination
    ADD CONSTRAINT vpn_tunneltermination_termination UNIQUE (termination_type_id, termination_id);


--
-- Name: wireless_wirelesslan wireless_wirelesslan_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.wireless_wirelesslan
    ADD CONSTRAINT wireless_wirelesslan_pkey PRIMARY KEY (id);


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_name_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslangroup_name_key UNIQUE (name);


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslangroup_pkey PRIMARY KEY (id);


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_slug_key; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslangroup_slug_key UNIQUE (slug);


--
-- Name: wireless_wirelesslangroup wireless_wirelesslangroup_unique_parent_name; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.wireless_wirelesslangroup
    ADD CONSTRAINT wireless_wirelesslangroup_unique_parent_name UNIQUE (parent_id, name);


--
-- Name: wireless_wirelesslink wireless_wirelesslink_pkey; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslink_pkey PRIMARY KEY (id);


--
-- Name: wireless_wirelesslink wireless_wirelesslink_unique_interfaces; Type: CONSTRAINT; Schema: __BRANCH_SCHEMA__; Owner: -
--

ALTER TABLE ONLY __BRANCH_SCHEMA__.wireless_wirelesslink
    ADD CONSTRAINT wireless_wirelesslink_unique_interfaces UNIQUE (interface_a_id, interface_b_id);


--
-- Name: circuits_circuit_provider_account_id_a7c8f61b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuit_provider_account_id_a7c8f61b ON __BRANCH_SCHEMA__.circuits_circuit USING btree (provider_account_id);


--
-- Name: circuits_circuit_provider_id_d9195418; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuit_provider_id_d9195418 ON __BRANCH_SCHEMA__.circuits_circuit USING btree (provider_id);


--
-- Name: circuits_circuit_tenant_id_812508a5; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuit_tenant_id_812508a5 ON __BRANCH_SCHEMA__.circuits_circuit USING btree (tenant_id);


--
-- Name: circuits_circuit_termination_a_id_f891adac; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuit_termination_a_id_f891adac ON __BRANCH_SCHEMA__.circuits_circuit USING btree (termination_a_id);


--
-- Name: circuits_circuit_termination_z_id_377b8551; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuit_termination_z_id_377b8551 ON __BRANCH_SCHEMA__.circuits_circuit USING btree (termination_z_id);


--
-- Name: circuits_circuit_type_id_1b9f485a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuit_type_id_1b9f485a ON __BRANCH_SCHEMA__.circuits_circuit USING btree (type_id);


--
-- Name: circuits_circuitgroup_name_ec8ac1e5_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuitgroup_name_ec8ac1e5_like ON __BRANCH_SCHEMA__.circuits_circuitgroup USING btree (name varchar_pattern_ops);


--
-- Name: circuits_circuitgroup_slug_61ca866b_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuitgroup_slug_61ca866b_like ON __BRANCH_SCHEMA__.circuits_circuitgroup USING btree (slug varchar_pattern_ops);


--
-- Name: circuits_circuitgroup_tenant_id_5bafdc3f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuitgroup_tenant_id_5bafdc3f ON __BRANCH_SCHEMA__.circuits_circuitgroup USING btree (tenant_id);


--
-- Name: circuits_circuitgroupassignment_group_id_1a7b6580; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuitgroupassignment_group_id_1a7b6580 ON __BRANCH_SCHEMA__.circuits_circuitgroupassignment USING btree (group_id);


--
-- Name: circuits_circuitgroupassignment_member_type_id_779d1a13; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuitgroupassignment_member_type_id_779d1a13 ON __BRANCH_SCHEMA__.circuits_circuitgroupassignment USING btree (member_type_id);


--
-- Name: circuits_circuittermination__location_id_4a578dca; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittermination__location_id_4a578dca ON __BRANCH_SCHEMA__.circuits_circuittermination USING btree (_location_id);


--
-- Name: circuits_circuittermination__region_id_1fa03379; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittermination__region_id_1fa03379 ON __BRANCH_SCHEMA__.circuits_circuittermination USING btree (_region_id);


--
-- Name: circuits_circuittermination__site_group_id_ec0c1998; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittermination__site_group_id_ec0c1998 ON __BRANCH_SCHEMA__.circuits_circuittermination USING btree (_site_group_id);


--
-- Name: circuits_circuittermination__site_id_84942491; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittermination__site_id_84942491 ON __BRANCH_SCHEMA__.circuits_circuittermination USING btree (_site_id);


--
-- Name: circuits_circuittermination_cable_id_35e9f703; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittermination_cable_id_35e9f703 ON __BRANCH_SCHEMA__.circuits_circuittermination USING btree (cable_id);


--
-- Name: circuits_circuittermination_circuit_id_257e87e7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittermination_circuit_id_257e87e7 ON __BRANCH_SCHEMA__.circuits_circuittermination USING btree (circuit_id);


--
-- Name: circuits_circuittermination_provider_network_id_b0c660f1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittermination_provider_network_id_b0c660f1 ON __BRANCH_SCHEMA__.circuits_circuittermination USING btree (_provider_network_id);


--
-- Name: circuits_circuittermination_termination_type_id_c9262c91; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittermination_termination_type_id_c9262c91 ON __BRANCH_SCHEMA__.circuits_circuittermination USING btree (termination_type_id);


--
-- Name: circuits_circuittype_name_8256ea9a_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittype_name_8256ea9a_like ON __BRANCH_SCHEMA__.circuits_circuittype USING btree (name varchar_pattern_ops);


--
-- Name: circuits_circuittype_slug_9b4b3cf9_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_circuittype_slug_9b4b3cf9_like ON __BRANCH_SCHEMA__.circuits_circuittype USING btree (slug varchar_pattern_ops);


--
-- Name: circuits_provider_asns_asn_id_0a6c53b3; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_provider_asns_asn_id_0a6c53b3 ON __BRANCH_SCHEMA__.circuits_provider_asns USING btree (asn_id);


--
-- Name: circuits_provider_asns_provider_id_becc3f7e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_provider_asns_provider_id_becc3f7e ON __BRANCH_SCHEMA__.circuits_provider_asns USING btree (provider_id);


--
-- Name: circuits_provider_name_8f2514f5_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_provider_name_8f2514f5_like ON __BRANCH_SCHEMA__.circuits_provider USING btree (name varchar_pattern_ops);


--
-- Name: circuits_provider_slug_c3c0aa10_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_provider_slug_c3c0aa10_like ON __BRANCH_SCHEMA__.circuits_provider USING btree (slug varchar_pattern_ops);


--
-- Name: circuits_provideraccount_provider_id_4bcd7e50; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_provideraccount_provider_id_4bcd7e50 ON __BRANCH_SCHEMA__.circuits_provideraccount USING btree (provider_id);


--
-- Name: circuits_provideraccount_unique_provider_name; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX circuits_provideraccount_unique_provider_name ON __BRANCH_SCHEMA__.circuits_provideraccount USING btree (provider_id, name) WHERE (NOT ((name)::text = ''::text));


--
-- Name: circuits_providernetwork_provider_id_7992236c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_providernetwork_provider_id_7992236c ON __BRANCH_SCHEMA__.circuits_providernetwork USING btree (provider_id);


--
-- Name: circuits_virtualcircuit_provider_account_id_d942f455; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_virtualcircuit_provider_account_id_d942f455 ON __BRANCH_SCHEMA__.circuits_virtualcircuit USING btree (provider_account_id);


--
-- Name: circuits_virtualcircuit_provider_network_id_a902f409; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_virtualcircuit_provider_network_id_a902f409 ON __BRANCH_SCHEMA__.circuits_virtualcircuit USING btree (provider_network_id);


--
-- Name: circuits_virtualcircuit_tenant_id_4458eca7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_virtualcircuit_tenant_id_4458eca7 ON __BRANCH_SCHEMA__.circuits_virtualcircuit USING btree (tenant_id);


--
-- Name: circuits_virtualcircuit_type_id_8527d682; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_virtualcircuit_type_id_8527d682 ON __BRANCH_SCHEMA__.circuits_virtualcircuit USING btree (type_id);


--
-- Name: circuits_virtualcircuittermination_virtual_circuit_id_ca588886; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_virtualcircuittermination_virtual_circuit_id_ca588886 ON __BRANCH_SCHEMA__.circuits_virtualcircuittermination USING btree (virtual_circuit_id);


--
-- Name: circuits_virtualcircuittype_name_5184db16_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_virtualcircuittype_name_5184db16_like ON __BRANCH_SCHEMA__.circuits_virtualcircuittype USING btree (name varchar_pattern_ops);


--
-- Name: circuits_virtualcircuittype_slug_75d5c661_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX circuits_virtualcircuittype_slug_75d5c661_like ON __BRANCH_SCHEMA__.circuits_virtualcircuittype USING btree (slug varchar_pattern_ops);


--
-- Name: core_objectchange_changed_object_type_id_2070ade6; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX core_objectchange_changed_object_type_id_2070ade6 ON __BRANCH_SCHEMA__.core_objectchange USING btree (changed_object_type_id);


--
-- Name: core_objectchange_changed_object_type_id_cha_79a9ed1e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX core_objectchange_changed_object_type_id_cha_79a9ed1e ON __BRANCH_SCHEMA__.core_objectchange USING btree (changed_object_type_id, changed_object_id);


--
-- Name: core_objectchange_related_object_type_id_b80958af; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX core_objectchange_related_object_type_id_b80958af ON __BRANCH_SCHEMA__.core_objectchange USING btree (related_object_type_id);


--
-- Name: core_objectchange_related_object_type_id_rel_a71d604a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX core_objectchange_related_object_type_id_rel_a71d604a ON __BRANCH_SCHEMA__.core_objectchange USING btree (related_object_type_id, related_object_id);


--
-- Name: core_objectchange_request_id_d9d160ac; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX core_objectchange_request_id_d9d160ac ON __BRANCH_SCHEMA__.core_objectchange USING btree (request_id);


--
-- Name: core_objectchange_time_800f60a5; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX core_objectchange_time_800f60a5 ON __BRANCH_SCHEMA__.core_objectchange USING btree ("time");


--
-- Name: core_objectchange_user_id_2b2142be; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX core_objectchange_user_id_2b2142be ON __BRANCH_SCHEMA__.core_objectchange USING btree (user_id);


--
-- Name: dcim_cable_tenant_id_3a7fdbb8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_cable_tenant_id_3a7fdbb8 ON __BRANCH_SCHEMA__.dcim_cable USING btree (tenant_id);


--
-- Name: dcim_cabletermination__device_id_f5884934; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_cabletermination__device_id_f5884934 ON __BRANCH_SCHEMA__.dcim_cabletermination USING btree (_device_id);


--
-- Name: dcim_cabletermination__location_id_ff4be503; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_cabletermination__location_id_ff4be503 ON __BRANCH_SCHEMA__.dcim_cabletermination USING btree (_location_id);


--
-- Name: dcim_cabletermination__rack_id_83a548e1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_cabletermination__rack_id_83a548e1 ON __BRANCH_SCHEMA__.dcim_cabletermination USING btree (_rack_id);


--
-- Name: dcim_cabletermination__site_id_616962fa; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_cabletermination__site_id_616962fa ON __BRANCH_SCHEMA__.dcim_cabletermination USING btree (_site_id);


--
-- Name: dcim_cabletermination_cable_id_b50010d1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_cabletermination_cable_id_b50010d1 ON __BRANCH_SCHEMA__.dcim_cabletermination USING btree (cable_id);


--
-- Name: dcim_cabletermination_termination_type_id_20da439e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_cabletermination_termination_type_id_20da439e ON __BRANCH_SCHEMA__.dcim_cabletermination USING btree (termination_type_id);


--
-- Name: dcim_consoleport__location_id_d0e7437b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleport__location_id_d0e7437b ON __BRANCH_SCHEMA__.dcim_consoleport USING btree (_location_id);


--
-- Name: dcim_consoleport__path_id_e40a4436; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleport__path_id_e40a4436 ON __BRANCH_SCHEMA__.dcim_consoleport USING btree (_path_id);


--
-- Name: dcim_consoleport__rack_id_71f16827; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleport__rack_id_71f16827 ON __BRANCH_SCHEMA__.dcim_consoleport USING btree (_rack_id);


--
-- Name: dcim_consoleport__site_id_9652df9c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleport__site_id_9652df9c ON __BRANCH_SCHEMA__.dcim_consoleport USING btree (_site_id);


--
-- Name: dcim_consoleport_cable_id_a9ae5465; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleport_cable_id_a9ae5465 ON __BRANCH_SCHEMA__.dcim_consoleport USING btree (cable_id);


--
-- Name: dcim_consoleport_device_id_f2d90d3c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleport_device_id_f2d90d3c ON __BRANCH_SCHEMA__.dcim_consoleport USING btree (device_id);


--
-- Name: dcim_consoleport_module_id_d17b2519; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleport_module_id_d17b2519 ON __BRANCH_SCHEMA__.dcim_consoleport USING btree (module_id);


--
-- Name: dcim_consoleporttemplate_device_type_id_075d4015; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleporttemplate_device_type_id_075d4015 ON __BRANCH_SCHEMA__.dcim_consoleporttemplate USING btree (device_type_id);


--
-- Name: dcim_consoleporttemplate_module_type_id_c0f35d97; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleporttemplate_module_type_id_c0f35d97 ON __BRANCH_SCHEMA__.dcim_consoleporttemplate USING btree (module_type_id);


--
-- Name: dcim_consoleserverport__location_id_7525ec0e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverport__location_id_7525ec0e ON __BRANCH_SCHEMA__.dcim_consoleserverport USING btree (_location_id);


--
-- Name: dcim_consoleserverport__path_id_dc5abe09; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverport__path_id_dc5abe09 ON __BRANCH_SCHEMA__.dcim_consoleserverport USING btree (_path_id);


--
-- Name: dcim_consoleserverport__rack_id_3eea9f1b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverport__rack_id_3eea9f1b ON __BRANCH_SCHEMA__.dcim_consoleserverport USING btree (_rack_id);


--
-- Name: dcim_consoleserverport__site_id_c500ac62; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverport__site_id_c500ac62 ON __BRANCH_SCHEMA__.dcim_consoleserverport USING btree (_site_id);


--
-- Name: dcim_consoleserverport_cable_id_f2940dfd; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverport_cable_id_f2940dfd ON __BRANCH_SCHEMA__.dcim_consoleserverport USING btree (cable_id);


--
-- Name: dcim_consoleserverport_device_id_d9866581; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverport_device_id_d9866581 ON __BRANCH_SCHEMA__.dcim_consoleserverport USING btree (device_id);


--
-- Name: dcim_consoleserverport_module_id_d060cfc8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverport_module_id_d060cfc8 ON __BRANCH_SCHEMA__.dcim_consoleserverport USING btree (module_id);


--
-- Name: dcim_consoleserverporttemplate_device_type_id_579bdc86; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverporttemplate_device_type_id_579bdc86 ON __BRANCH_SCHEMA__.dcim_consoleserverporttemplate USING btree (device_type_id);


--
-- Name: dcim_consoleserverporttemplate_module_type_id_4abf751a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_consoleserverporttemplate_module_type_id_4abf751a ON __BRANCH_SCHEMA__.dcim_consoleserverporttemplate USING btree (module_type_id);


--
-- Name: dcim_device_asset_tag_8dac1079_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_asset_tag_8dac1079_like ON __BRANCH_SCHEMA__.dcim_device USING btree (asset_tag varchar_pattern_ops);


--
-- Name: dcim_device_cluster_id_cf852f78; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_cluster_id_cf852f78 ON __BRANCH_SCHEMA__.dcim_device USING btree (cluster_id);


--
-- Name: dcim_device_config_template_id_316328c4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_config_template_id_316328c4 ON __BRANCH_SCHEMA__.dcim_device USING btree (config_template_id);


--
-- Name: dcim_device_device_role_id_682e8188; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_device_role_id_682e8188 ON __BRANCH_SCHEMA__.dcim_device USING btree (role_id);


--
-- Name: dcim_device_device_type_id_d61b4086; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_device_type_id_d61b4086 ON __BRANCH_SCHEMA__.dcim_device USING btree (device_type_id);


--
-- Name: dcim_device_location_id_11a7bedb; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_location_id_11a7bedb ON __BRANCH_SCHEMA__.dcim_device USING btree (location_id);


--
-- Name: dcim_device_platform_id_468138f1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_platform_id_468138f1 ON __BRANCH_SCHEMA__.dcim_device USING btree (platform_id);


--
-- Name: dcim_device_rack_id_23bde71f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_rack_id_23bde71f ON __BRANCH_SCHEMA__.dcim_device USING btree (rack_id);


--
-- Name: dcim_device_site_id_ff897cf6; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_site_id_ff897cf6 ON __BRANCH_SCHEMA__.dcim_device USING btree (site_id);


--
-- Name: dcim_device_tenant_id_dcea7969; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_tenant_id_dcea7969 ON __BRANCH_SCHEMA__.dcim_device USING btree (tenant_id);


--
-- Name: dcim_device_unique_name_site; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_device_unique_name_site ON __BRANCH_SCHEMA__.dcim_device USING btree (lower((name)::text), site_id) WHERE (tenant_id IS NULL);


--
-- Name: dcim_device_unique_name_site_tenant; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_device_unique_name_site_tenant ON __BRANCH_SCHEMA__.dcim_device USING btree (lower((name)::text), site_id, tenant_id);


--
-- Name: dcim_device_virtual_chassis_id_aed51693; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_device_virtual_chassis_id_aed51693 ON __BRANCH_SCHEMA__.dcim_device USING btree (virtual_chassis_id);


--
-- Name: dcim_devicebay__location_id_6c869a87; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicebay__location_id_6c869a87 ON __BRANCH_SCHEMA__.dcim_devicebay USING btree (_location_id);


--
-- Name: dcim_devicebay__rack_id_75672431; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicebay__rack_id_75672431 ON __BRANCH_SCHEMA__.dcim_devicebay USING btree (_rack_id);


--
-- Name: dcim_devicebay__site_id_8ddc30f4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicebay__site_id_8ddc30f4 ON __BRANCH_SCHEMA__.dcim_devicebay USING btree (_site_id);


--
-- Name: dcim_devicebay_device_id_0c8a1218; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicebay_device_id_0c8a1218 ON __BRANCH_SCHEMA__.dcim_devicebay USING btree (device_id);


--
-- Name: dcim_devicebaytemplate_device_type_id_f4b24a29; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicebaytemplate_device_type_id_f4b24a29 ON __BRANCH_SCHEMA__.dcim_devicebaytemplate USING btree (device_type_id);


--
-- Name: dcim_devicerole_config_template_id_5874002c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicerole_config_template_id_5874002c ON __BRANCH_SCHEMA__.dcim_devicerole USING btree (config_template_id);


--
-- Name: dcim_devicerole_name; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_devicerole_name ON __BRANCH_SCHEMA__.dcim_devicerole USING btree (name) WHERE (parent_id IS NULL);


--
-- Name: dcim_devicerole_parent_id_7f9ccf87; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicerole_parent_id_7f9ccf87 ON __BRANCH_SCHEMA__.dcim_devicerole USING btree (parent_id);


--
-- Name: dcim_devicerole_slug; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_devicerole_slug ON __BRANCH_SCHEMA__.dcim_devicerole USING btree (slug) WHERE (parent_id IS NULL);


--
-- Name: dcim_devicerole_slug_7952643b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicerole_slug_7952643b ON __BRANCH_SCHEMA__.dcim_devicerole USING btree (slug);


--
-- Name: dcim_devicerole_slug_7952643b_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicerole_slug_7952643b_like ON __BRANCH_SCHEMA__.dcim_devicerole USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_devicerole_tree_id_196b114c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicerole_tree_id_196b114c ON __BRANCH_SCHEMA__.dcim_devicerole USING btree (tree_id);


--
-- Name: dcim_devicetype_default_platform_id_1f6ff6ac; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicetype_default_platform_id_1f6ff6ac ON __BRANCH_SCHEMA__.dcim_devicetype USING btree (default_platform_id);


--
-- Name: dcim_devicetype_manufacturer_id_a3e8029e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicetype_manufacturer_id_a3e8029e ON __BRANCH_SCHEMA__.dcim_devicetype USING btree (manufacturer_id);


--
-- Name: dcim_devicetype_slug_448745bd; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicetype_slug_448745bd ON __BRANCH_SCHEMA__.dcim_devicetype USING btree (slug);


--
-- Name: dcim_devicetype_slug_448745bd_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_devicetype_slug_448745bd_like ON __BRANCH_SCHEMA__.dcim_devicetype USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_frontport__location_id_dc0402e7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontport__location_id_dc0402e7 ON __BRANCH_SCHEMA__.dcim_frontport USING btree (_location_id);


--
-- Name: dcim_frontport__rack_id_1ba6d11c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontport__rack_id_1ba6d11c ON __BRANCH_SCHEMA__.dcim_frontport USING btree (_rack_id);


--
-- Name: dcim_frontport__site_id_51efdefe; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontport__site_id_51efdefe ON __BRANCH_SCHEMA__.dcim_frontport USING btree (_site_id);


--
-- Name: dcim_frontport_cable_id_04ff8aab; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontport_cable_id_04ff8aab ON __BRANCH_SCHEMA__.dcim_frontport USING btree (cable_id);


--
-- Name: dcim_frontport_device_id_950557b5; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontport_device_id_950557b5 ON __BRANCH_SCHEMA__.dcim_frontport USING btree (device_id);


--
-- Name: dcim_frontport_module_id_952c3f9a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontport_module_id_952c3f9a ON __BRANCH_SCHEMA__.dcim_frontport USING btree (module_id);


--
-- Name: dcim_frontport_rear_port_id_78df2532; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontport_rear_port_id_78df2532 ON __BRANCH_SCHEMA__.dcim_frontport USING btree (rear_port_id);


--
-- Name: dcim_frontporttemplate_device_type_id_f088b952; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontporttemplate_device_type_id_f088b952 ON __BRANCH_SCHEMA__.dcim_frontporttemplate USING btree (device_type_id);


--
-- Name: dcim_frontporttemplate_module_type_id_66851ff9; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontporttemplate_module_type_id_66851ff9 ON __BRANCH_SCHEMA__.dcim_frontporttemplate USING btree (module_type_id);


--
-- Name: dcim_frontporttemplate_rear_port_id_9775411b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_frontporttemplate_rear_port_id_9775411b ON __BRANCH_SCHEMA__.dcim_frontporttemplate USING btree (rear_port_id);


--
-- Name: dcim_interface__location_id_72d5e107; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface__location_id_72d5e107 ON __BRANCH_SCHEMA__.dcim_interface USING btree (_location_id);


--
-- Name: dcim_interface__path_id_f8f4f7f0; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface__path_id_f8f4f7f0 ON __BRANCH_SCHEMA__.dcim_interface USING btree (_path_id);


--
-- Name: dcim_interface__rack_id_0d3f84a6; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface__rack_id_0d3f84a6 ON __BRANCH_SCHEMA__.dcim_interface USING btree (_rack_id);


--
-- Name: dcim_interface__site_id_0fffd4ef; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface__site_id_0fffd4ef ON __BRANCH_SCHEMA__.dcim_interface USING btree (_site_id);


--
-- Name: dcim_interface_bridge_id_f2a8df85; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_bridge_id_f2a8df85 ON __BRANCH_SCHEMA__.dcim_interface USING btree (bridge_id);


--
-- Name: dcim_interface_cable_id_1b264edb; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_cable_id_1b264edb ON __BRANCH_SCHEMA__.dcim_interface USING btree (cable_id);


--
-- Name: dcim_interface_device_id_359c6115; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_device_id_359c6115 ON __BRANCH_SCHEMA__.dcim_interface USING btree (device_id);


--
-- Name: dcim_interface_lag_id_ea1a1d12; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_lag_id_ea1a1d12 ON __BRANCH_SCHEMA__.dcim_interface USING btree (lag_id);


--
-- Name: dcim_interface_module_id_05ca2da5; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_module_id_05ca2da5 ON __BRANCH_SCHEMA__.dcim_interface USING btree (module_id);


--
-- Name: dcim_interface_parent_id_3e2b159b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_parent_id_3e2b159b ON __BRANCH_SCHEMA__.dcim_interface USING btree (parent_id);


--
-- Name: dcim_interface_qinq_svlan_id_21189a58; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_qinq_svlan_id_21189a58 ON __BRANCH_SCHEMA__.dcim_interface USING btree (qinq_svlan_id);


--
-- Name: dcim_interface_tagged_vlans_interface_id_5870c9e9; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_tagged_vlans_interface_id_5870c9e9 ON __BRANCH_SCHEMA__.dcim_interface_tagged_vlans USING btree (interface_id);


--
-- Name: dcim_interface_tagged_vlans_vlan_id_e027005c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_tagged_vlans_vlan_id_e027005c ON __BRANCH_SCHEMA__.dcim_interface_tagged_vlans USING btree (vlan_id);


--
-- Name: dcim_interface_untagged_vlan_id_838dc7be; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_untagged_vlan_id_838dc7be ON __BRANCH_SCHEMA__.dcim_interface USING btree (untagged_vlan_id);


--
-- Name: dcim_interface_vdcs_interface_id_6d58dbaf; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_vdcs_interface_id_6d58dbaf ON __BRANCH_SCHEMA__.dcim_interface_vdcs USING btree (interface_id);


--
-- Name: dcim_interface_vdcs_virtualdevicecontext_id_af0bfd4b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_vdcs_virtualdevicecontext_id_af0bfd4b ON __BRANCH_SCHEMA__.dcim_interface_vdcs USING btree (virtualdevicecontext_id);


--
-- Name: dcim_interface_vlan_translation_policy_id_91060031; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_vlan_translation_policy_id_91060031 ON __BRANCH_SCHEMA__.dcim_interface USING btree (vlan_translation_policy_id);


--
-- Name: dcim_interface_vrf_id_a92e59b2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_vrf_id_a92e59b2 ON __BRANCH_SCHEMA__.dcim_interface USING btree (vrf_id);


--
-- Name: dcim_interface_wireless_lans_interface_id_80df3785; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_wireless_lans_interface_id_80df3785 ON __BRANCH_SCHEMA__.dcim_interface_wireless_lans USING btree (interface_id);


--
-- Name: dcim_interface_wireless_lans_wirelesslan_id_f081e278; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_wireless_lans_wirelesslan_id_f081e278 ON __BRANCH_SCHEMA__.dcim_interface_wireless_lans USING btree (wirelesslan_id);


--
-- Name: dcim_interface_wireless_link_id_bc91108f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interface_wireless_link_id_bc91108f ON __BRANCH_SCHEMA__.dcim_interface USING btree (wireless_link_id);


--
-- Name: dcim_interfacetemplate_bridge_id_4e44355b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interfacetemplate_bridge_id_4e44355b ON __BRANCH_SCHEMA__.dcim_interfacetemplate USING btree (bridge_id);


--
-- Name: dcim_interfacetemplate_device_type_id_4bfcbfab; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interfacetemplate_device_type_id_4bfcbfab ON __BRANCH_SCHEMA__.dcim_interfacetemplate USING btree (device_type_id);


--
-- Name: dcim_interfacetemplate_module_type_id_f941f180; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_interfacetemplate_module_type_id_f941f180 ON __BRANCH_SCHEMA__.dcim_interfacetemplate USING btree (module_type_id);


--
-- Name: dcim_invent_compone_0560bb_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_invent_compone_0560bb_idx ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (component_type_id, component_id);


--
-- Name: dcim_invent_compone_77b5f8_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_invent_compone_77b5f8_idx ON __BRANCH_SCHEMA__.dcim_inventoryitemtemplate USING btree (component_type_id, component_id);


--
-- Name: dcim_inventoryitem__location_id_05a23b33; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem__location_id_05a23b33 ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (_location_id);


--
-- Name: dcim_inventoryitem__rack_id_25b80d23; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem__rack_id_25b80d23 ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (_rack_id);


--
-- Name: dcim_inventoryitem__site_id_cd94573b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem__site_id_cd94573b ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (_site_id);


--
-- Name: dcim_inventoryitem_asset_tag_d3289273_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem_asset_tag_d3289273_like ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (asset_tag varchar_pattern_ops);


--
-- Name: dcim_inventoryitem_component_type_id_f0e4d83a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem_component_type_id_f0e4d83a ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (component_type_id);


--
-- Name: dcim_inventoryitem_device_id_033d83f8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem_device_id_033d83f8 ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (device_id);


--
-- Name: dcim_inventoryitem_manufacturer_id_dcd1b78a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem_manufacturer_id_dcd1b78a ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (manufacturer_id);


--
-- Name: dcim_inventoryitem_parent_id_7ebcd457; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem_parent_id_7ebcd457 ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (parent_id);


--
-- Name: dcim_inventoryitem_role_id_2bcfcb04; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem_role_id_2bcfcb04 ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (role_id);


--
-- Name: dcim_inventoryitem_tree_id_4676ade2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitem_tree_id_4676ade2 ON __BRANCH_SCHEMA__.dcim_inventoryitem USING btree (tree_id);


--
-- Name: dcim_inventoryitemrole_name_4c8cfe6d_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitemrole_name_4c8cfe6d_like ON __BRANCH_SCHEMA__.dcim_inventoryitemrole USING btree (name varchar_pattern_ops);


--
-- Name: dcim_inventoryitemrole_slug_3556c227_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitemrole_slug_3556c227_like ON __BRANCH_SCHEMA__.dcim_inventoryitemrole USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_inventoryitemtemplate_component_type_id_161623a2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_component_type_id_161623a2 ON __BRANCH_SCHEMA__.dcim_inventoryitemtemplate USING btree (component_type_id);


--
-- Name: dcim_inventoryitemtemplate_device_type_id_6a1be904; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_device_type_id_6a1be904 ON __BRANCH_SCHEMA__.dcim_inventoryitemtemplate USING btree (device_type_id);


--
-- Name: dcim_inventoryitemtemplate_manufacturer_id_b388c5d9; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_manufacturer_id_b388c5d9 ON __BRANCH_SCHEMA__.dcim_inventoryitemtemplate USING btree (manufacturer_id);


--
-- Name: dcim_inventoryitemtemplate_parent_id_0dac73bb; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_parent_id_0dac73bb ON __BRANCH_SCHEMA__.dcim_inventoryitemtemplate USING btree (parent_id);


--
-- Name: dcim_inventoryitemtemplate_role_id_292676e6; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_role_id_292676e6 ON __BRANCH_SCHEMA__.dcim_inventoryitemtemplate USING btree (role_id);


--
-- Name: dcim_inventoryitemtemplate_tree_id_75ebcb8e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_inventoryitemtemplate_tree_id_75ebcb8e ON __BRANCH_SCHEMA__.dcim_inventoryitemtemplate USING btree (tree_id);


--
-- Name: dcim_location_name; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_location_name ON __BRANCH_SCHEMA__.dcim_location USING btree (site_id, name) WHERE (parent_id IS NULL);


--
-- Name: dcim_location_parent_id_d77f3318; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_location_parent_id_d77f3318 ON __BRANCH_SCHEMA__.dcim_location USING btree (parent_id);


--
-- Name: dcim_location_site_id_b55e975f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_location_site_id_b55e975f ON __BRANCH_SCHEMA__.dcim_location USING btree (site_id);


--
-- Name: dcim_location_slug; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_location_slug ON __BRANCH_SCHEMA__.dcim_location USING btree (site_id, slug) WHERE (parent_id IS NULL);


--
-- Name: dcim_location_slug_352c5472; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_location_slug_352c5472 ON __BRANCH_SCHEMA__.dcim_location USING btree (slug);


--
-- Name: dcim_location_slug_352c5472_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_location_slug_352c5472_like ON __BRANCH_SCHEMA__.dcim_location USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_location_tenant_id_2c4df974; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_location_tenant_id_2c4df974 ON __BRANCH_SCHEMA__.dcim_location USING btree (tenant_id);


--
-- Name: dcim_location_tree_id_5089ef14; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_location_tree_id_5089ef14 ON __BRANCH_SCHEMA__.dcim_location USING btree (tree_id);


--
-- Name: dcim_macaddress_assigned_object_type_id_28814a20; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_macaddress_assigned_object_type_id_28814a20 ON __BRANCH_SCHEMA__.dcim_macaddress USING btree (assigned_object_type_id);


--
-- Name: dcim_manufacturer_name_841fcd92_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_manufacturer_name_841fcd92_like ON __BRANCH_SCHEMA__.dcim_manufacturer USING btree (name varchar_pattern_ops);


--
-- Name: dcim_manufacturer_slug_00430749_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_manufacturer_slug_00430749_like ON __BRANCH_SCHEMA__.dcim_manufacturer USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_module_asset_tag_2fd91eed_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_module_asset_tag_2fd91eed_like ON __BRANCH_SCHEMA__.dcim_module USING btree (asset_tag varchar_pattern_ops);


--
-- Name: dcim_module_device_id_53cfd5be; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_module_device_id_53cfd5be ON __BRANCH_SCHEMA__.dcim_module USING btree (device_id);


--
-- Name: dcim_module_module_type_id_a50b39fc; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_module_module_type_id_a50b39fc ON __BRANCH_SCHEMA__.dcim_module USING btree (module_type_id);


--
-- Name: dcim_modulebay__location_id_17290069; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebay__location_id_17290069 ON __BRANCH_SCHEMA__.dcim_modulebay USING btree (_location_id);


--
-- Name: dcim_modulebay__rack_id_673d8fb5; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebay__rack_id_673d8fb5 ON __BRANCH_SCHEMA__.dcim_modulebay USING btree (_rack_id);


--
-- Name: dcim_modulebay__site_id_cedd61bc; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebay__site_id_cedd61bc ON __BRANCH_SCHEMA__.dcim_modulebay USING btree (_site_id);


--
-- Name: dcim_modulebay_device_id_3526abc2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebay_device_id_3526abc2 ON __BRANCH_SCHEMA__.dcim_modulebay USING btree (device_id);


--
-- Name: dcim_modulebay_module_id_a21ddd9a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebay_module_id_a21ddd9a ON __BRANCH_SCHEMA__.dcim_modulebay USING btree (module_id);


--
-- Name: dcim_modulebay_parent_id_e483f9b7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebay_parent_id_e483f9b7 ON __BRANCH_SCHEMA__.dcim_modulebay USING btree (parent_id);


--
-- Name: dcim_modulebay_tree_id_223db581; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebay_tree_id_223db581 ON __BRANCH_SCHEMA__.dcim_modulebay USING btree (tree_id);


--
-- Name: dcim_modulebaytemplate_device_type_id_9eaf9bd3; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebaytemplate_device_type_id_9eaf9bd3 ON __BRANCH_SCHEMA__.dcim_modulebaytemplate USING btree (device_type_id);


--
-- Name: dcim_modulebaytemplate_module_type_id_2fdfb491; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_modulebaytemplate_module_type_id_2fdfb491 ON __BRANCH_SCHEMA__.dcim_modulebaytemplate USING btree (module_type_id);


--
-- Name: dcim_moduletype_manufacturer_id_7347392e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_moduletype_manufacturer_id_7347392e ON __BRANCH_SCHEMA__.dcim_moduletype USING btree (manufacturer_id);


--
-- Name: dcim_moduletype_profile_id_62b5d02d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_moduletype_profile_id_62b5d02d ON __BRANCH_SCHEMA__.dcim_moduletype USING btree (profile_id);


--
-- Name: dcim_moduletypeprofile_name_1709c36e_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_moduletypeprofile_name_1709c36e_like ON __BRANCH_SCHEMA__.dcim_moduletypeprofile USING btree (name varchar_pattern_ops);


--
-- Name: dcim_platform_config_template_id_013a4d3c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_platform_config_template_id_013a4d3c ON __BRANCH_SCHEMA__.dcim_platform USING btree (config_template_id);


--
-- Name: dcim_platform_manufacturer_id_83f72d3d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_platform_manufacturer_id_83f72d3d ON __BRANCH_SCHEMA__.dcim_platform USING btree (manufacturer_id);


--
-- Name: dcim_platform_name; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_platform_name ON __BRANCH_SCHEMA__.dcim_platform USING btree (name) WHERE (manufacturer_id IS NULL);


--
-- Name: dcim_platform_parent_id_795c7101; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_platform_parent_id_795c7101 ON __BRANCH_SCHEMA__.dcim_platform USING btree (parent_id);


--
-- Name: dcim_platform_slug; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_platform_slug ON __BRANCH_SCHEMA__.dcim_platform USING btree (slug) WHERE (manufacturer_id IS NULL);


--
-- Name: dcim_platform_slug_b0908ae4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_platform_slug_b0908ae4 ON __BRANCH_SCHEMA__.dcim_platform USING btree (slug);


--
-- Name: dcim_platform_slug_b0908ae4_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_platform_slug_b0908ae4_like ON __BRANCH_SCHEMA__.dcim_platform USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_platform_tree_id_ca32aeb8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_platform_tree_id_ca32aeb8 ON __BRANCH_SCHEMA__.dcim_platform USING btree (tree_id);


--
-- Name: dcim_powerfeed__path_id_a1ea1f28; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerfeed__path_id_a1ea1f28 ON __BRANCH_SCHEMA__.dcim_powerfeed USING btree (_path_id);


--
-- Name: dcim_powerfeed_cable_id_ec44c4f8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerfeed_cable_id_ec44c4f8 ON __BRANCH_SCHEMA__.dcim_powerfeed USING btree (cable_id);


--
-- Name: dcim_powerfeed_power_panel_id_32bde3be; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerfeed_power_panel_id_32bde3be ON __BRANCH_SCHEMA__.dcim_powerfeed USING btree (power_panel_id);


--
-- Name: dcim_powerfeed_rack_id_7abba090; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerfeed_rack_id_7abba090 ON __BRANCH_SCHEMA__.dcim_powerfeed USING btree (rack_id);


--
-- Name: dcim_powerfeed_tenant_id_947bee85; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerfeed_tenant_id_947bee85 ON __BRANCH_SCHEMA__.dcim_powerfeed USING btree (tenant_id);


--
-- Name: dcim_poweroutlet__location_id_49563316; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlet__location_id_49563316 ON __BRANCH_SCHEMA__.dcim_poweroutlet USING btree (_location_id);


--
-- Name: dcim_poweroutlet__path_id_cbb47bb9; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlet__path_id_cbb47bb9 ON __BRANCH_SCHEMA__.dcim_poweroutlet USING btree (_path_id);


--
-- Name: dcim_poweroutlet__rack_id_aca89672; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlet__rack_id_aca89672 ON __BRANCH_SCHEMA__.dcim_poweroutlet USING btree (_rack_id);


--
-- Name: dcim_poweroutlet__site_id_a956755e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlet__site_id_a956755e ON __BRANCH_SCHEMA__.dcim_poweroutlet USING btree (_site_id);


--
-- Name: dcim_poweroutlet_cable_id_8dbea1ec; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlet_cable_id_8dbea1ec ON __BRANCH_SCHEMA__.dcim_poweroutlet USING btree (cable_id);


--
-- Name: dcim_poweroutlet_device_id_286351d7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlet_device_id_286351d7 ON __BRANCH_SCHEMA__.dcim_poweroutlet USING btree (device_id);


--
-- Name: dcim_poweroutlet_module_id_032f5af2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlet_module_id_032f5af2 ON __BRANCH_SCHEMA__.dcim_poweroutlet USING btree (module_id);


--
-- Name: dcim_poweroutlet_power_port_id_9bdf4163; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlet_power_port_id_9bdf4163 ON __BRANCH_SCHEMA__.dcim_poweroutlet USING btree (power_port_id);


--
-- Name: dcim_poweroutlettemplate_device_type_id_26b2316c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlettemplate_device_type_id_26b2316c ON __BRANCH_SCHEMA__.dcim_poweroutlettemplate USING btree (device_type_id);


--
-- Name: dcim_poweroutlettemplate_module_type_id_6142b416; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlettemplate_module_type_id_6142b416 ON __BRANCH_SCHEMA__.dcim_poweroutlettemplate USING btree (module_type_id);


--
-- Name: dcim_poweroutlettemplate_power_port_id_c0fb0c42; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_poweroutlettemplate_power_port_id_c0fb0c42 ON __BRANCH_SCHEMA__.dcim_poweroutlettemplate USING btree (power_port_id);


--
-- Name: dcim_powerpanel_location_id_474b60f8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerpanel_location_id_474b60f8 ON __BRANCH_SCHEMA__.dcim_powerpanel USING btree (location_id);


--
-- Name: dcim_powerpanel_site_id_c430bc89; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerpanel_site_id_c430bc89 ON __BRANCH_SCHEMA__.dcim_powerpanel USING btree (site_id);


--
-- Name: dcim_powerport__location_id_ccf995e7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerport__location_id_ccf995e7 ON __BRANCH_SCHEMA__.dcim_powerport USING btree (_location_id);


--
-- Name: dcim_powerport__path_id_9fe4af8f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerport__path_id_9fe4af8f ON __BRANCH_SCHEMA__.dcim_powerport USING btree (_path_id);


--
-- Name: dcim_powerport__rack_id_4c1c316d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerport__rack_id_4c1c316d ON __BRANCH_SCHEMA__.dcim_powerport USING btree (_rack_id);


--
-- Name: dcim_powerport__site_id_87bfa142; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerport__site_id_87bfa142 ON __BRANCH_SCHEMA__.dcim_powerport USING btree (_site_id);


--
-- Name: dcim_powerport_cable_id_c9682ba2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerport_cable_id_c9682ba2 ON __BRANCH_SCHEMA__.dcim_powerport USING btree (cable_id);


--
-- Name: dcim_powerport_device_id_ef7185ae; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerport_device_id_ef7185ae ON __BRANCH_SCHEMA__.dcim_powerport USING btree (device_id);


--
-- Name: dcim_powerport_module_id_d0c27534; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerport_module_id_d0c27534 ON __BRANCH_SCHEMA__.dcim_powerport USING btree (module_id);


--
-- Name: dcim_powerporttemplate_device_type_id_1ddfbfcc; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerporttemplate_device_type_id_1ddfbfcc ON __BRANCH_SCHEMA__.dcim_powerporttemplate USING btree (device_type_id);


--
-- Name: dcim_powerporttemplate_module_type_id_93e26849; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_powerporttemplate_module_type_id_93e26849 ON __BRANCH_SCHEMA__.dcim_powerporttemplate USING btree (module_type_id);


--
-- Name: dcim_rack_asset_tag_f88408e5_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rack_asset_tag_f88408e5_like ON __BRANCH_SCHEMA__.dcim_rack USING btree (asset_tag varchar_pattern_ops);


--
-- Name: dcim_rack_location_id_5f63ec31; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rack_location_id_5f63ec31 ON __BRANCH_SCHEMA__.dcim_rack USING btree (location_id);


--
-- Name: dcim_rack_rack_type_id_39433a22; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rack_rack_type_id_39433a22 ON __BRANCH_SCHEMA__.dcim_rack USING btree (rack_type_id);


--
-- Name: dcim_rack_role_id_62d6919e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rack_role_id_62d6919e ON __BRANCH_SCHEMA__.dcim_rack USING btree (role_id);


--
-- Name: dcim_rack_site_id_403c7b3a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rack_site_id_403c7b3a ON __BRANCH_SCHEMA__.dcim_rack USING btree (site_id);


--
-- Name: dcim_rack_tenant_id_7cdf3725; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rack_tenant_id_7cdf3725 ON __BRANCH_SCHEMA__.dcim_rack USING btree (tenant_id);


--
-- Name: dcim_rackreservation_rack_id_1ebbaa9b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rackreservation_rack_id_1ebbaa9b ON __BRANCH_SCHEMA__.dcim_rackreservation USING btree (rack_id);


--
-- Name: dcim_rackreservation_tenant_id_eb5e045f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rackreservation_tenant_id_eb5e045f ON __BRANCH_SCHEMA__.dcim_rackreservation USING btree (tenant_id);


--
-- Name: dcim_rackreservation_user_id_0785a527; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rackreservation_user_id_0785a527 ON __BRANCH_SCHEMA__.dcim_rackreservation USING btree (user_id);


--
-- Name: dcim_rackrole_name_9077cfcc_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rackrole_name_9077cfcc_like ON __BRANCH_SCHEMA__.dcim_rackrole USING btree (name varchar_pattern_ops);


--
-- Name: dcim_rackrole_slug_40bbcd3a_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rackrole_slug_40bbcd3a_like ON __BRANCH_SCHEMA__.dcim_rackrole USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_racktype_manufacturer_id_d46a05c6; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_racktype_manufacturer_id_d46a05c6 ON __BRANCH_SCHEMA__.dcim_racktype USING btree (manufacturer_id);


--
-- Name: dcim_racktype_slug_6bbb384a_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_racktype_slug_6bbb384a_like ON __BRANCH_SCHEMA__.dcim_racktype USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_rearport__location_id_72554006; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rearport__location_id_72554006 ON __BRANCH_SCHEMA__.dcim_rearport USING btree (_location_id);


--
-- Name: dcim_rearport__rack_id_9af9a402; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rearport__rack_id_9af9a402 ON __BRANCH_SCHEMA__.dcim_rearport USING btree (_rack_id);


--
-- Name: dcim_rearport__site_id_35e05ccf; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rearport__site_id_35e05ccf ON __BRANCH_SCHEMA__.dcim_rearport USING btree (_site_id);


--
-- Name: dcim_rearport_cable_id_42c0e4e7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rearport_cable_id_42c0e4e7 ON __BRANCH_SCHEMA__.dcim_rearport USING btree (cable_id);


--
-- Name: dcim_rearport_device_id_0bdfe9c0; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rearport_device_id_0bdfe9c0 ON __BRANCH_SCHEMA__.dcim_rearport USING btree (device_id);


--
-- Name: dcim_rearport_module_id_9a7b7e91; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rearport_module_id_9a7b7e91 ON __BRANCH_SCHEMA__.dcim_rearport USING btree (module_id);


--
-- Name: dcim_rearporttemplate_device_type_id_6a02fd01; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rearporttemplate_device_type_id_6a02fd01 ON __BRANCH_SCHEMA__.dcim_rearporttemplate USING btree (device_type_id);


--
-- Name: dcim_rearporttemplate_module_type_id_4d970e5b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_rearporttemplate_module_type_id_4d970e5b ON __BRANCH_SCHEMA__.dcim_rearporttemplate USING btree (module_type_id);


--
-- Name: dcim_region_name; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_region_name ON __BRANCH_SCHEMA__.dcim_region USING btree (name) WHERE (parent_id IS NULL);


--
-- Name: dcim_region_parent_id_2486f5d4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_region_parent_id_2486f5d4 ON __BRANCH_SCHEMA__.dcim_region USING btree (parent_id);


--
-- Name: dcim_region_slug; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_region_slug ON __BRANCH_SCHEMA__.dcim_region USING btree (slug) WHERE (parent_id IS NULL);


--
-- Name: dcim_region_slug_ff078a66; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_region_slug_ff078a66 ON __BRANCH_SCHEMA__.dcim_region USING btree (slug);


--
-- Name: dcim_region_slug_ff078a66_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_region_slug_ff078a66_like ON __BRANCH_SCHEMA__.dcim_region USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_region_tree_id_a09ea9a7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_region_tree_id_a09ea9a7 ON __BRANCH_SCHEMA__.dcim_region USING btree (tree_id);


--
-- Name: dcim_site_asns_asn_id_3cfd0f00; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_site_asns_asn_id_3cfd0f00 ON __BRANCH_SCHEMA__.dcim_site_asns USING btree (asn_id);


--
-- Name: dcim_site_asns_site_id_112ccacf; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_site_asns_site_id_112ccacf ON __BRANCH_SCHEMA__.dcim_site_asns USING btree (site_id);


--
-- Name: dcim_site_group_id_3910c975; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_site_group_id_3910c975 ON __BRANCH_SCHEMA__.dcim_site USING btree (group_id);


--
-- Name: dcim_site_name_8fe66c76_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_site_name_8fe66c76_like ON __BRANCH_SCHEMA__.dcim_site USING btree (name varchar_pattern_ops);


--
-- Name: dcim_site_region_id_45210932; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_site_region_id_45210932 ON __BRANCH_SCHEMA__.dcim_site USING btree (region_id);


--
-- Name: dcim_site_slug_4412c762_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_site_slug_4412c762_like ON __BRANCH_SCHEMA__.dcim_site USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_site_tenant_id_15e7df63; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_site_tenant_id_15e7df63 ON __BRANCH_SCHEMA__.dcim_site USING btree (tenant_id);


--
-- Name: dcim_sitegroup_name; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_sitegroup_name ON __BRANCH_SCHEMA__.dcim_sitegroup USING btree (name) WHERE (parent_id IS NULL);


--
-- Name: dcim_sitegroup_parent_id_533a5e44; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_sitegroup_parent_id_533a5e44 ON __BRANCH_SCHEMA__.dcim_sitegroup USING btree (parent_id);


--
-- Name: dcim_sitegroup_slug; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX dcim_sitegroup_slug ON __BRANCH_SCHEMA__.dcim_sitegroup USING btree (slug) WHERE (parent_id IS NULL);


--
-- Name: dcim_sitegroup_slug_a11d2b04; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_sitegroup_slug_a11d2b04 ON __BRANCH_SCHEMA__.dcim_sitegroup USING btree (slug);


--
-- Name: dcim_sitegroup_slug_a11d2b04_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_sitegroup_slug_a11d2b04_like ON __BRANCH_SCHEMA__.dcim_sitegroup USING btree (slug varchar_pattern_ops);


--
-- Name: dcim_sitegroup_tree_id_e76dc999; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_sitegroup_tree_id_e76dc999 ON __BRANCH_SCHEMA__.dcim_sitegroup USING btree (tree_id);


--
-- Name: dcim_virtualdevicecontext_device_id_4f39274b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_virtualdevicecontext_device_id_4f39274b ON __BRANCH_SCHEMA__.dcim_virtualdevicecontext USING btree (device_id);


--
-- Name: dcim_virtualdevicecontext_tenant_id_b6a21753; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX dcim_virtualdevicecontext_tenant_id_b6a21753 ON __BRANCH_SCHEMA__.dcim_virtualdevicecontext USING btree (tenant_id);


--
-- Name: extras_cachedvalue_object; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_cachedvalue_object ON __BRANCH_SCHEMA__.extras_cachedvalue USING btree (object_type_id, object_id);


--
-- Name: extras_cachedvalue_object_type_id_6f47d444; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_cachedvalue_object_type_id_6f47d444 ON __BRANCH_SCHEMA__.extras_cachedvalue USING btree (object_type_id);


--
-- Name: extras_configcontext_cluster_groups_clustergroup_id_f4322ce8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_cluster_groups_clustergroup_id_f4322ce8 ON __BRANCH_SCHEMA__.extras_configcontext_cluster_groups USING btree (clustergroup_id);


--
-- Name: extras_configcontext_cluster_groups_configcontext_id_8f50b794; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_cluster_groups_configcontext_id_8f50b794 ON __BRANCH_SCHEMA__.extras_configcontext_cluster_groups USING btree (configcontext_id);


--
-- Name: extras_configcontext_cluster_types_clustertype_id_fa493b64; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_cluster_types_clustertype_id_fa493b64 ON __BRANCH_SCHEMA__.extras_configcontext_cluster_types USING btree (clustertype_id);


--
-- Name: extras_configcontext_cluster_types_configcontext_id_d549b6f2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_cluster_types_configcontext_id_d549b6f2 ON __BRANCH_SCHEMA__.extras_configcontext_cluster_types USING btree (configcontext_id);


--
-- Name: extras_configcontext_clusters_cluster_id_6abd47a1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_clusters_cluster_id_6abd47a1 ON __BRANCH_SCHEMA__.extras_configcontext_clusters USING btree (cluster_id);


--
-- Name: extras_configcontext_clusters_configcontext_id_ed579a40; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_clusters_configcontext_id_ed579a40 ON __BRANCH_SCHEMA__.extras_configcontext_clusters USING btree (configcontext_id);


--
-- Name: extras_configcontext_data_file_id_8fdd620b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_data_file_id_8fdd620b ON __BRANCH_SCHEMA__.extras_configcontext USING btree (data_file_id);


--
-- Name: extras_configcontext_data_source_id_1b2eb8af; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_data_source_id_1b2eb8af ON __BRANCH_SCHEMA__.extras_configcontext USING btree (data_source_id);


--
-- Name: extras_configcontext_device_types_configcontext_id_55632923; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_device_types_configcontext_id_55632923 ON __BRANCH_SCHEMA__.extras_configcontext_device_types USING btree (configcontext_id);


--
-- Name: extras_configcontext_device_types_devicetype_id_b8788c2d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_device_types_devicetype_id_b8788c2d ON __BRANCH_SCHEMA__.extras_configcontext_device_types USING btree (devicetype_id);


--
-- Name: extras_configcontext_locations_configcontext_id_cc629ec1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_locations_configcontext_id_cc629ec1 ON __BRANCH_SCHEMA__.extras_configcontext_locations USING btree (configcontext_id);


--
-- Name: extras_configcontext_locations_location_id_9e19eac9; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_locations_location_id_9e19eac9 ON __BRANCH_SCHEMA__.extras_configcontext_locations USING btree (location_id);


--
-- Name: extras_configcontext_name_4bbfe25d_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_name_4bbfe25d_like ON __BRANCH_SCHEMA__.extras_configcontext USING btree (name varchar_pattern_ops);


--
-- Name: extras_configcontext_platforms_configcontext_id_2a516699; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_platforms_configcontext_id_2a516699 ON __BRANCH_SCHEMA__.extras_configcontext_platforms USING btree (configcontext_id);


--
-- Name: extras_configcontext_platforms_platform_id_3fdfedc0; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_platforms_platform_id_3fdfedc0 ON __BRANCH_SCHEMA__.extras_configcontext_platforms USING btree (platform_id);


--
-- Name: extras_configcontext_profile_id_48c7bc6a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_profile_id_48c7bc6a ON __BRANCH_SCHEMA__.extras_configcontext USING btree (profile_id);


--
-- Name: extras_configcontext_regions_configcontext_id_73003dbc; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_regions_configcontext_id_73003dbc ON __BRANCH_SCHEMA__.extras_configcontext_regions USING btree (configcontext_id);


--
-- Name: extras_configcontext_regions_region_id_35c6ba9d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_regions_region_id_35c6ba9d ON __BRANCH_SCHEMA__.extras_configcontext_regions USING btree (region_id);


--
-- Name: extras_configcontext_roles_configcontext_id_59b67386; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_roles_configcontext_id_59b67386 ON __BRANCH_SCHEMA__.extras_configcontext_roles USING btree (configcontext_id);


--
-- Name: extras_configcontext_roles_devicerole_id_d3a84813; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_roles_devicerole_id_d3a84813 ON __BRANCH_SCHEMA__.extras_configcontext_roles USING btree (devicerole_id);


--
-- Name: extras_configcontext_site_groups_configcontext_id_2e0f43cb; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_site_groups_configcontext_id_2e0f43cb ON __BRANCH_SCHEMA__.extras_configcontext_site_groups USING btree (configcontext_id);


--
-- Name: extras_configcontext_site_groups_sitegroup_id_3287c9e7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_site_groups_sitegroup_id_3287c9e7 ON __BRANCH_SCHEMA__.extras_configcontext_site_groups USING btree (sitegroup_id);


--
-- Name: extras_configcontext_sites_configcontext_id_8c54feb9; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_sites_configcontext_id_8c54feb9 ON __BRANCH_SCHEMA__.extras_configcontext_sites USING btree (configcontext_id);


--
-- Name: extras_configcontext_sites_site_id_cbb76c96; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_sites_site_id_cbb76c96 ON __BRANCH_SCHEMA__.extras_configcontext_sites USING btree (site_id);


--
-- Name: extras_configcontext_tags_configcontext_id_64a392b1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_tags_configcontext_id_64a392b1 ON __BRANCH_SCHEMA__.extras_configcontext_tags USING btree (configcontext_id);


--
-- Name: extras_configcontext_tags_tag_id_129a5d87; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_tags_tag_id_129a5d87 ON __BRANCH_SCHEMA__.extras_configcontext_tags USING btree (tag_id);


--
-- Name: extras_configcontext_tenant_groups_configcontext_id_92f68345; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_tenant_groups_configcontext_id_92f68345 ON __BRANCH_SCHEMA__.extras_configcontext_tenant_groups USING btree (configcontext_id);


--
-- Name: extras_configcontext_tenant_groups_tenantgroup_id_0909688d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_tenant_groups_tenantgroup_id_0909688d ON __BRANCH_SCHEMA__.extras_configcontext_tenant_groups USING btree (tenantgroup_id);


--
-- Name: extras_configcontext_tenants_configcontext_id_b53552a6; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_tenants_configcontext_id_b53552a6 ON __BRANCH_SCHEMA__.extras_configcontext_tenants USING btree (configcontext_id);


--
-- Name: extras_configcontext_tenants_tenant_id_8d0aa28e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontext_tenants_tenant_id_8d0aa28e ON __BRANCH_SCHEMA__.extras_configcontext_tenants USING btree (tenant_id);


--
-- Name: extras_configcontextprofile_data_file_id_e0caf376; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontextprofile_data_file_id_e0caf376 ON __BRANCH_SCHEMA__.extras_configcontextprofile USING btree (data_file_id);


--
-- Name: extras_configcontextprofile_data_source_id_b88dd849; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontextprofile_data_source_id_b88dd849 ON __BRANCH_SCHEMA__.extras_configcontextprofile USING btree (data_source_id);


--
-- Name: extras_configcontextprofile_name_070de83b_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configcontextprofile_name_070de83b_like ON __BRANCH_SCHEMA__.extras_configcontextprofile USING btree (name varchar_pattern_ops);


--
-- Name: extras_configtemplate_data_file_id_20c7cff4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configtemplate_data_file_id_20c7cff4 ON __BRANCH_SCHEMA__.extras_configtemplate USING btree (data_file_id);


--
-- Name: extras_configtemplate_data_source_id_f9d26d5d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_configtemplate_data_source_id_f9d26d5d ON __BRANCH_SCHEMA__.extras_configtemplate USING btree (data_source_id);


--
-- Name: extras_imag_object__96bebc_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_imag_object__96bebc_idx ON __BRANCH_SCHEMA__.extras_imageattachment USING btree (object_type_id, object_id);


--
-- Name: extras_imageattachment_content_type_id_90e0643d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_imageattachment_content_type_id_90e0643d ON __BRANCH_SCHEMA__.extras_imageattachment USING btree (object_type_id);


--
-- Name: extras_jour_assigne_76510f_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_jour_assigne_76510f_idx ON __BRANCH_SCHEMA__.extras_journalentry USING btree (assigned_object_type_id, assigned_object_id);


--
-- Name: extras_journalentry_assigned_object_type_id_1bba9f68; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_journalentry_assigned_object_type_id_1bba9f68 ON __BRANCH_SCHEMA__.extras_journalentry USING btree (assigned_object_type_id);


--
-- Name: extras_journalentry_created_by_id_8d4e4329; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_journalentry_created_by_id_8d4e4329 ON __BRANCH_SCHEMA__.extras_journalentry USING btree (created_by_id);


--
-- Name: extras_tableconfig_object_type_id_e43ad6ad; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_tableconfig_object_type_id_e43ad6ad ON __BRANCH_SCHEMA__.extras_tableconfig USING btree (object_type_id);


--
-- Name: extras_tableconfig_user_id_0b525dff; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_tableconfig_user_id_0b525dff ON __BRANCH_SCHEMA__.extras_tableconfig USING btree (user_id);


--
-- Name: extras_tag_name_9550b3d9_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_tag_name_9550b3d9_like ON __BRANCH_SCHEMA__.extras_tag USING btree (name varchar_pattern_ops);


--
-- Name: extras_tag_object_types_contenttype_id_c1b220c3; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_tag_object_types_contenttype_id_c1b220c3 ON __BRANCH_SCHEMA__.extras_tag_object_types USING btree (contenttype_id);


--
-- Name: extras_tag_object_types_tag_id_2e1aab29; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_tag_object_types_tag_id_2e1aab29 ON __BRANCH_SCHEMA__.extras_tag_object_types USING btree (tag_id);


--
-- Name: extras_tag_slug_aaa5b7e9_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_tag_slug_aaa5b7e9_like ON __BRANCH_SCHEMA__.extras_tag USING btree (slug varchar_pattern_ops);


--
-- Name: extras_tagg_content_717743_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_tagg_content_717743_idx ON __BRANCH_SCHEMA__.extras_taggeditem USING btree (content_type_id, object_id);


--
-- Name: extras_taggeditem_content_type_id_ba5562ed; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_taggeditem_content_type_id_ba5562ed ON __BRANCH_SCHEMA__.extras_taggeditem USING btree (content_type_id);


--
-- Name: extras_taggeditem_object_id_31b2aa77; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_taggeditem_object_id_31b2aa77 ON __BRANCH_SCHEMA__.extras_taggeditem USING btree (object_id);


--
-- Name: extras_taggeditem_tag_id_d48af7c7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX extras_taggeditem_tag_id_d48af7c7 ON __BRANCH_SCHEMA__.extras_taggeditem USING btree (tag_id);


--
-- Name: ipam_aggregate_rir_id_ef7a27bd; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_aggregate_rir_id_ef7a27bd ON __BRANCH_SCHEMA__.ipam_aggregate USING btree (rir_id);


--
-- Name: ipam_aggregate_tenant_id_637dd1a1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_aggregate_tenant_id_637dd1a1 ON __BRANCH_SCHEMA__.ipam_aggregate USING btree (tenant_id);


--
-- Name: ipam_asn_rir_id_f5ad3cff; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_asn_rir_id_f5ad3cff ON __BRANCH_SCHEMA__.ipam_asn USING btree (rir_id);


--
-- Name: ipam_asn_tenant_id_07e8188e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_asn_tenant_id_07e8188e ON __BRANCH_SCHEMA__.ipam_asn USING btree (tenant_id);


--
-- Name: ipam_asnrange_name_c7585e73_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_asnrange_name_c7585e73_like ON __BRANCH_SCHEMA__.ipam_asnrange USING btree (name varchar_pattern_ops);


--
-- Name: ipam_asnrange_rir_id_c9c31183; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_asnrange_rir_id_c9c31183 ON __BRANCH_SCHEMA__.ipam_asnrange USING btree (rir_id);


--
-- Name: ipam_asnrange_slug_c8a7d8a1_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_asnrange_slug_c8a7d8a1_like ON __BRANCH_SCHEMA__.ipam_asnrange USING btree (slug varchar_pattern_ops);


--
-- Name: ipam_asnrange_tenant_id_ed8f80b7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_asnrange_tenant_id_ed8f80b7 ON __BRANCH_SCHEMA__.ipam_asnrange USING btree (tenant_id);


--
-- Name: ipam_fhrpgr_interfa_2acc3f_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_fhrpgr_interfa_2acc3f_idx ON __BRANCH_SCHEMA__.ipam_fhrpgroupassignment USING btree (interface_type_id, interface_id);


--
-- Name: ipam_fhrpgroupassignment_group_id_19f15ca4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_fhrpgroupassignment_group_id_19f15ca4 ON __BRANCH_SCHEMA__.ipam_fhrpgroupassignment USING btree (group_id);


--
-- Name: ipam_fhrpgroupassignment_interface_type_id_f3bcb487; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_fhrpgroupassignment_interface_type_id_f3bcb487 ON __BRANCH_SCHEMA__.ipam_fhrpgroupassignment USING btree (interface_type_id);


--
-- Name: ipam_ipaddr_assigne_890ab8_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_ipaddr_assigne_890ab8_idx ON __BRANCH_SCHEMA__.ipam_ipaddress USING btree (assigned_object_type_id, assigned_object_id);


--
-- Name: ipam_ipaddress_assigned_object_type_id_02354370; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_ipaddress_assigned_object_type_id_02354370 ON __BRANCH_SCHEMA__.ipam_ipaddress USING btree (assigned_object_type_id);


--
-- Name: ipam_ipaddress_host; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_ipaddress_host ON __BRANCH_SCHEMA__.ipam_ipaddress USING btree (((host(address))::inet));


--
-- Name: ipam_ipaddress_nat_inside_id_a45fb7c5; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_ipaddress_nat_inside_id_a45fb7c5 ON __BRANCH_SCHEMA__.ipam_ipaddress USING btree (nat_inside_id);


--
-- Name: ipam_ipaddress_tenant_id_ac55acfd; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_ipaddress_tenant_id_ac55acfd ON __BRANCH_SCHEMA__.ipam_ipaddress USING btree (tenant_id);


--
-- Name: ipam_ipaddress_vrf_id_51fcc59b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_ipaddress_vrf_id_51fcc59b ON __BRANCH_SCHEMA__.ipam_ipaddress USING btree (vrf_id);


--
-- Name: ipam_iprange_role_id_2782e864; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_iprange_role_id_2782e864 ON __BRANCH_SCHEMA__.ipam_iprange USING btree (role_id);


--
-- Name: ipam_iprange_tenant_id_856027ea; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_iprange_tenant_id_856027ea ON __BRANCH_SCHEMA__.ipam_iprange USING btree (tenant_id);


--
-- Name: ipam_iprange_vrf_id_613e9dd2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_iprange_vrf_id_613e9dd2 ON __BRANCH_SCHEMA__.ipam_iprange USING btree (vrf_id);


--
-- Name: ipam_l2vpn_export_targets_l2vpn_id_8749bbe8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_l2vpn_export_targets_l2vpn_id_8749bbe8 ON __BRANCH_SCHEMA__.vpn_l2vpn_export_targets USING btree (l2vpn_id);


--
-- Name: ipam_l2vpn_export_targets_routetarget_id_5ccb758b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_l2vpn_export_targets_routetarget_id_5ccb758b ON __BRANCH_SCHEMA__.vpn_l2vpn_export_targets USING btree (routetarget_id);


--
-- Name: ipam_l2vpn_import_targets_l2vpn_id_731f5bb4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_l2vpn_import_targets_l2vpn_id_731f5bb4 ON __BRANCH_SCHEMA__.vpn_l2vpn_import_targets USING btree (l2vpn_id);


--
-- Name: ipam_l2vpn_import_targets_routetarget_id_58a188b2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_l2vpn_import_targets_routetarget_id_58a188b2 ON __BRANCH_SCHEMA__.vpn_l2vpn_import_targets USING btree (routetarget_id);


--
-- Name: ipam_prefix__location_id_f5925c42; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix__location_id_f5925c42 ON __BRANCH_SCHEMA__.ipam_prefix USING btree (_location_id);


--
-- Name: ipam_prefix__region_id_54aedc72; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix__region_id_54aedc72 ON __BRANCH_SCHEMA__.ipam_prefix USING btree (_region_id);


--
-- Name: ipam_prefix__site_group_id_8277120b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix__site_group_id_8277120b ON __BRANCH_SCHEMA__.ipam_prefix USING btree (_site_group_id);


--
-- Name: ipam_prefix__site_id_b479fb05; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix__site_id_b479fb05 ON __BRANCH_SCHEMA__.ipam_prefix USING btree (_site_id);


--
-- Name: ipam_prefix_gist_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix_gist_idx ON __BRANCH_SCHEMA__.ipam_prefix USING gist (prefix inet_ops);


--
-- Name: ipam_prefix_role_id_0a98d415; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix_role_id_0a98d415 ON __BRANCH_SCHEMA__.ipam_prefix USING btree (role_id);


--
-- Name: ipam_prefix_scope_type_id_413319e2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix_scope_type_id_413319e2 ON __BRANCH_SCHEMA__.ipam_prefix USING btree (scope_type_id);


--
-- Name: ipam_prefix_tenant_id_7ba1fcc4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix_tenant_id_7ba1fcc4 ON __BRANCH_SCHEMA__.ipam_prefix USING btree (tenant_id);


--
-- Name: ipam_prefix_vlan_id_1db91bff; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix_vlan_id_1db91bff ON __BRANCH_SCHEMA__.ipam_prefix USING btree (vlan_id);


--
-- Name: ipam_prefix_vrf_id_34f78ed0; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_prefix_vrf_id_34f78ed0 ON __BRANCH_SCHEMA__.ipam_prefix USING btree (vrf_id);


--
-- Name: ipam_rir_name_64a71982_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_rir_name_64a71982_like ON __BRANCH_SCHEMA__.ipam_rir USING btree (name varchar_pattern_ops);


--
-- Name: ipam_rir_slug_ff1a369a_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_rir_slug_ff1a369a_like ON __BRANCH_SCHEMA__.ipam_rir USING btree (slug varchar_pattern_ops);


--
-- Name: ipam_role_name_13784849_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_role_name_13784849_like ON __BRANCH_SCHEMA__.ipam_role USING btree (name varchar_pattern_ops);


--
-- Name: ipam_role_slug_309ca14c_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_role_slug_309ca14c_like ON __BRANCH_SCHEMA__.ipam_role USING btree (slug varchar_pattern_ops);


--
-- Name: ipam_routetarget_name_212be79f_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_routetarget_name_212be79f_like ON __BRANCH_SCHEMA__.ipam_routetarget USING btree (name varchar_pattern_ops);


--
-- Name: ipam_routetarget_tenant_id_5a0b35e8; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_routetarget_tenant_id_5a0b35e8 ON __BRANCH_SCHEMA__.ipam_routetarget USING btree (tenant_id);


--
-- Name: ipam_servic_parent__563d2b_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_servic_parent__563d2b_idx ON __BRANCH_SCHEMA__.ipam_service USING btree (parent_object_type_id, parent_object_id);


--
-- Name: ipam_service_ipaddresses_ipaddress_id_b4138c6d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_service_ipaddresses_ipaddress_id_b4138c6d ON __BRANCH_SCHEMA__.ipam_service_ipaddresses USING btree (ipaddress_id);


--
-- Name: ipam_service_ipaddresses_service_id_ae26b9ab; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_service_ipaddresses_service_id_ae26b9ab ON __BRANCH_SCHEMA__.ipam_service_ipaddresses USING btree (service_id);


--
-- Name: ipam_service_parent_object_type_id_8e76bfb3; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_service_parent_object_type_id_8e76bfb3 ON __BRANCH_SCHEMA__.ipam_service USING btree (parent_object_type_id);


--
-- Name: ipam_servicetemplate_name_1a2f3410_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_servicetemplate_name_1a2f3410_like ON __BRANCH_SCHEMA__.ipam_servicetemplate USING btree (name varchar_pattern_ops);


--
-- Name: ipam_vlan_group_id_88cbfa62; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlan_group_id_88cbfa62 ON __BRANCH_SCHEMA__.ipam_vlan USING btree (group_id);


--
-- Name: ipam_vlan_qinq_svlan_id_acbd7a5d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlan_qinq_svlan_id_acbd7a5d ON __BRANCH_SCHEMA__.ipam_vlan USING btree (qinq_svlan_id);


--
-- Name: ipam_vlan_role_id_f5015962; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlan_role_id_f5015962 ON __BRANCH_SCHEMA__.ipam_vlan USING btree (role_id);


--
-- Name: ipam_vlan_site_id_a59334e3; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlan_site_id_a59334e3 ON __BRANCH_SCHEMA__.ipam_vlan USING btree (site_id);


--
-- Name: ipam_vlan_tenant_id_71a8290d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlan_tenant_id_71a8290d ON __BRANCH_SCHEMA__.ipam_vlan USING btree (tenant_id);


--
-- Name: ipam_vlangr_scope_t_9da557_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlangr_scope_t_9da557_idx ON __BRANCH_SCHEMA__.ipam_vlangroup USING btree (scope_type_id, scope_id);


--
-- Name: ipam_vlangroup_scope_type_id_6606a755; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlangroup_scope_type_id_6606a755 ON __BRANCH_SCHEMA__.ipam_vlangroup USING btree (scope_type_id);


--
-- Name: ipam_vlangroup_slug_40abcf6b; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlangroup_slug_40abcf6b ON __BRANCH_SCHEMA__.ipam_vlangroup USING btree (slug);


--
-- Name: ipam_vlangroup_slug_40abcf6b_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlangroup_slug_40abcf6b_like ON __BRANCH_SCHEMA__.ipam_vlangroup USING btree (slug varchar_pattern_ops);


--
-- Name: ipam_vlangroup_tenant_id_29197fca; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlangroup_tenant_id_29197fca ON __BRANCH_SCHEMA__.ipam_vlangroup USING btree (tenant_id);


--
-- Name: ipam_vlantranslationpolicy_name_17e0a007_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlantranslationpolicy_name_17e0a007_like ON __BRANCH_SCHEMA__.ipam_vlantranslationpolicy USING btree (name varchar_pattern_ops);


--
-- Name: ipam_vlantranslationrule_policy_id_09157735; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vlantranslationrule_policy_id_09157735 ON __BRANCH_SCHEMA__.ipam_vlantranslationrule USING btree (policy_id);


--
-- Name: ipam_vrf_export_targets_routetarget_id_8d9319f7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vrf_export_targets_routetarget_id_8d9319f7 ON __BRANCH_SCHEMA__.ipam_vrf_export_targets USING btree (routetarget_id);


--
-- Name: ipam_vrf_export_targets_vrf_id_6f4875c4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vrf_export_targets_vrf_id_6f4875c4 ON __BRANCH_SCHEMA__.ipam_vrf_export_targets USING btree (vrf_id);


--
-- Name: ipam_vrf_import_targets_routetarget_id_0e05b144; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vrf_import_targets_routetarget_id_0e05b144 ON __BRANCH_SCHEMA__.ipam_vrf_import_targets USING btree (routetarget_id);


--
-- Name: ipam_vrf_import_targets_vrf_id_ed491b19; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vrf_import_targets_vrf_id_ed491b19 ON __BRANCH_SCHEMA__.ipam_vrf_import_targets USING btree (vrf_id);


--
-- Name: ipam_vrf_rd_0ac1bde1_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vrf_rd_0ac1bde1_like ON __BRANCH_SCHEMA__.ipam_vrf USING btree (rd varchar_pattern_ops);


--
-- Name: ipam_vrf_tenant_id_498b0051; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX ipam_vrf_tenant_id_498b0051 ON __BRANCH_SCHEMA__.ipam_vrf USING btree (tenant_id);


--
-- Name: tenancy_con_object__6f20f7_idx; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_con_object__6f20f7_idx ON __BRANCH_SCHEMA__.tenancy_contactassignment USING btree (object_type_id, object_id);


--
-- Name: tenancy_contact_groups_contact_id_84c9d84f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contact_groups_contact_id_84c9d84f ON __BRANCH_SCHEMA__.tenancy_contact_groups USING btree (contact_id);


--
-- Name: tenancy_contact_groups_contactgroup_id_5c8d6c5a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contact_groups_contactgroup_id_5c8d6c5a ON __BRANCH_SCHEMA__.tenancy_contact_groups USING btree (contactgroup_id);


--
-- Name: tenancy_contactassignment_contact_id_5302baf0; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactassignment_contact_id_5302baf0 ON __BRANCH_SCHEMA__.tenancy_contactassignment USING btree (contact_id);


--
-- Name: tenancy_contactassignment_content_type_id_0c3f0c67; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactassignment_content_type_id_0c3f0c67 ON __BRANCH_SCHEMA__.tenancy_contactassignment USING btree (object_type_id);


--
-- Name: tenancy_contactassignment_role_id_fc08bfb5; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactassignment_role_id_fc08bfb5 ON __BRANCH_SCHEMA__.tenancy_contactassignment USING btree (role_id);


--
-- Name: tenancy_contactgroup_parent_id_c087d69f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactgroup_parent_id_c087d69f ON __BRANCH_SCHEMA__.tenancy_contactgroup USING btree (parent_id);


--
-- Name: tenancy_contactgroup_slug_5b0f3e75; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactgroup_slug_5b0f3e75 ON __BRANCH_SCHEMA__.tenancy_contactgroup USING btree (slug);


--
-- Name: tenancy_contactgroup_slug_5b0f3e75_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactgroup_slug_5b0f3e75_like ON __BRANCH_SCHEMA__.tenancy_contactgroup USING btree (slug varchar_pattern_ops);


--
-- Name: tenancy_contactgroup_tree_id_57456c98; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactgroup_tree_id_57456c98 ON __BRANCH_SCHEMA__.tenancy_contactgroup USING btree (tree_id);


--
-- Name: tenancy_contactrole_name_44b01a1f_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactrole_name_44b01a1f_like ON __BRANCH_SCHEMA__.tenancy_contactrole USING btree (name varchar_pattern_ops);


--
-- Name: tenancy_contactrole_slug_c5837d7d_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_contactrole_slug_c5837d7d_like ON __BRANCH_SCHEMA__.tenancy_contactrole USING btree (slug varchar_pattern_ops);


--
-- Name: tenancy_tenant_group_id_7daef6f4; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_tenant_group_id_7daef6f4 ON __BRANCH_SCHEMA__.tenancy_tenant USING btree (group_id);


--
-- Name: tenancy_tenant_slug_0716575e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_tenant_slug_0716575e ON __BRANCH_SCHEMA__.tenancy_tenant USING btree (slug);


--
-- Name: tenancy_tenant_slug_0716575e_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_tenant_slug_0716575e_like ON __BRANCH_SCHEMA__.tenancy_tenant USING btree (slug varchar_pattern_ops);


--
-- Name: tenancy_tenant_unique_name; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX tenancy_tenant_unique_name ON __BRANCH_SCHEMA__.tenancy_tenant USING btree (name) WHERE (group_id IS NULL);


--
-- Name: tenancy_tenant_unique_slug; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX tenancy_tenant_unique_slug ON __BRANCH_SCHEMA__.tenancy_tenant USING btree (slug) WHERE (group_id IS NULL);


--
-- Name: tenancy_tenantgroup_name_53363199_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_tenantgroup_name_53363199_like ON __BRANCH_SCHEMA__.tenancy_tenantgroup USING btree (name varchar_pattern_ops);


--
-- Name: tenancy_tenantgroup_parent_id_2542fc18; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_tenantgroup_parent_id_2542fc18 ON __BRANCH_SCHEMA__.tenancy_tenantgroup USING btree (parent_id);


--
-- Name: tenancy_tenantgroup_slug_e2af1cb6_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_tenantgroup_slug_e2af1cb6_like ON __BRANCH_SCHEMA__.tenancy_tenantgroup USING btree (slug varchar_pattern_ops);


--
-- Name: tenancy_tenantgroup_tree_id_769a98bf; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX tenancy_tenantgroup_tree_id_769a98bf ON __BRANCH_SCHEMA__.tenancy_tenantgroup USING btree (tree_id);


--
-- Name: virtualization_cluster__location_id_f553e386; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_cluster__location_id_f553e386 ON __BRANCH_SCHEMA__.virtualization_cluster USING btree (_location_id);


--
-- Name: virtualization_cluster__region_id_9244325e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_cluster__region_id_9244325e ON __BRANCH_SCHEMA__.virtualization_cluster USING btree (_region_id);


--
-- Name: virtualization_cluster__site_group_id_7d9bff8f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_cluster__site_group_id_7d9bff8f ON __BRANCH_SCHEMA__.virtualization_cluster USING btree (_site_group_id);


--
-- Name: virtualization_cluster__site_id_883df848; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_cluster__site_id_883df848 ON __BRANCH_SCHEMA__.virtualization_cluster USING btree (_site_id);


--
-- Name: virtualization_cluster_group_id_de379828; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_cluster_group_id_de379828 ON __BRANCH_SCHEMA__.virtualization_cluster USING btree (group_id);


--
-- Name: virtualization_cluster_scope_type_id_c49d797a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_cluster_scope_type_id_c49d797a ON __BRANCH_SCHEMA__.virtualization_cluster USING btree (scope_type_id);


--
-- Name: virtualization_cluster_tenant_id_bc2868d0; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_cluster_tenant_id_bc2868d0 ON __BRANCH_SCHEMA__.virtualization_cluster USING btree (tenant_id);


--
-- Name: virtualization_cluster_type_id_4efafb0a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_cluster_type_id_4efafb0a ON __BRANCH_SCHEMA__.virtualization_cluster USING btree (type_id);


--
-- Name: virtualization_clustergroup_name_4fcd26b4_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_clustergroup_name_4fcd26b4_like ON __BRANCH_SCHEMA__.virtualization_clustergroup USING btree (name varchar_pattern_ops);


--
-- Name: virtualization_clustergroup_slug_57ca1d23_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_clustergroup_slug_57ca1d23_like ON __BRANCH_SCHEMA__.virtualization_clustergroup USING btree (slug varchar_pattern_ops);


--
-- Name: virtualization_clustertype_name_ea854d3d_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_clustertype_name_ea854d3d_like ON __BRANCH_SCHEMA__.virtualization_clustertype USING btree (name varchar_pattern_ops);


--
-- Name: virtualization_clustertype_slug_8ee4d0e0_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_clustertype_slug_8ee4d0e0_like ON __BRANCH_SCHEMA__.virtualization_clustertype USING btree (slug varchar_pattern_ops);


--
-- Name: virtualization_virtualdisk_virtual_machine_id_7bc8b6c2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_virtualdisk_virtual_machine_id_7bc8b6c2 ON __BRANCH_SCHEMA__.virtualization_virtualdisk USING btree (virtual_machine_id);


--
-- Name: virtualization_virtualmachine_cluster_id_6c9f9047; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_virtualmachine_cluster_id_6c9f9047 ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (cluster_id);


--
-- Name: virtualization_virtualmachine_config_template_id_d7fc7874; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_virtualmachine_config_template_id_d7fc7874 ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (config_template_id);


--
-- Name: virtualization_virtualmachine_device_id_5a49ed18; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_virtualmachine_device_id_5a49ed18 ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (device_id);


--
-- Name: virtualization_virtualmachine_platform_id_a6c5ccb2; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_virtualmachine_platform_id_a6c5ccb2 ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (platform_id);


--
-- Name: virtualization_virtualmachine_role_id_0cc898f9; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_virtualmachine_role_id_0cc898f9 ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (role_id);


--
-- Name: virtualization_virtualmachine_site_id_54475a27; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_virtualmachine_site_id_54475a27 ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (site_id);


--
-- Name: virtualization_virtualmachine_tenant_id_d00d1d77; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_virtualmachine_tenant_id_d00d1d77 ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (tenant_id);


--
-- Name: virtualization_virtualmachine_unique_name_cluster; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX virtualization_virtualmachine_unique_name_cluster ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (lower((name)::text), cluster_id) WHERE (tenant_id IS NULL);


--
-- Name: virtualization_virtualmachine_unique_name_cluster_tenant; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX virtualization_virtualmachine_unique_name_cluster_tenant ON __BRANCH_SCHEMA__.virtualization_virtualmachine USING btree (lower((name)::text), cluster_id, tenant_id);


--
-- Name: virtualization_vminterface_bridge_id_7462b91e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_bridge_id_7462b91e ON __BRANCH_SCHEMA__.virtualization_vminterface USING btree (bridge_id);


--
-- Name: virtualization_vminterface_parent_id_f86958e1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_parent_id_f86958e1 ON __BRANCH_SCHEMA__.virtualization_vminterface USING btree (parent_id);


--
-- Name: virtualization_vminterface_qinq_svlan_id_afacb024; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_qinq_svlan_id_afacb024 ON __BRANCH_SCHEMA__.virtualization_vminterface USING btree (qinq_svlan_id);


--
-- Name: virtualization_vminterface_tagged_vlans_vlan_id_4e77411e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_tagged_vlans_vlan_id_4e77411e ON __BRANCH_SCHEMA__.virtualization_vminterface_tagged_vlans USING btree (vlan_id);


--
-- Name: virtualization_vminterface_tagged_vlans_vminterface_id_904b12de; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_tagged_vlans_vminterface_id_904b12de ON __BRANCH_SCHEMA__.virtualization_vminterface_tagged_vlans USING btree (vminterface_id);


--
-- Name: virtualization_vminterface_untagged_vlan_id_aea4fc69; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_untagged_vlan_id_aea4fc69 ON __BRANCH_SCHEMA__.virtualization_vminterface USING btree (untagged_vlan_id);


--
-- Name: virtualization_vminterface_virtual_machine_id_e9f89829; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_virtual_machine_id_e9f89829 ON __BRANCH_SCHEMA__.virtualization_vminterface USING btree (virtual_machine_id);


--
-- Name: virtualization_vminterface_vlan_translation_policy_id_938e6637; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_vlan_translation_policy_id_938e6637 ON __BRANCH_SCHEMA__.virtualization_vminterface USING btree (vlan_translation_policy_id);


--
-- Name: virtualization_vminterface_vrf_id_4b570a8c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX virtualization_vminterface_vrf_id_4b570a8c ON __BRANCH_SCHEMA__.virtualization_vminterface USING btree (vrf_id);


--
-- Name: vpn_ikepolicy_name_5124aa3b_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ikepolicy_name_5124aa3b_like ON __BRANCH_SCHEMA__.vpn_ikepolicy USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ikepolicy_proposals_ikepolicy_id_1e1deaab; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ikepolicy_proposals_ikepolicy_id_1e1deaab ON __BRANCH_SCHEMA__.vpn_ikepolicy_proposals USING btree (ikepolicy_id);


--
-- Name: vpn_ikepolicy_proposals_ikeproposal_id_a9ead252; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ikepolicy_proposals_ikeproposal_id_a9ead252 ON __BRANCH_SCHEMA__.vpn_ikepolicy_proposals USING btree (ikeproposal_id);


--
-- Name: vpn_ikeproposal_name_254623b7_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ikeproposal_name_254623b7_like ON __BRANCH_SCHEMA__.vpn_ikeproposal USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ipsecpolicy_name_cf28a1aa_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ipsecpolicy_name_cf28a1aa_like ON __BRANCH_SCHEMA__.vpn_ipsecpolicy USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ipsecpolicy_proposals_ipsecpolicy_id_0e7771a1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ipsecpolicy_proposals_ipsecpolicy_id_0e7771a1 ON __BRANCH_SCHEMA__.vpn_ipsecpolicy_proposals USING btree (ipsecpolicy_id);


--
-- Name: vpn_ipsecpolicy_proposals_ipsecproposal_id_685fe509; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ipsecpolicy_proposals_ipsecproposal_id_685fe509 ON __BRANCH_SCHEMA__.vpn_ipsecpolicy_proposals USING btree (ipsecproposal_id);


--
-- Name: vpn_ipsecprofile_ike_policy_id_4eff5fb9; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ipsecprofile_ike_policy_id_4eff5fb9 ON __BRANCH_SCHEMA__.vpn_ipsecprofile USING btree (ike_policy_id);


--
-- Name: vpn_ipsecprofile_ipsec_policy_id_e06f2323; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ipsecprofile_ipsec_policy_id_e06f2323 ON __BRANCH_SCHEMA__.vpn_ipsecprofile USING btree (ipsec_policy_id);


--
-- Name: vpn_ipsecprofile_name_3ac63c72_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ipsecprofile_name_3ac63c72_like ON __BRANCH_SCHEMA__.vpn_ipsecprofile USING btree (name varchar_pattern_ops);


--
-- Name: vpn_ipsecproposal_name_2fb98e2b_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_ipsecproposal_name_2fb98e2b_like ON __BRANCH_SCHEMA__.vpn_ipsecproposal USING btree (name varchar_pattern_ops);


--
-- Name: vpn_l2vpn_name_8824eda5_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_l2vpn_name_8824eda5_like ON __BRANCH_SCHEMA__.vpn_l2vpn USING btree (name varchar_pattern_ops);


--
-- Name: vpn_l2vpn_slug_76b5a174_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_l2vpn_slug_76b5a174_like ON __BRANCH_SCHEMA__.vpn_l2vpn USING btree (slug varchar_pattern_ops);


--
-- Name: vpn_l2vpn_tenant_id_57ec8f92; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_l2vpn_tenant_id_57ec8f92 ON __BRANCH_SCHEMA__.vpn_l2vpn USING btree (tenant_id);


--
-- Name: vpn_l2vpntermination_assigned_object_type_id_f063b865; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_l2vpntermination_assigned_object_type_id_f063b865 ON __BRANCH_SCHEMA__.vpn_l2vpntermination USING btree (assigned_object_type_id);


--
-- Name: vpn_l2vpntermination_l2vpn_id_f5367bbe; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_l2vpntermination_l2vpn_id_f5367bbe ON __BRANCH_SCHEMA__.vpn_l2vpntermination USING btree (l2vpn_id);


--
-- Name: vpn_tunnel_group_id_56b1e7f7; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunnel_group_id_56b1e7f7 ON __BRANCH_SCHEMA__.vpn_tunnel USING btree (group_id);


--
-- Name: vpn_tunnel_ipsec_profile_id_fd0361c5; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunnel_ipsec_profile_id_fd0361c5 ON __BRANCH_SCHEMA__.vpn_tunnel USING btree (ipsec_profile_id);


--
-- Name: vpn_tunnel_name; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE UNIQUE INDEX vpn_tunnel_name ON __BRANCH_SCHEMA__.vpn_tunnel USING btree (name) WHERE (group_id IS NULL);


--
-- Name: vpn_tunnel_name_f060beab_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunnel_name_f060beab_like ON __BRANCH_SCHEMA__.vpn_tunnel USING btree (name varchar_pattern_ops);


--
-- Name: vpn_tunnel_tenant_id_f3df2ab3; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunnel_tenant_id_f3df2ab3 ON __BRANCH_SCHEMA__.vpn_tunnel USING btree (tenant_id);


--
-- Name: vpn_tunnelgroup_name_9f6ebf92_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunnelgroup_name_9f6ebf92_like ON __BRANCH_SCHEMA__.vpn_tunnelgroup USING btree (name varchar_pattern_ops);


--
-- Name: vpn_tunnelgroup_slug_9e614d62_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunnelgroup_slug_9e614d62_like ON __BRANCH_SCHEMA__.vpn_tunnelgroup USING btree (slug varchar_pattern_ops);


--
-- Name: vpn_tunneltermination_outside_ip_id_2c6f3a7c; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunneltermination_outside_ip_id_2c6f3a7c ON __BRANCH_SCHEMA__.vpn_tunneltermination USING btree (outside_ip_id);


--
-- Name: vpn_tunneltermination_termination_type_id_e546f7a1; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunneltermination_termination_type_id_e546f7a1 ON __BRANCH_SCHEMA__.vpn_tunneltermination USING btree (termination_type_id);


--
-- Name: vpn_tunneltermination_tunnel_id_962efa25; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX vpn_tunneltermination_tunnel_id_962efa25 ON __BRANCH_SCHEMA__.vpn_tunneltermination USING btree (tunnel_id);


--
-- Name: wireless_wirelesslan__location_id_c742912f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslan__location_id_c742912f ON __BRANCH_SCHEMA__.wireless_wirelesslan USING btree (_location_id);


--
-- Name: wireless_wirelesslan__region_id_fd2a93ee; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslan__region_id_fd2a93ee ON __BRANCH_SCHEMA__.wireless_wirelesslan USING btree (_region_id);


--
-- Name: wireless_wirelesslan__site_group_id_d61285cc; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslan__site_group_id_d61285cc ON __BRANCH_SCHEMA__.wireless_wirelesslan USING btree (_site_group_id);


--
-- Name: wireless_wirelesslan__site_id_5dce5f6f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslan__site_id_5dce5f6f ON __BRANCH_SCHEMA__.wireless_wirelesslan USING btree (_site_id);


--
-- Name: wireless_wirelesslan_group_id_d9e3d67f; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslan_group_id_d9e3d67f ON __BRANCH_SCHEMA__.wireless_wirelesslan USING btree (group_id);


--
-- Name: wireless_wirelesslan_scope_type_id_c3e37d35; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslan_scope_type_id_c3e37d35 ON __BRANCH_SCHEMA__.wireless_wirelesslan USING btree (scope_type_id);


--
-- Name: wireless_wirelesslan_tenant_id_5dfee941; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslan_tenant_id_5dfee941 ON __BRANCH_SCHEMA__.wireless_wirelesslan USING btree (tenant_id);


--
-- Name: wireless_wirelesslan_vlan_id_d7fa6ccc; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslan_vlan_id_d7fa6ccc ON __BRANCH_SCHEMA__.wireless_wirelesslan USING btree (vlan_id);


--
-- Name: wireless_wirelesslangroup_name_2ffd60c8_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslangroup_name_2ffd60c8_like ON __BRANCH_SCHEMA__.wireless_wirelesslangroup USING btree (name varchar_pattern_ops);


--
-- Name: wireless_wirelesslangroup_parent_id_37ca8b87; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslangroup_parent_id_37ca8b87 ON __BRANCH_SCHEMA__.wireless_wirelesslangroup USING btree (parent_id);


--
-- Name: wireless_wirelesslangroup_slug_f5d59831_like; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslangroup_slug_f5d59831_like ON __BRANCH_SCHEMA__.wireless_wirelesslangroup USING btree (slug varchar_pattern_ops);


--
-- Name: wireless_wirelesslangroup_tree_id_eb99115d; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslangroup_tree_id_eb99115d ON __BRANCH_SCHEMA__.wireless_wirelesslangroup USING btree (tree_id);


--
-- Name: wireless_wirelesslink__interface_a_device_id_6c8e042e; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslink__interface_a_device_id_6c8e042e ON __BRANCH_SCHEMA__.wireless_wirelesslink USING btree (_interface_a_device_id);


--
-- Name: wireless_wirelesslink__interface_b_device_id_43d5101a; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslink__interface_b_device_id_43d5101a ON __BRANCH_SCHEMA__.wireless_wirelesslink USING btree (_interface_b_device_id);


--
-- Name: wireless_wirelesslink_interface_a_id_bc9e37fd; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslink_interface_a_id_bc9e37fd ON __BRANCH_SCHEMA__.wireless_wirelesslink USING btree (interface_a_id);


--
-- Name: wireless_wirelesslink_interface_b_id_a82fb2ee; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslink_interface_b_id_a82fb2ee ON __BRANCH_SCHEMA__.wireless_wirelesslink USING btree (interface_b_id);


--
-- Name: wireless_wirelesslink_tenant_id_4c0638ee; Type: INDEX; Schema: __BRANCH_SCHEMA__; Owner: -
--

CREATE INDEX wireless_wirelesslink_tenant_id_4c0638ee ON __BRANCH_SCHEMA__.wireless_wirelesslink USING btree (tenant_id);


--
-- PostgreSQL database dump complete
--


